# Research Project

This repository contains the research pilot, verified Qwen Stage A and Stage B experiment artifacts, and analysis reports.

## Folder guide
- `information_placebo_pilot/`: pilot scripts, configurations, documentation, and analysis.
- `qwen_stage_a_verified/`: Stage A run records, analysis, frozen configuration/input artifacts, and documentation.
- `qwen_stage_b_stage1_verified/`: Stage B Stage 1 verified run artifacts and frozen inputs.
- `qwen_stage_b_verified/`: Stage B Stage 2 verified run artifacts and frozen inputs.
- `qwen_stage_b_analysis/`: Stage B analysis tables, report, and figures.
- `Phi4_Research.ipynb`: notebook supplied with the project.

## Notes
Some bulky or redundant artifacts were omitted from this GitHub-ready package, including checkpoint archives, nested ZIP bundles, temporary logs, test-run directories, and duplicate raw dataset copies. Run outputs and analysis artifacts retained here are for research transparency; review the included reports for limitations and interpretation.

See the README files inside individual folders for their specific instructions and requirements.
