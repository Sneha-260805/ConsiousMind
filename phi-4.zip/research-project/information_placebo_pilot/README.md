# Information or Placebo? Diagnostic Feedback for LLM Reasoning Repair (pilot)

## Research pilot

We take correct GSM8K reasoning traces, inject exactly **one** known reasoning error, and test whether
LLMs repair the trace differently depending on the diagnostic feedback they receive. The pilot is small
by design:

- 30–50 GSM8K examples, one controlled error per trace
- error type **M1 only**: wrong arithmetic operation (e.g. `/` changed to `*`)
- five feedback conditions:
  - `L0`: no diagnostic feedback
  - `V`: "The final answer above is wrong."
  - `L`: true error location
  - `L_false`: false error location
  - `A`: correct answer given (ceiling)

The central question is whether a *location* hint carries real information (L beats L_false) or acts
as a placebo (L ≈ L_false ≈ V).

## Current stage: Stage 1, dataset inspection (no corruption, no LLM)

This stage only:

1. downloads GSM8K from the official OpenAI repository (pinned commit), and
2. inspects how solutions and `<<expr=result>>` calculator annotations are structured, to decide how
   M1 corruption can be done safely.

Nothing in this stage writes corrupted data or calls a model. The "throwaway swap test" in the
inspection script computes, in memory only, what would happen if one operator were swapped, to
measure feasibility.

## Layout

```
data/raw/        GSM8K train.jsonl / test.jsonl, exactly as downloaded (never modified)
data/pilot/      (empty) future curated pilot items
scripts/
  download_gsm8k.py   fetch raw files from github.com/openai/grade-school-math @ pinned commit
  inspect_gsm8k.py    structural analysis + suitability heuristic + throwaway swap test
outputs/
  gsm8k_inspection.json              per-example analysis, train[0:20]
  gsm8k_train_annotation_stats.json  aggregate statistics over all 7,473 train examples
  representative_examples.txt        5 examples in readable form
logs/
  download_log.json   URLs, line counts and SHA-256 of the raw files
  inspection_run.log  full console output of the last inspection run
```

## How to rerun

Requires Python 3.10+ and no third-party packages. Run from this folder:

```bash
python scripts/download_gsm8k.py          # skips files that already exist; logs SHA-256
PYTHONIOENCODING=utf-8 python scripts/inspect_gsm8k.py > logs/inspection_run.log
# options: --start 0 --n 20 (which train slice to save), --show 0 3 19 9 10 (examples to print)
```

On Windows PowerShell, set the encoding first: `$env:PYTHONIOENCODING="utf-8"`. Otherwise curly
quotes in the data show up as `�` in the console. The raw files themselves are clean.

Expected raw-file hashes (also in `logs/download_log.json`):

- train.jsonl: 7473 lines, sha256 `17f347dc51477c50d4efb83959dbb7c56297aba886e5544ee2aaed3024813465`
- test.jsonl: 1319 lines, sha256 `3730d312f6e3440559ace48831e51066acaca737f6eabec99bccb9e4b3c39d14`

## Stage 2: 10 M1 candidate traces for manual review (no LLM)

`scripts/build_m1_candidates.py` builds exactly 10 corrupted traces, each with one wrong-operation
error, from a strict subset of GSM8K train:

1. **Strict filter.** An example is rejected if any annotation fails to parse or is inexact, or if
   it has fewer than 2 calculations. It is also rejected if any step has more than one calculation,
   or if the final answer doesn't equal the last calculation. Algebra is rejected. Every calculation
   must have a visible `a op b =` that matches its annotation, and a matching visible result. Numbers
   or arithmetic that appear in prose without an annotation cause rejection. Every operand must
   trace to exactly one source (the question, one earlier calculation, or a unit constant).
2. **Explicit graph.** Each `<<expr=result>>` becomes a node with its operators, operands, sources
   and dependencies.
3. **Corruption.** One single-operator, non-final calculation at step 2 or later gets a different
   operator. The new value is propagated only along graph edges, and only the calculation spans
   are rewritten.
4. **Safety checks.** A corruption is rejected for division by zero, a negative or zero value, a
   non-integer where the original was an integer, a ratio outside [0.1, 10] (for the error step and
   for the final answer), an unchanged result, a final answer equal to the gold one, a changed
   value restated in prose, or a new value that collides with an existing number.
5. **Independent validation.** The gold and corrupted texts are re-parsed from scratch and every
   check is stored per candidate.
6. **Selection.** Selection is seeded (42) with diversity caps. At most 2 of the 10 may be flagged
   "obvious from local wording".

```bash
PYTHONIOENCODING=utf-8 python scripts/build_m1_candidates.py > logs/build_m1_candidates_run.log
```

Outputs:
- `data/pilot/m1_candidates_10.json`: the candidates. The traces carry no error markers.
- `outputs/m1_candidates_review.txt`: the review file. The error step is marked here only.
- `outputs/m1_candidates_stats.json`: filter, rejection and selection statistics.

The output is deterministic: two runs give byte-identical JSON. Each candidate's
`manual_review.approved` is `null` until a human reviews it.

## Stage 3: clean M1 regeneration (outcome: 0 clean candidates)

`scripts/build_m1_clean.py` imports the Stage 2 structural pipeline unchanged and adds four controls:
a unit check (cross-family swaps and unverifiable `*`↔`/` swaps are rejected), a local-wording cue
check, a question-wording cue check (any cue anywhere in the question counts), and a semantic
plausibility check. The plausibility check is partly automatic (numeric bands) and partly a
reviewer verdict recorded in the script with a reason.

Of 1,217 structurally valid corruptions, 28 survive the automatic controls. All 28 fail the reviewer
semantic check: each `+`↔`-` swap turns a sum into something smaller than one of its parts, or a
remainder into something larger than the whole. No clean JSON file is written. The full audit is in
`outputs/m1_clean_pool_audit.txt` and the statistics in `outputs/m1_candidates_10_clean_stats.json`.

```bash
PYTHONIOENCODING=utf-8 python scripts/build_m1_clean.py > logs/build_m1_clean_run.log   # exits 2 (incomplete)
```

## Stage 4: M3 calculation-slip candidates (first behavioral pilot)

An M3 error keeps the operands, the operator, the meaning and the units of one calculation, and
replaces only its result with a nearby wrong value (±1, ±2, ±10), e.g. `9450/90 = 106`. The wrong
value appears in both the visible text and the annotation, and every dependent later step is
recomputed correctly from it.

`scripts/build_m3_candidates.py` reuses the Stage 2 parser, filter, dependency graph and span
rewriting. The only change to `build_m1_candidates.py` is an opt-in `strict_arithmetic=False` flag
on `parse_trace`; the default behaviour is unchanged, and Stage 2 output is byte-identical. The
script then applies three layers:

1. **Automatic realism rules.** These reject slips that can be spotted without doing the
   arithmetic, or that sit on recalled facts: times tables, doubling or halving, round numbers,
   carry-free single digits, visible divisibility, and similar.
2. **Wording check.** This rejects any slip where the question states the correct result.
3. **Reviewer semantic gate.** Each verdict is recorded in the script with a reason.

The script is deterministic (seed 42). If it can't select 10 candidates it exits with code 2 and
deletes its own stale outputs. A full run takes about 2–3 minutes.

```bash
PYTHONIOENCODING=utf-8 python scripts/build_m3_candidates.py > logs/build_m3_candidates_run.log
```

Outputs:
- `data/pilot/m3_candidates_10.json`: the candidates.
- `outputs/m3_candidates_10_review.txt`: the review file.
- `outputs/m3_candidates_10_stats.json`: statistics.
- `outputs/m3_reviewed_sample_audit.txt`: reviewer rejections met during selection.

## Stage 5: 40-item M3 pilot set

`scripts/build_m3_pilot40.py` builds the first behavioral pilot set: 40 M3 items, one per GSM8K
problem. It reuses the Stage 4 M3 machinery unchanged and adds:

- **Selection balancing.** Each problem gets a seeded target direction (alternating over/under) and
  magnitude (±1/±2/±10). Reviewer verdicts can only remove options and never reorder them, which
  keeps the selection stable. Caps limit operator and step concentration.
- **Pilot-only realism rules.** Carry-free additions and borrow-free subtractions are rejected,
  which replaced inconsistent case-by-case calls. Even results of all-odd products (`33*7 = 232`)
  are rejected too, mirroring Stage 4's even-factor parity rule.
- **A gold-text gate.** Automatic flags catch lower-case sentence starts, fragments, doubled words,
  and label-like words (gold, wrong, error, ...). A recorded per-problem reading of every selected
  gold trace catches typos, grammar errors and gold reasoning errors. A second, stricter
  reading (2026-10-08) also rejects question-side fragments and grammar errors, spacing typos such as
  `240-144 =96`, and unit or label slips in the gold text (84 problems excluded in total). The
  error-step cap was raised from 14 to 15 because the stricter gate used up the reviewed pool at 39 items.
- **Student-facing fields** (`question`, `*_steps_student`, `*_trace_student`). These have the
  annotations removed and nothing else changed, and an automatic leakage audit asserts zero hits.

```bash
PYTHONIOENCODING=utf-8 python scripts/build_m3_pilot40.py > logs/build_m3_pilot40_run.log   # ~11 s
```

Outputs:
- `data/pilot/m3_pilot_40.json`: the 40 items.
- `outputs/m3_pilot_40_review.txt`: the review file, with APPROVE/REJECT boxes.
- `outputs/m3_pilot_40_stats.json`: statistics.

## Caveats of the inspection heuristic

Operand provenance (question vs. an earlier result) is inferred by **matching values**, so it can be
wrong when the same number appears in more than one place. Examples where this happens are flagged
"ambiguous" and marked unsuitable. Constants such as 2, 7, 12, 60 and 100 are accepted as "implicit"
even when they were actually computed in prose (train[10]: `7 = 1+2+4`). A value written as `.5`
(no leading zero) is reported as a hidden value; this is a known false positive. The heuristic is a
filter for candidates, not a substitute for manually reviewing every pilot item.

## Stage 6: five feedback conditions (no model calls)

`scripts/build_conditions.py` turns the 40 pilot items into 200 independent prompts: 40 items x {L0, V,
L, L_false, A}. Every prompt shares one neutral template:

- problem
- numbered corrupted student steps
- an optional feedback paragraph
- "Assess the proposed solution carefully…" ending with `FINAL_ANSWER: <answer>`

L0 has no feedback paragraph. L and L_false use identical wording and differ only in the step number.
V is L with the location sentence removed.

The false steps are chosen deterministically by exhaustively searching over 3,520 count assignments.
The search minimises the L1 distance between the true-step and false-step histograms, then the squared
distance, then the total step distance. It reaches the theoretical lower bound: items with the error
at Step 2 can only point at Step 1. Every false step is checked: it precedes the error, is identical to
gold, holds a correct calculation, and is not downstream of the error.

The script audits all 200 prompts for leakage. It also checks that L/L_false are byte-identical apart
from the step number, and that V equals L minus the location sentence. It exits with code 2 on any
violation. The source dataset is only read, and its SHA-256 is recorded in the manifest.

```bash
PYTHONIOENCODING=utf-8 python scripts/build_conditions.py > logs/build_conditions_run.log
```

Outputs:
- `data/pilot/m3_pilot_40_conditions.jsonl`: the 200 rows.
- `outputs/m3_pilot_40_conditions_review.txt`: the review file.
- `outputs/m3_pilot_40_condition_manifest.json`: distributions and audit results.

## Stage 7: L_false_far sensitivity condition (no model calls)

The primary file's `L_false` condition is now read as **L_false_near**. The primary file itself is not
rewritten, which keeps its SHA-256 for provenance; the alias is recorded in the far-false manifest.

`scripts/build_far_false.py` adds a second false-location control for a sensitivity analysis. A far
step must sit at least 2 steps before the true error and pass the same correctness checks as the near
step. Candidates are tiered by dependency relation to the error step:

- Tier 1: neither a direct parent nor an ancestor.
- Tier 2: an indirect ancestor only.
- Tier 3: a direct parent.

The best tier wins, and within it the latest step. Items whose error is at Step 2 have no candidate
and are marked unavailable. The prompt wording is identical to L except for the step number. It is
audited with the same leakage and matching functions as the primary conditions.

```bash
PYTHONIOENCODING=utf-8 python scripts/build_far_false.py > logs/build_far_false_run.log
```

Outputs:
- `data/pilot/m3_pilot_40_far_false_sensitivity.jsonl`: 25 rows.
- `outputs/m3_pilot_40_far_false_manifest.json`: per-item dependency records for all 40 items, plus distributions and audits.
- `outputs/m3_pilot_40_far_false_review.txt`: the review file.

## Stage 8: inference and scoring harness (built and tested; no model has been run)

| File | Role |
|---|---|
| `scripts/pilot_common.py` | frozen inputs, SHA-256 provenance, seeded execution order, crash-safe JSONL |
| `scripts/backends.py` | adapter interface `generate(prompt) -> text + metadata`: `mock` (TEST ONLY), `openai_compatible`, `ollama`, `hf_transformers` (lazy import) |
| `scripts/run_pilot.py` | runner: one fresh request per prompt, resume, retry on transport errors only, `--smoke-test`, `--dry-run` |
| `scripts/parse_answers.py` | strict `FINAL_ANSWER:` parser (last occurrence; formatting-only normalisation) |
| `scripts/score_pilot.py` | per-row flags, per-condition descriptive rates, paired tables (primary 40 items, far subset 25 items) |
| `scripts/test_harness.py` | 19 tests: mock backend plus an in-process fake HTTP server |
| `configs/pilot_model.example.json` | template; fill in a real backend and model before any real run |
| `configs/mock_test.json` | TEST ONLY mock configuration |

The execution order (`outputs/pilot_execution_order.json`) is 225 requests shuffled once with seed 2026.
Analysis reads the frozen `L_false` label as `L_false_near`.

Real runs write to `outputs/runs/<run_id>/`. Mock runs and dry runs can only write to
`outputs/test_runs/` and are labelled TEST ONLY.

```bash
python -m unittest scripts/test_harness.py -v                                               # tests
python scripts/run_pilot.py --config configs/<model>.json --run-id <id> --smoke-test --dry-run   # nothing sent
python scripts/run_pilot.py --config configs/<model>.json --run-id <id> --smoke-test             # 10 real requests
python scripts/run_pilot.py --config configs/<model>.json --run-id <id>                          # 225 requests; rerun the same command to resume
```

## Stage 9: two answer parsers and Qwen3-4B preparation (no model downloaded or run)

**Parsing is predefined before any results exist.**

- *Strict format parser*: unchanged from Stage 8. It is a diagnostic only:
  `strict_parse_status`, `strict_parsed_answer`, and `strict_format_compliant` (an exact
  `FINAL_ANSWER: <number>` on the last line).
- *Numeric parser*: used to score repair.
  - It reads the last `final_answer:` field, case-insensitively, and accepts it only if the field
    holds exactly one standalone number (`FINAL_ANSWER: 1920 dollars` → 1920).
  - Two or more numbers make it `ambiguous` (`1920 or 1880`, `40*48 = 1920`).
  - Only when no label exists does it look at the final non-empty line, which must contain exactly
    one number.
  - It never searches the rest of the reasoning.

Repair is `numeric_parsed_answer == gold`. The strict format failure is reported separately, along
with a strict-parse repair rate for comparison.

**Qwen3-4B** is configured in `configs/qwen3_4b_pilot.json`:

- revision `3101254bbe4169895668a0e7653c3fd1f313576e`, the chat model, not the Base model;
- `hf_transformers` backend, BF16 on CPU (this machine has no NVIDIA GPU);
- greedy decoding, `max_new_tokens` 512;
- `enable_thinking: false`, applied through the chat-template switch. The frozen prompt is never edited.

At start-up, before any prompt is sent, the backend:

- refuses to load if free RAM is below `min_free_ram_gb`;
- verifies the rendered chat template:
  - the prompt appears verbatim;
  - the wrapper is constant across prompts;
  - no system message and no `/think` or `/no_think` text are added;
  - the switch is honoured, and the `<think>` block is empty;
- checks every request against `prefix + frozen prompt + suffix`.

Greedy decoding at temperature 0 prioritises deterministic comparison over Qwen's recommended
sampling settings.

## Stage 10: Kaggle free-GPU package (prepared only; nothing run)

The local Qwen plan was stopped: the laptop's memory was too tight. The partial HF cache is left untouched.
`python scripts/build_kaggle_bundle.py` does the following:

1. Verifies the four frozen files.
2. Builds `kaggle/pilot_bundle/`, mirroring the repo layout, so the audited `run_pilot`, `backends`,
   `parse_answers` and `score_pilot` run unchanged.
3. Writes `manifest.json` with every file's SHA-256.
4. Writes `kaggle/pilot_bundle.zip` and `kaggle/run_qwen3_pilot.ipynb`. The notebook has 9 cells and stops
   after the 10-request smoke test.
5. Writes `kaggle/README_KAGGLE.md` with the upload steps.

The model config is `configs/qwen3_4b_kaggle.json`: Qwen/Qwen3-4B at the pinned revision, FP16 on `cuda:0`,
greedy decoding, 512 new tokens, `enable_thinking=false`, batch size 1. When CUDA is requested, the HF
backend loads the weights straight to the GPU and never falls back to the CPU.

### Protocol change: max_new_tokens 512 -> 768 (2026-10-08)

The first Kaggle smoke test passed every check except one: m3p_04 under condition A hit the 512-token
limit before reaching its `FINAL_ANSWER` line. `max_new_tokens` was raised to 768. Nothing else changed:
model, revision, FP16, cuda:0, greedy decoding, `enable_thinking=false`, prompts, conditions, data, order,
parser, scorer and smoke selection are all the same.

- The 512-token run is kept unchanged as `results/smoke_512/`. The same 10 requests are regenerated from
  scratch into `results/smoke_768/`.
- `kaggle/session1_patch_768.py` applies the change in a running session and reuses the loaded model.
- Bundle v3 carries the change for fresh sessions. Bundles v1 and v2 are archived in `kaggle/`.

### Frozen model protocol (2026-10-08, after the 768-token smoke test passed every gate)

Frozen settings:

- model: Qwen/Qwen3-4B at revision 3101254bbe4169895668a0e7653c3fd1f313576e
- FP16 on cuda:0 (Kaggle T4)
- temperature 0, do_sample=false, num_beams=1
- enable_thinking=false
- max_new_tokens 768, batch size 1

None of these may change in response to model outputs.

`kaggle/session1_run_full_768.py` runs the frozen 225-request pilot (200 primary + 25 L_false_far) in the
live Kaggle session. It reuses the loaded model and first runs 13 pre-flight checks, again on every resume.
Results go to `results/full_768/`, kept separate from `smoke_512/` and `smoke_768/`. The run is crash-safe:
re-running the same cell resumes it, and responses that hit the token limit are recorded, never regenerated.
It stops after generation and scoring; no analysis is done here.
