# Information or Placebo? Qwen3-4B feasibility pilot (40 items, 225 requests)

**Status:** exploratory feasibility pilot. It is not the publication experiment and not confirmatory evidence.
**Source:** `results_full_768_FINAL.zip` (SHA-256 `ec6197e3c71d95d9df7d2c9dfeeb69285b7b14df3c2247ff01eb590aa4dc3d2d`),
extracted to `kaggle/results/full_768_FINAL/results/full_768/`.
**Analysis code:** `scripts/analyze_pilot.py`. No model inference was rerun or modified.
**Scoring:** the frozen scorer's `is_gold_correct` is used unchanged. A response counts as repaired only when its
parsed numeric answer equals gold. Non-numeric, unparseable and truncated answers count as not repaired.

## In plain language first

Qwen3-4B was shown 40 short math solutions. Each solution contained exactly one small arithmetic slip, and the
model was asked to give the right answer. What we changed was the hint:

| Condition | What the model was told |
|---|---|
| L0 | nothing (just "assess the solution") |
| V | "The final answer is wrong." |
| L | "The final answer is wrong. The first mistake is in Step *k*." (the true step) |
| L_false_near | same sentence, but pointing at the step just before the true error (a correct step) |
| A | "The correct final answer is *X*." (answer ceiling) |

- **With no hint**, the model fixed the slip half the time (20/40).
- **Being told the answer is wrong** raised that to 80% (32/40).
- **Adding the true location** barely helped further: 82.5% (33/40).
- **Adding a false location** pulled the model back down to 55% (22/40), nearly as low as no hint at all.
- **Given the answer**, it reached 92.5% (37/40).

So true and false location hints lead to very different outcomes: 82.5% vs 55%, a gap of 27.5 points. Most of
that gap is not because the true hint helps. It is because the false hint hurts. Compared with the plain
"your answer is wrong" message, a correct pointer adds about 2.5 points, while a wrong pointer costs about
25 points. The content of the diagnostic clearly matters, so this is not a placebo. In this setup, though, the
content matters mainly as a source of harm when it is wrong.

---

## DATA INTEGRITY

All 14 checks pass, so the analysis proceeds:

- **Rows:** 225/225 raw rows and 225 scored rows, with 225 unique request keys and no duplicates. The scored
  keys equal the raw keys.
- **Condition counts:** L0 40, V 40, L_false_near 40, L 40, A 40, L_false_far 25.
- **Failures:** 0 transport failures, 0 retries, 0 runtime failures. Every request completed on a single attempt.
- **Protocol:** the config matches the frozen protocol, and every row records the frozen settings:
  - Qwen/Qwen3-4B @ `3101254b…`
  - FP16, cuda:0, Tesla T4
  - greedy decoding, temperature 0, enable_thinking false
  - max_new_tokens 768, batch 1
- **Frozen inputs:** the input-file hashes and the execution-order hash (`2b6e7e0f…`) are the frozen ones.
  The data is not test-only, and all 15 Kaggle pre-flight checks passed.
- **Scoring reproduces:** I reran the frozen parser and scorer locally on a copy of the run directory. They
  reproduced `parsed_outputs.jsonl`, `scored_outputs.jsonl` and both paired CSVs byte for byte.
- **Outcomes kept as observed:**
  - `m3p_40/A` was truncated at 768 tokens and is scored as not repaired.
  - `m3p_06/L_false_near` and `m3p_06/L_false_far` gave non-numeric answers and are scored as not repaired.

## PRIMARY REPAIR RATES

The outcome breakdown in the last three columns is descriptive and comes from the frozen scorer.

| Condition | Correct / 40 | Repair rate | % | Gave the corrupted answer | Other wrong number | No numeric answer |
|---|---|---|---|---|---|---|
| L0 | 20 | 0.500 | 50.0% | 20 | 0 | 0 |
| V | 32 | 0.800 | 80.0% | 8 | 0 | 0 |
| L_false_near | 22 | 0.550 | 55.0% | 13 | 4 | 1 |
| L | 33 | 0.825 | 82.5% | 5 | 2 | 0 |
| A | 37 | 0.925 | 92.5% | 1 | 1 | 1 |

## CCA

**CCA = RR(L) − RR(L_false_near) = 0.825 − 0.550 = +27.5 percentage points.**

## PAIRED TABLE

| (40 items) | L_false_near correct | L_false_near wrong |
|---|---|---|
| **L correct** | 20 (both_correct) | **13 (true_only)** |
| **L wrong** | **2 (false_only)** | 5 (both_wrong) |

There are 15 discordant pairs: 13 favour the true location and 2 favour the false one.

## UNCERTAINTY

This is exploratory pilot inference.

- **Exact McNemar test** (13 vs 2 discordant pairs): two-sided p = 0.0074.
- **Paired bootstrap 95% CI for CCA:** [+10.0, +45.0] pp. This used 10,000 item resamples, seed 2026, and the
  percentile method. Only 0.12% of resamples had CCA ≤ 0.

The interval is wide because there are only 40 items. Its lower end (+10 pp) is still clearly above zero.

## MECHANISM DECOMPOSITION

| Quantity | Definition | Value | Paired discordant counts | Exact McNemar p |
|---|---|---|---|---|
| Verification effect | RR(V) − RR(L0) | **+30.0 pp** | V-only 13 vs L0-only 1 | 0.0018 |
| Correct-location increment | RR(L) − RR(V) | **+2.5 pp** | L-only 4 vs V-only 3 | 1.0 |
| False-location increment | RR(L_false_near) − RR(V) | **−25.0 pp** | L_false_near-only 0 vs V-only 10 | 0.0020 |
| Correct-content advantage | RR(L) − RR(L_false_near) | **+27.5 pp** | L-only 13 vs L_false_near-only 2 | 0.0074 |
| Answer ceiling | RR(A) | **92.5%** (37/40) | – | – |

Reading this table:
- The CCA of +27.5 pp is almost exactly the false-location harm (−25 pp) plus a small true-location gain
  (+2.5 pp).
- The false pointer never rescued an item that V alone missed (0 cases), and it broke 10 items that V alone
  got right.
- V is already at 80% against a 92.5% ceiling, so there was little room left for the true location to show a
  gain.

## FAR-FALSE SENSITIVITY

This uses the same 25 items throughout (the items where a far false step exists).

| Condition (same 25 items) | Correct / 25 | Rate |
|---|---|---|
| L0 | 14 | 56% |
| V | 21 | 84% |
| L | 21 | 84% |
| L_false_near | 14 | 56% |
| L_false_far | 18 | 72% |
| A | 23 | 92% |

| Contrast (25 items) | Diff | Discordant counts | McNemar p | Bootstrap 95% CI |
|---|---|---|---|---|
| CCA_near_25 = L − L_false_near | **+28.0 pp** | L-only 8 vs near-only 1 | 0.039 | [+8, +48] |
| CCA_far_25 = L − L_false_far | **+12.0 pp** | L-only 4 vs far-only 1 | 0.375 | [−4, +28] |
| L_false_near − L_false_far | −16.0 pp | near-only 1 vs far-only 5 | 0.219 | – |

- **The near result replicates.** On these 25 items CCA_near is +28 pp, essentially the same as the full-set
  +27.5 pp.
- **The far result points the same way but is smaller,** and its CI includes 0.
- **A far false pointer did less damage than a near one** (72% vs 56%). This is consistent with a
  misdirection cost that is largest when the false pointer sits right next to the true error, usually on a
  step that feeds into it.

## m3p_06 SENSITIVITY

**POST-HOC AMBIGUITY SENSITIVITY — NOT PRIMARY ANALYSIS** (m3p_06 excluded, 39 items)

| Condition | Correct / 39 | Rate |
|---|---|---|
| L0 | 20 | 51.3% |
| V | 32 | 82.1% |
| L_false_near | 22 | 56.4% |
| L | 32 | 82.1% |
| A | 36 | 92.3% |

- **CCA:** +25.6 pp (12 vs 2 discordant pairs), McNemar p = 0.013, bootstrap 95% CI [+10.3, +43.6].
- **How m3p_06 behaved:**
  - It is a true_only item: L correct, L_false_near wrong.
  - It was wrong under L0 and V, both times answering 335.
  - It gave non-numeric answers under both false conditions.
- **Removing m3p_06 does not materially change CCA.** It stays positive and of similar size (27.5 → 25.6 pp),
  with the same lower CI bound (≈ +10 pp).

No other item was inspected or removed.

## ITEM-LEVEL PATTERN

| item_id | L_correct | L_false_near_correct | paired_outcome |
|---|---|---|---|
| m3p_01 | 1 | 1 | both_correct |
| m3p_02 | 1 | 0 | true_only |
| m3p_03 | 1 | 1 | both_correct |
| m3p_04 | 1 | 0 | true_only |
| m3p_05 | 1 | 1 | both_correct |
| m3p_06 | 1 | 0 | true_only |
| m3p_07 | 1 | 0 | true_only |
| m3p_08 | 1 | 0 | true_only |
| m3p_09 | 1 | 0 | true_only |
| m3p_10 | 1 | 0 | true_only |
| m3p_11 | 1 | 1 | both_correct |
| m3p_12 | 1 | 1 | both_correct |
| m3p_13 | 0 | 1 | false_only |
| m3p_14 | 0 | 0 | both_wrong |
| m3p_15 | 1 | 0 | true_only |
| m3p_16 | 1 | 0 | true_only |
| m3p_17 | 1 | 0 | true_only |
| m3p_18 | 0 | 1 | false_only |
| m3p_19 | 1 | 1 | both_correct |
| m3p_20 | 1 | 1 | both_correct |
| m3p_21 | 1 | 0 | true_only |
| m3p_22 | 1 | 1 | both_correct |
| m3p_23 | 1 | 1 | both_correct |
| m3p_24 | 1 | 0 | true_only |
| m3p_25 | 1 | 1 | both_correct |
| m3p_26 | 0 | 0 | both_wrong |
| m3p_27 | 1 | 1 | both_correct |
| m3p_28 | 0 | 0 | both_wrong |
| m3p_29 | 1 | 1 | both_correct |
| m3p_30 | 1 | 1 | both_correct |
| m3p_31 | 1 | 1 | both_correct |
| m3p_32 | 1 | 1 | both_correct |
| m3p_33 | 1 | 1 | both_correct |
| m3p_34 | 0 | 0 | both_wrong |
| m3p_35 | 1 | 1 | both_correct |
| m3p_36 | 1 | 1 | both_correct |
| m3p_37 | 1 | 1 | both_correct |
| m3p_38 | 1 | 1 | both_correct |
| m3p_39 | 1 | 0 | true_only |
| m3p_40 | 0 | 0 | both_wrong |

**Totals:** both_correct 20 · true_only 13 · false_only 2 · both_wrong 5.

- **The effect is spread across many items.** Thirteen different items favour the true location, so this is
  not one or two outliers. Removing any single item changes CCA by at most 2.5 pp.
- **Where the true_only items fall:**
  - Error position: they span true-error Steps 2, 3 and 4.
  - Trace length: they span traces of 3 to 7 steps.
- **A clustering worth re-checking (observation only):** 12 of the 13 true_only items are among m3p_01–m3p_24.
  I don't know of any design meaning in the ID order, so this may be chance, but it is worth checking at scale.

## PILOT VERDICT: GO

## WHY

| Criterion | Result |
|---|---|
| A. CCA directionally positive? | **Yes.** +27.5 pp. |
| B. Practically meaningful, not ≈ 0? | **Yes.** About a quarter of the items flip, and the CI lower bound is about +10 pp. |
| C. Multiple true_only items, not one outlier? | **Yes.** 13 true_only vs 2 false_only, spread across items. Robust to removing m3p_06 (+25.6 pp). |
| D. Far-false sensitivity broadly consistent? | **Broadly yes.** Same direction: near +28 pp, far +12 pp on the same 25 items. The far effect is smaller and uncertain, which is plausible for a distant (less misleading) pointer. |
| E. Can the model repair when given the answer? | **Yes.** A = 92.5%. |
| F. Enough variation to make the question identifiable? | **Yes.** The conditions spread from 50% to 92.5%, with clear separation between L0, V, L_false and L. |

- The verdict rests on the full pattern above, not on the p-value.
- **Important qualification.** The GO is for the question "does diagnostic content matter, beyond the mere
  presence of feedback?", and the answer here is clearly yes. The decomposition shows *how* it matters in this
  setup: the false location causes a large harm, while the true location adds little over "your answer is
  wrong". The scaled study should be designed to measure both of these separately rather than report CCA alone.

## WHAT THE PILOT DOES NOT PROVE

- **That true diagnostic information helps beyond "your answer is wrong."** L − V = +2.5 pp (4 vs 3
  discordant pairs) is indistinguishable from zero. It may also be capped by the ceiling, since V is already at
  80% against A at 92.5%.
- **That the effect generalises.** The pilot covers one model (Qwen3-4B), one decoding setup (greedy,
  non-thinking), one error type (M3 single-number calculation slips in GSM8K), and one false-pointer
  construction: the near pointer is always the preceding step, which is correct but usually feeds the error.
- **Confirmatory evidence.** 40 items is small, the CIs are wide, and the p-values are exploratory and not
  adjusted for the several contrasts shown.
- **Why the model behaves this way.** Following an authoritative pointer, sycophancy, or genuine re-checking
  cannot be told apart from final answers alone. The outcome counts hint at both:
  - Under L_false_near, the model returned the corrupted answer 13 times and a different wrong number 4 times.
  - Under L0, it accepted the corrupted answer 20 times.
- **Run-to-run stability.** Greedy decoding was run once, so there is no estimate of how much outcomes would
  change on a rerun.
- **That m3p_06 is or isn't flawed.** The sensitivity analysis only shows that the conclusion does not depend
  on it.

## RECOMMENDED NEXT STEP

Scale up, with a design that separates "true content helps" from "false content hurts". Pre-register both
estimands:
- **Benefit:** L − V
- **Harm:** L_false − V
- **Overall difference:** CCA

Concretely:
1. **Pre-register a scaled study** before generating anything.
   - Estimands: CCA, L − V, L_false − V, and near-vs-far on matched items.
   - Paired tests and paired bootstrap; adjust for the number of contrasts.
   - A power target. The observed discordance (15 of 40 pairs, 13:2) suggests that roughly 150–200 items would
     give a tight CCA interval. Detecting an L − V effect of a few points would need far more, or more headroom.
2. **Create headroom for the true-information gain.** For example:
   - harder items or longer traces;
   - error types where "it's wrong" alone is less sufficient (the M1/M2 types, which were deferred);
   - and/or a weaker or second model.
   Today V is at 80% against a 92.5% ceiling, which leaves little room to detect a benefit of true information.
3. **Keep the near/far false pointers and report them separately.** Make far-false available for more items,
   so the gradient (near harms more than far) can be tested on a larger matched set.
4. **Add a second model,** and optionally a second decoding seed or a sampled condition, to check robustness.
5. **Hold the current scoring, prompts, parser and scorer fixed,** and keep the m3p_06-style ambiguity check as
   a pre-registered item-quality gate rather than a post-hoc exclusion.
