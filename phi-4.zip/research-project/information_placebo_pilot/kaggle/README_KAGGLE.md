# Running the Qwen3-4B smoke test on Kaggle (free GPU)

Nothing here runs on the laptop. The scientific experiment is unchanged: the same frozen prompts, execution
order, smoke items, parser, scorer and provenance checks.

## 1. Upload the bundle as a private Kaggle Dataset
kaggle.com -> Datasets -> New Dataset -> upload `kaggle/pilot_bundle.zip`
(Kaggle unzips it) -> title `info-placebo-pilot-bundle` -> Private -> Create.

## 2. Create the notebook
kaggle.com -> Code -> New Notebook -> File -> Import Notebook -> `kaggle/run_qwen3_pilot.ipynb`.

## 3. Notebook settings (right-hand panel)
- Accelerator: **GPU T4 x2** (recommended; P100 is checked and may be rejected by current PyTorch builds)
- Internet: **On** (requires a phone-verified Kaggle account; needed to download the model and pin packages)
- Add Input -> Your Datasets -> `info-placebo-pilot-bundle`

## 4. Run cells 1 -> 9 in order
Each gate stops with `SystemExit: STOP ...` on failure: GPU, package pins, file hashes, pinned revision
and dtype, chat template, canary. Cell 7 sends exactly 10 independent requests. Nothing runs after cell 9.

## 5. Bring the results back
Results are in `/kaggle/working/results/`:
- `smoke/`: raw_outputs.jsonl, parsed_outputs.jsonl, scored_outputs.jsonl, summary.json, environment.json,
  smoke_diagnostics.json, config.json, run_log.txt, paired_primary.csv
- `diagnostics/`: model_load.json, template_audit.json, canary.json (kept separate from the smoke run)

Download them from the Output panel, or use "Save Version -> Save & Run All" to persist them, and place
them under `kaggle/results/` locally.

## Tokens
None needed: Qwen/Qwen3-4B is public (Apache-2.0). If Hugging Face unexpectedly asks for authentication,
cell 4 stops and prints Kaggle Secrets instructions. Never paste a token into the notebook.

# FULL 225-request run, fresh runtime, Save & Run All (bundle v5, `kaggle/run_full_768_persistent.ipynb`)

Rerun of the frozen pilot (first run's files were lost; NOT a protocol change). v5 = v3 files byte-identical
+ `scripts/kaggle_full_run.py` (persistence only).

1. Datasets -> `info-placebo-pilot-bundle` -> New Version -> upload `kaggle/pilot_bundle.zip` (v5).
2. Code -> New Notebook -> File -> Import Notebook -> `kaggle/run_full_768_persistent.ipynb`.
3. Settings: Accelerator GPU T4 x2; Internet On; Add Input -> `info-placebo-pilot-bundle`.
4. Save Version -> Save & Run All (Commit) -> Save. Do not run cells by hand.
5. The browser can be closed. When the version finishes: notebook -> that version -> Output:
   `results_full_768_FINAL.zip` (+ `.sha256.txt`), `checkpoints/`, `results/`.
