# CELL 4-BRIDGE: session 1 only (bundle v1 still loaded). Run this INSTEAD of re-running Cell 4.
# Fixes the provenance check without re-downloading or reloading:
#   1. verifies the pinned revision on the Hub: HfApi().model_info(repo, revision).sha == pinned
#   2. re-uses the Qwen3-4B object that Cell 4 already loaded onto the GPU (no second 8 GB copy)
#   3. records requested / hub_resolved / transformers commit separately (transformers None is fine)
# If the loaded object is gone, it reloads from the local Hub cache (no download).
import gc, hashlib, json, torch
from huggingface_hub import HfApi
import backends as be
import kaggle_runner as kr

MODEL_ID, PINNED = "Qwen/Qwen3-4B", "3101254bbe4169895668a0e7653c3fd1f313576e"
hub_sha = HfApi().model_info(MODEL_ID, revision=PINNED).sha
print("requested_revision:   ", PINNED)
print("hub_resolved_revision:", hub_sha)
if hub_sha != PINNED:
    raise SystemExit("STOP: the Hub resolves the pinned revision to a different commit")

import warnings
with warnings.catch_warnings():
    warnings.simplefilter("ignore")              # isinstance() over all objects can touch deprecated torch attrs
    found = [o for o in gc.get_objects() if isinstance(o, be.HFTransformersBackend)]
if len(found) > 1:
    raise SystemExit(f"STOP: {len(found)} model objects in memory; restart the session and use bundle v2")
if found:
    BACKEND, how = found[0], "re-used the model object loaded by Cell 4 (no reload, no download)"
else:
    gc.collect(); torch.cuda.empty_cache()
    if torch.cuda.memory_allocated(0) > 1e9:
        raise SystemExit("STOP: GPU memory still occupied; restart the session and use bundle v2")
    _cfg = json.loads((kr.WORK / kr.CONFIG_REL).read_text(encoding="utf-8"))
    BACKEND, how = be.make_backend(_cfg), "reloaded from the local Hub cache (no download)"
print(how)

tch = getattr(BACKEND.model.config, "_commit_hash", None)
if tch is not None and tch != PINNED:
    raise SystemExit(f"STOP: Transformers reports a contradicting commit {tch}")
_orig_effective_settings = BACKEND.effective_settings


def _effective_settings():
    d = _orig_effective_settings()
    d.pop("model_revision_pinned", None)
    d.pop("model_revision_resolved", None)
    d.update(requested_revision=PINNED, hub_resolved_revision=hub_sha, transformers_commit_hash=tch,
             snapshot_path=None,
             revision_verification="HfApi().model_info(repo, revision).sha == requested_revision "
                                   "(session-1 bridge cell; model object from Cell 4 re-used)")
    return d


BACKEND.effective_settings = _effective_settings
eff = BACKEND.effective_settings()
try:
    bridge_src = get_ipython().user_ns["_ih"][-1]
except NameError:
    bridge_src = ""
checks = {"hub_sha_equals_pinned": hub_sha == PINNED,
          "dtype_float16": "float16" in eff["dtype"],
          "device_cuda0": eff["device"] == "cuda:0",
          "enable_thinking_false": eff["enable_thinking"] is False,
          "greedy_num_beams_1": eff["decoding"] == "greedy (do_sample=False, num_beams=1)",
          "max_new_tokens_512": eff["max_new_tokens"] == 512,
          "startup_template_check_passed": bool(BACKEND.template_check.get("enable_thinking_honoured"))}
kr.save(kr.RESULTS / "diagnostics" / "model_load.json", {
    "loaded": kr.now(), "how": how, "requested_revision": PINNED, "hub_resolved_revision": hub_sha,
    "transformers_commit_hash": tch, "snapshot_path": None,
    "bridge_cell_sha256": hashlib.sha256(bridge_src.encode("utf-8")).hexdigest(),
    "bundle_version": 1, "checks": checks, "effective_settings": eff, "versions": BACKEND.versions(),
    "gpu_memory_allocated_gb": round(torch.cuda.memory_allocated(0) / 1e9, 2)})
print("transformers_commit_hash:", tch, "(informational; null is fine)")
print("model dtype:", eff["dtype"], "| device:", eff["device"], "| GPU allocated:",
      round(torch.cuda.memory_allocated(0) / 1e9, 2), "GB")
print("checks:", checks)
if not all(checks.values()):
    raise SystemExit("STOP: a protocol check failed")
print("OK - continue with Cell 5")
