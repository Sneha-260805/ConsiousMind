# CELL 7-768: session 1 only (bundle v1 + Cell 4 bridge already run; Qwen3-4B already on the GPU).
# Controlled protocol change: max_new_tokens 512 -> 768. NOTHING else changes.
#   * re-uses the loaded BACKEND (no reload, no download)
#   * archives the 512-token smoke run unchanged as results/smoke_512/
#   * re-generates the SAME 10 requests from scratch into results/smoke_768/ (never appends/resumes)
#   * prints the diagnostics and the GO / NO-GO gate. It does NOT launch the 225-request pilot.
import hashlib, json, re, shutil, statistics
import torch
import kaggle_runner as kr
import pilot_common as pc

NEW_MAX, OLD_MAX = 768, 512
if "BACKEND" not in globals():
    raise SystemExit("STOP: BACKEND not in this session; the loaded model is gone (use bundle v3 in a fresh session)")

# ---- 1. archive the 512-token smoke run (moved, not modified)
old_dir, arch_dir, new_dir = kr.RESULTS / "smoke", kr.RESULTS / "smoke_512", kr.RESULTS / "smoke_768"
if new_dir.exists():
    raise SystemExit("STOP: results/smoke_768 already exists; refusing to append to it")
if old_dir.exists():
    if arch_dir.exists():
        raise SystemExit("STOP: both results/smoke and results/smoke_512 exist; resolve manually")
    shutil.move(str(old_dir), str(arch_dir))
elif not arch_dir.exists():
    raise SystemExit("STOP: no 512-token smoke run found to archive")
old_keys = [json.loads(l)["request_key"] for l in (arch_dir / "raw_outputs.jsonl").read_text(encoding="utf-8").splitlines()]
print("archived 512-token run:", arch_dir, "|", len(old_keys), "rows")

# ---- 2. change ONLY max_new_tokens (config file used for run records + the live backend)
cfg_path = kr.WORK / kr.CONFIG_REL
old_bytes = cfg_path.read_bytes()
cfg_old = json.loads(old_bytes)
if cfg_old["max_new_tokens"] != OLD_MAX or BACKEND.cfg["max_new_tokens"] != OLD_MAX:
    raise SystemExit(f"STOP: expected max_new_tokens {OLD_MAX} before the change")
eff_before, bcfg_before = BACKEND.effective_settings(), dict(BACKEND.cfg)
cfg_new = dict(cfg_old, max_new_tokens=NEW_MAX)
cfg_path.write_text(json.dumps(cfg_new, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
BACKEND.cfg["max_new_tokens"] = NEW_MAX
eff_after = BACKEND.effective_settings()
diff = lambda a, b: sorted(k for k in set(a) | set(b) if a.get(k) != b.get(k))
changes = {"config_file": diff(cfg_old, cfg_new), "backend_cfg": diff(bcfg_before, BACKEND.cfg),
           "effective_settings": diff(eff_before, eff_after)}
print("changed keys:", changes)
if any(v != ["max_new_tokens"] for v in changes.values()):
    raise SystemExit("STOP: something other than max_new_tokens changed")
checks = {"max_new_tokens_768": eff_after["max_new_tokens"] == NEW_MAX,
          "pinned_revision": eff_after.get("hub_resolved_revision") == "3101254bbe4169895668a0e7653c3fd1f313576e",
          "dtype_float16": "float16" in eff_after["dtype"], "device_cuda0": eff_after["device"] == "cuda:0",
          "greedy_num_beams_1": eff_after["decoding"] == "greedy (do_sample=False, num_beams=1)",
          "enable_thinking_false": eff_after["enable_thinking"] is False}
print("settings:", checks)
if not all(checks.values()):
    raise SystemExit("STOP: protocol check failed")
try:
    _src = get_ipython().user_ns["_ih"][-1]
except NameError:
    _src = ""
kr.save(kr.RESULTS / "diagnostics" / "protocol_change_max_new_tokens_768.json", {
    "changed": kr.now(), "change": {"max_new_tokens": [OLD_MAX, NEW_MAX]}, "changed_keys": changes,
    "config_sha256_before": hashlib.sha256(old_bytes).hexdigest(),
    "config_sha256_after": hashlib.sha256(cfg_path.read_bytes()).hexdigest(),
    "model_reused_no_reload": True, "patch_cell_sha256": hashlib.sha256(_src.encode("utf-8")).hexdigest(),
    "archived_512_run": str(arch_dir), "checks": checks})

# ---- 3. the SAME 10 requests, regenerated from scratch under 768
SMOKE768 = kr.smoke_test(BACKEND, run_id="smoke_768")
DIAG768 = kr.score_and_diagnose(SMOKE768, globals().get("GPU"), globals().get("VERSIONS"))

# ---- 4. per-response flags + extra metrics
raw = [json.loads(l) for l in (SMOKE768 / "raw_outputs.jsonl").read_text(encoding="utf-8").splitlines()]
scored = {s["request_key"]: s for s in
          (json.loads(l) for l in (SMOKE768 / "scored_outputs.jsonl").read_text(encoding="utf-8").splitlines())}
frozen = {r["request_key"]: r["prompt"] for r in pc.load_requests()}
toks = [r["model_metadata"]["response"].get("new_tokens") or 0 for r in raw]
flags = []
for r in raw:
    m, s = r["model_metadata"]["response"], scored[r["request_key"]]
    f = {"hits_768": m.get("finish_reason") == "length" or (m.get("new_tokens") or 0) >= NEW_MAX,
         "numeric_parse_failed": s["numeric_parse_failure"],
         "lacks_final_answer": re.search(r"final_answer\s*:", r["raw_response"], re.I) is None,
         "visible_thinking": "<think>" in r["raw_response"] or "</think>" in r["raw_response"]
                             or bool(m.get("think_tag_in_output"))}
    if any(f.values()):
        flags.append({"item_id": r["item_id"], "condition": r["analysis_condition"],
                      "new_tokens": m.get("new_tokens"), **{k: v for k, v in f.items() if v}})
report = {"LABEL": "PIPELINE CHECK ONLY - NOT AN EXPERIMENTAL RESULT - N=2 ITEMS",
          **{k: DIAG768[k] for k in ("requested", "completed", "transport_failures")},
          "retries": sum(r["attempt_count"] - 1 for r in raw),
          **{k: DIAG768[k] for k in ("numeric_parse_ok", "numeric_parse_failures", "strict_format_ok",
                                     "strict_format_failures", "hit_max_new_tokens", "think_tag_in_any_output",
                                     "latency_mean_s", "latency_median_s", "generated_tokens_mean")},
          "generated_tokens_max": max(toks), "gpu_peak_memory_gb": DIAG768["gpu_peak_memory_gb"],
          "flagged_responses": flags}
same_requests = sorted(r["request_key"] for r in raw) == sorted(old_keys)
gate = {"completed_10_of_10": report["completed"] == 10,
        "transport_failures_0": report["transport_failures"] == 0,
        "numeric_parse_10_of_10": report["numeric_parse_ok"] == 10,
        "hit_max_new_tokens_0": report["hit_max_new_tokens"] == 0 and not any(f.get("hits_768") for f in flags),
        "no_visible_thinking": report["think_tag_in_any_output"] is False
                               and not any(f.get("visible_thinking") for f in flags),
        "prompts_byte_identical_to_frozen": all(r["prompt"] == frozen[r["request_key"]] for r in raw),
        "same_10_requests_as_512_run": same_requests}
report["gate"] = gate
report["decision"] = "GO (pending your approval; the 225-request pilot is NOT launched)" if all(gate.values()) else "NO-GO"
kr.save(SMOKE768 / "smoke_768_report.json", report)
print(json.dumps(report, indent=2))
print("\nDECISION:", report["decision"])
