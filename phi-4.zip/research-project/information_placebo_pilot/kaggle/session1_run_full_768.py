# CELL FULL-768: session 1 only (bundle v1 + Cell 4 bridge + 768 patch; Qwen3-4B already on the GPU).
# Runs the frozen 225-request pilot (200 primary + 25 L_false_far) into results/full_768/, re-using the loaded
# model: no reload, no download, backend untouched (only verified). Crash-safe: re-run THIS SAME CELL to resume;
# completed requests are never regenerated. Model outputs are never retried (only the generation call itself
# would be, and the frozen config allows 1 attempt). Stops after generation + scoring: no analysis here.
import argparse, hashlib, inspect, json, re, statistics, threading, time
from datetime import datetime, timezone
import torch
from huggingface_hub import HfApi
import kaggle_runner as kr
import pilot_common as pc
import run_pilot as rp

PIN = "3101254bbe4169895668a0e7653c3fd1f313576e"
ORDER_SHA = "2b6e7e0f0895b002976358df618cba33c8bc6dbf38a31f0c9567dc684466ec91"
RUN_ID, N_TOTAL = "full_768", 225
EXPECTED = {"L0": 40, "V": 40, "L_false_near": 40, "L": 40, "A": 40, "L_false_far": 25}
RUN_DIR = kr.RESULTS / RUN_ID
cell_t0 = time.time()


def stop(msg):
    raise SystemExit("STOP: " + msg)


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


# ============================================================ PRE-FLIGHT (re-run in full on every resume)
if "BACKEND" not in globals():
    stop("BACKEND not in this session (the loaded model is gone); do not reload here")
pf = {}
rep_path = kr.RESULTS / "smoke_768" / "smoke_768_report.json"
pf["01_smoke_768_report_exists"] = rep_path.exists()
smoke = json.loads(rep_path.read_text(encoding="utf-8")) if rep_path.exists() else {}
pf["02_smoke_768_decision_GO"] = str(smoke.get("decision", "")).startswith("GO") and bool(smoke.get("gate")) \
    and all(smoke["gate"].values())
cfg_path = kr.WORK / kr.CONFIG_REL
cfg, cfg_sha = json.loads(cfg_path.read_text(encoding="utf-8")), sha(cfg_path)
change_path = kr.RESULTS / "diagnostics" / "protocol_change_max_new_tokens_768.json"
change = json.loads(change_path.read_text(encoding="utf-8")) if change_path.exists() else {}
eff = BACKEND.effective_settings()
pf["03_max_new_tokens_768"] = cfg["max_new_tokens"] == BACKEND.cfg["max_new_tokens"] == eff["max_new_tokens"] == 768
pf["03b_config_hash_matches_768_change_record"] = cfg_sha == change.get("config_sha256_after")
pf["03c_backend_cfg_identical_to_config_file"] = BACKEND.cfg == cfg
hub_sha = HfApi().model_info("Qwen/Qwen3-4B", revision=PIN).sha
pf["04_hub_revision_exact"] = hub_sha == PIN == cfg["model_revision"] == eff.get("hub_resolved_revision") \
    and cfg["model"] == "Qwen/Qwen3-4B"
pf["05_dtype_fp16"] = BACKEND.model.dtype == torch.float16 and "float16" in eff["dtype"] and cfg["dtype"] == "float16"
pf["06_device_cuda0"] = str(BACKEND.model.device) == "cuda:0" == eff["device"] == cfg["device"]
pf["07_enable_thinking_false"] = BACKEND.enable_thinking is False and eff["enable_thinking"] is False \
    and cfg["enable_thinking"] is False
gen_src = inspect.getsource(type(BACKEND).generate)
pf["08_decoding_greedy_temp0"] = ("do_sample=False, num_beams=1, temperature=None" in gen_src
                                  and "generate" not in vars(BACKEND)          # class method, not monkey-patched
                                  and eff["decoding"] == "greedy (do_sample=False, num_beams=1)"
                                  and cfg["temperature"] == 0 and cfg["max_attempts"] == 1)
pf["09_frozen_file_hashes"] = all(sha(kr.WORK / rel) == h for rel, h in kr.FROZEN_SHA256.items())
requests = pc.load_requests()
order_doc = pc.order_document(requests, pc.input_hashes())
order_file = json.loads(pc.ORDER_FILE.read_text(encoding="utf-8"))
pf["10_execution_order_hash"] = order_doc["order_sha256"] == order_file["order_sha256"] == ORDER_SHA
tc, render_ok, roundtrip_ok = BACKEND.template_check, True, True
for r in requests:                                           # all 225 frozen prompts, rendered + tokenised only
    text = BACKEND.render(r["prompt"], False)
    render_ok &= text == tc["prefix"] + r["prompt"] + tc["suffix"] and text.count(r["prompt"]) == 1
    ids = BACKEND.tok(text, add_special_tokens=False).input_ids
    roundtrip_ok &= BACKEND.tok.decode(ids, skip_special_tokens=False, clean_up_tokenization_spaces=False) == text
pf["11_frozen_prompt_bytes_unchanged_by_request_construction"] = bool(render_ok and roundtrip_ok)
selected = rp.select(requests, order_doc["order"], "full")
counts = {c: sum(r["analysis_condition"] == c for r in selected) for c in EXPECTED}
pf["12_selection_225_exact"] = (len(selected) == N_TOTAL == len({r["request_key"] for r in selected})
                                and counts == EXPECTED)
if (RUN_DIR / "config.json").exists():                       # resume: everything must be unchanged
    prev = json.loads((RUN_DIR / "config.json").read_text(encoding="utf-8"))
    pf["13_resume_config_unchanged"] = (prev["model_config"] == cfg and prev["input_sha256"] == pc.input_hashes()
                                        and prev["execution_order"]["order_sha256"] == ORDER_SHA
                                        and [x["request_key"] for x in prev["selected_requests"]]
                                        == [r["request_key"] for r in selected])
resuming = (RUN_DIR / "raw_outputs.jsonl").exists()
print("PRE-FLIGHT CHECK")
for k, v in pf.items():
    print(f"  {'PASS' if v else 'FAIL'}  {k}")
kr.save(kr.RESULTS / "diagnostics" / f"full_768_preflight_{int(time.time())}.json",
        {"checked": kr.now(), "checks": pf, "config_sha256": cfg_sha, "hub_resolved_revision": hub_sha,
         "resuming": resuming})
if not all(pf.values()):
    stop("pre-flight failed; nothing was sent")

# ============================================================ RUN (crash-safe, resumable)
raw_path = RUN_DIR / "raw_outputs.jsonl"


def completed_rows():
    if not raw_path.exists():
        return []
    out = []
    for line in raw_path.read_text(encoding="utf-8").splitlines():
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            pass                                             # torn final line; run_pilot repairs it on resume
    return out


n_at_start = len(completed_rows())
print(f"\n{'RESUMING' if resuming else 'STARTING'} {RUN_ID}: {n_at_start}/{N_TOTAL} already completed\n", flush=True)
stop_evt = threading.Event()


def progress():
    t0, next_mark = time.time(), max(1, (n_at_start // 10 + 1) * 10) if n_at_start else 1
    while not stop_evt.wait(5):
        rows = completed_rows()
        n = len(rows)
        if n >= next_mark or n == N_TOTAL:
            done_now = n - n_at_start
            el = time.time() - t0
            eta = (N_TOTAL - n) * (el / done_now) if done_now else float("nan")
            print(f"[{n}/{N_TOTAL}] completed {n} | elapsed {el / 60:.1f} min | recent latency "
                  f"{rows[-1]['latency_seconds']:.1f} s | ~{eta / 60:.0f} min remaining", flush=True)
            next_mark = (n // 10 + 1) * 10
            if n == N_TOTAL:
                return


torch.cuda.reset_peak_memory_stats(0)
mon = threading.Thread(target=progress, daemon=True)
mon.start()
args = argparse.Namespace(config=str(cfg_path), run_id=RUN_ID, mode="full", dry_run=False, sequential=False,
                          max_requests=None, output_root=str(kr.RESULTS))
try:
    run_dir, stats = rp.execute(args, backend=BACKEND)
except SystemExit:
    raise                                                    # resume refusal / lock: nothing generated
except BaseException as e:                                   # CUDA / runtime failure or manual interrupt
    stop_evt.set()
    mon.join(timeout=10)
    n = len(completed_rows())
    kr.save(RUN_DIR / f"runtime_failure_{int(time.time())}.json",
            {"failed": kr.now(), "error": f"{type(e).__name__}: {e}", "completed_rows_on_disk": n})
    stop(f"{type(e).__name__}: {e}. {n}/{N_TOTAL} completed rows are safely on disk. Re-run THIS SAME CELL to "
         "resume (completed requests are not regenerated). If the kernel died, the model is gone: ask before "
         "doing anything else.")
finally:
    stop_evt.set()
mon.join(timeout=10)
_rows = completed_rows()
print(f"[{len(_rows)}/{N_TOTAL}] generation finished | this cell {(time.time() - cell_t0) / 60:.1f} min", flush=True)

# ============================================================ POST-RUN PIPELINE CHECK (no interpretation)
raw = completed_rows()
scored = [json.loads(l) for l in (RUN_DIR / "scored_outputs.jsonl").read_text(encoding="utf-8").splitlines()]
by_key = {s["request_key"]: s for s in scored}
frozen = {r["request_key"]: r["prompt"] for r in requests}
toks = [r["model_metadata"]["response"].get("new_tokens") or 0 for r in raw]
lat = [r["latency_seconds"] for r in raw]
tf = RUN_DIR / "transport_failures.jsonl"
runtime_failures = sorted(p.name for p in RUN_DIR.glob("runtime_failure_*.json"))
flags = {"parse_failed": [], "hit_768": [], "lacks_final_answer": [], "visible_thinking": []}
for r in raw:
    m, s, tag = r["model_metadata"]["response"], by_key[r["request_key"]], f"{r['item_id']}/{r['analysis_condition']}"
    if s["numeric_parse_failure"]:
        flags["parse_failed"].append(tag)
    if m.get("finish_reason") == "length" or (m.get("new_tokens") or 0) >= 768:
        flags["hit_768"].append(tag)                         # recorded only; never regenerated
    if re.search(r"final_answer\s*:", r["raw_response"], re.I) is None:
        flags["lacks_final_answer"].append(tag)
    if "<think>" in r["raw_response"] or "</think>" in r["raw_response"] or m.get("think_tag_in_output"):
        flags["visible_thinking"].append(tag)
ts = sorted(datetime.fromisoformat(r["timestamp"]) for r in raw)
diag = {
    "LABEL": "PIPELINE / INTEGRITY CHECK ONLY - no scientific interpretation",
    "requested": N_TOTAL, "completed": len(raw),
    "completed_keys_match_plan": sorted(r["request_key"] for r in raw) == sorted(x["request_key"] for x in selected),
    "duplicate_keys": len(raw) - len({r["request_key"] for r in raw}),
    "transport_failures": len(tf.read_text(encoding="utf-8").splitlines()) if tf.exists() else 0,
    "runtime_failures_recorded": runtime_failures,
    "retries": sum(r["attempt_count"] - 1 for r in raw),
    "numeric_parse_ok": sum(not s["numeric_parse_failure"] for s in scored),
    "numeric_parse_failures": sum(s["numeric_parse_failure"] for s in scored),
    "strict_format_ok": sum(not s["strict_format_failure"] for s in scored),
    "strict_format_failures": sum(s["strict_format_failure"] for s in scored),
    "final_line_fallback_count": sum(s["numeric_parse_source"] == "final_line_fallback" for s in scored),
    "hit_max_new_tokens": len(flags["hit_768"]),
    "think_tag_in_any_output": bool(flags["visible_thinking"]),
    "generated_tokens_mean": round(statistics.mean(toks), 1), "generated_tokens_median": statistics.median(toks),
    "generated_tokens_max": max(toks),
    "latency_mean_s": round(statistics.mean(lat), 2), "latency_median_s": round(statistics.median(lat), 2),
    "generation_time_total_min": round(sum(lat) / 60, 1),
    "wall_clock_first_to_last_row_min": round((ts[-1] - ts[0]).total_seconds() / 60, 1),
    "this_cell_wall_clock_min": round((time.time() - cell_t0) / 60, 1),
    "gpu_peak_memory_gb": round(torch.cuda.max_memory_allocated(0) / 1e9, 2),
    "condition_counts_completed": {c: sum(r["analysis_condition"] == c for r in raw) for c in EXPECTED},
    "prompts_byte_identical_to_frozen": all(r["prompt"] == frozen[r["request_key"]] for r in raw),
    "all_rows_recorded_max_new_tokens_768": all(r["model_metadata"]["max_new_tokens"] == 768 for r in raw),
    "flagged": flags,
    "provenance": {"model": cfg["model"], "requested_revision": PIN, "hub_resolved_revision": hub_sha,
                   "transformers_commit_hash": eff.get("transformers_commit_hash"), "dtype": eff["dtype"],
                   "device": eff["device"], "config_sha256": cfg_sha, "execution_order_sha256": ORDER_SHA,
                   "input_sha256": pc.input_hashes(), "resumed": resuming or bool(runtime_failures)},
}
diag["ready_for_analysis"] = (diag["completed"] == N_TOTAL and diag["completed_keys_match_plan"]
                              and diag["duplicate_keys"] == 0 and diag["transport_failures"] == 0
                              and diag["prompts_byte_identical_to_frozen"]
                              and diag["all_rows_recorded_max_new_tokens_768"] and all(pf.values()))
kr.save(RUN_DIR / "full_run_diagnostics.json", diag)
kr.save(RUN_DIR / "environment.json", kr.environment_record(globals().get("GPU"), globals().get("VERSIONS")))

files = sorted(p.name for p in RUN_DIR.iterdir())
print("\n" + "=" * 70)
print("PRE-FLIGHT CHECK      ", "PASS (all", len(pf), "checks)")
print("REQUESTS PLANNED      ", N_TOTAL, counts)
print("REQUESTS COMPLETED    ", diag["completed"], "| keys match plan:", diag["completed_keys_match_plan"],
      "| duplicates:", diag["duplicate_keys"])
print("RESUME STATUS         ", "resumed" if diag["provenance"]["resumed"] else "single uninterrupted pass",
      "| runtime failures recorded:", runtime_failures or "none", "| transport failures:",
      diag["transport_failures"], "| retries:", diag["retries"])
print("PARSE RESULTS         ", f"numeric ok {diag['numeric_parse_ok']} / failures {diag['numeric_parse_failures']}"
      f" | final-line fallback {diag['final_line_fallback_count']} | failed: {flags['parse_failed'] or 'none'}")
print("FORMAT RESULTS        ", f"strict ok {diag['strict_format_ok']} / failures {diag['strict_format_failures']}"
      f" | lacks FINAL_ANSWER: {flags['lacks_final_answer'] or 'none'}")
print("TRUNCATIONS           ", diag["hit_max_new_tokens"], flags["hit_768"] or "none")
print("VISIBLE THINKING      ", diag["think_tag_in_any_output"], flags["visible_thinking"] or "none")
print("LATENCY               ", f"mean {diag['latency_mean_s']} s | median {diag['latency_median_s']} s | "
      f"tokens mean {diag['generated_tokens_mean']} median {diag['generated_tokens_median']} max "
      f"{diag['generated_tokens_max']} | generation {diag['generation_time_total_min']} min | wall "
      f"{diag['wall_clock_first_to_last_row_min']} min")
print("GPU MEMORY            ", diag["gpu_peak_memory_gb"], "GB peak")
print("FILES CREATED         ", RUN_DIR, files)
print("PROVENANCE            ", json.dumps(diag["provenance"]))
problems = [k for k in ("completed_keys_match_plan", "prompts_byte_identical_to_frozen",
                        "all_rows_recorded_max_new_tokens_768") if not diag[k]]
problems += ["duplicates"] if diag["duplicate_keys"] else []
problems += ["transport failures"] if diag["transport_failures"] else []
print("PROBLEMS              ", problems or "none (parse failures / truncations above are outcomes, not problems)")
print("READY FOR ANALYSIS:   ", "YES" if diag["ready_for_analysis"] else "NO")
print("=" * 70, "\nSTOP. No RR / CCA / statistics computed. Download /kaggle/working/results/ for the audit.")
