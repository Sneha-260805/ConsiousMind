"""Feasibility analysis of the 40-item / 225-request Qwen3-4B pilot (no model inference).

  python scripts/analyze_pilot.py --run-dir kaggle/results/full_768_FINAL/results/full_768

Reads only the frozen outputs (raw_outputs.jsonl, scored_outputs.jsonl, config.json). Repair = the frozen
scorer's is_gold_correct (numeric parsed answer == gold; non-numeric / unparseable / truncated = not repaired).
Writes analysis/pilot_primary_results.csv, pilot_paired_L_vs_false.csv, pilot_far_sensitivity.csv,
pilot_summary.json. Exploratory pilot inference only (exact McNemar, paired bootstrap, seed 2026).
"""
import argparse
import csv
import json
import random
from math import comb
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "analysis"
PRIMARY = ["L0", "V", "L_false_near", "L", "A"]
EXPECTED = {"L0": 40, "V": 40, "L_false_near": 40, "L": 40, "A": 40, "L_false_far": 25}
FROZEN = {"model": "Qwen/Qwen3-4B", "model_revision": "3101254bbe4169895668a0e7653c3fd1f313576e",
          "dtype": "float16", "device": "cuda:0", "temperature": 0, "enable_thinking": False,
          "max_new_tokens": 768, "max_attempts": 1, "decoding": "greedy", "seed": 2026}
FROZEN_INPUTS = {
    "m3_pilot_40.json": "2f6ba3f034a3aeb7c57cd5245b59d692aa3b7d95762b5d6d1c02e9b143eec190",
    "m3_pilot_40_conditions.jsonl": "b664f96d4a531a95de965ab11f52ed4b5fd183ddde99c700960a1f6dc2b426a1",
    "m3_pilot_40_far_false_sensitivity.jsonl": "d7327d59dff90b2a9df83fb9c3ac4872ad83d82c3a6271888fa4eb846ef2ca16"}
ORDER_SHA = "2b6e7e0f0895b002976358df618cba33c8bc6dbf38a31f0c9567dc684466ec91"
SEED, N_BOOT = 2026, 10000
AMBIGUOUS_ITEM = "m3p_06"


def jl(p):
    return [json.loads(l) for l in Path(p).read_text(encoding="utf-8").splitlines() if l.strip()]


def verify(run_dir):
    raw, scored = jl(run_dir / "raw_outputs.jsonl"), jl(run_dir / "scored_outputs.jsonl")
    cfg = json.loads((run_dir / "config.json").read_text(encoding="utf-8"))
    tf = run_dir / "transport_failures.jsonl"
    keys = [r["request_key"] for r in raw]
    counts = {c: sum(r["analysis_condition"] == c for r in raw) for c in EXPECTED}
    mc = cfg["model_config"]
    checks = {
        "raw_rows_225": len(raw) == 225,
        "scored_rows_225": len(scored) == 225,
        "unique_request_keys_225": len(set(keys)) == 225,
        "no_duplicates": len(keys) == len(set(keys)),
        "scored_keys_equal_raw_keys": sorted(keys) == sorted(s["request_key"] for s in scored),
        "condition_counts_exact": counts == EXPECTED,
        "zero_transport_failures": not tf.exists() or not tf.read_text(encoding="utf-8").strip(),
        "all_completed_single_attempt": all(r["status"] == "completed" and r["attempt_count"] == 1 for r in raw),
        "config_matches_frozen_protocol": all(mc.get(k) == v for k, v in FROZEN.items()),
        "rows_record_frozen_settings": all(
            r["model_metadata"]["model"] == FROZEN["model"]
            and r["model_metadata"]["model_revision"] == FROZEN["model_revision"]
            and r["model_metadata"]["max_new_tokens"] == 768 and r["model_metadata"]["temperature"] == 0
            and r["model_metadata"]["enable_thinking"] is False and r["model_metadata"]["device"] == "cuda:0"
            for r in raw),
        "input_hashes_frozen": cfg["input_sha256"] == FROZEN_INPUTS,
        "execution_order_frozen": cfg["execution_order"]["order_sha256"] == ORDER_SHA,
        "not_test_only": cfg.get("TEST_ONLY") is False and not any(r["test_only"] for r in raw),
        "is_gold_correct_consistent_with_rule": all(
            s["is_gold_correct"] == (s["numeric_parse_status"] == "ok"
                                     and float(s["numeric_parsed_answer"]) == float(s["gold_answer"]))
            for s in scored),
    }
    return checks, raw, scored, counts


def table(scored):
    t = {}
    for s in scored:
        t.setdefault(s["item_id"], {})[s["analysis_condition"]] = s
    return t


def rr(t, items, cond):
    k = sum(t[i][cond]["is_gold_correct"] for i in items)
    return {"correct": k, "n": len(items), "rate": k / len(items)}


def paired(t, items, a, b):
    """a = 'true' condition, b = comparison. Counts of the 2x2 paired table."""
    c = {"both_correct": 0, "both_wrong": 0, "a_only": 0, "b_only": 0}
    for i in items:
        x, y = t[i][a]["is_gold_correct"], t[i][b]["is_gold_correct"]
        c["both_correct" if x and y else "both_wrong" if not x and not y else "a_only" if x else "b_only"] += 1
    return c


def mcnemar_exact(b, c):
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    return min(1.0, 2 * sum(comb(n, j) for j in range(k + 1)) / 2 ** n)


def bootstrap_diff(t, items, a, b, seed=SEED, n_boot=N_BOOT):
    rng = random.Random(seed)
    d = [int(t[i][a]["is_gold_correct"]) - int(t[i][b]["is_gold_correct"]) for i in items]
    n = len(d)
    stats = sorted(sum(d[rng.randrange(n)] for _ in range(n)) / n for _ in range(n_boot))
    lo, hi = stats[int(0.025 * n_boot)], stats[int(0.975 * n_boot) - 1]
    return {"seed": seed, "resamples": n_boot, "method": "paired item bootstrap, percentile",
            "ci95": [lo, hi], "share_resamples_le_0": sum(s <= 0 for s in stats) / n_boot}


def contrast(t, items, a, b, boot=False):
    ra, rb = rr(t, items, a), rr(t, items, b)
    p = paired(t, items, a, b)
    out = {"comparison": f"{a} - {b}", "n_items": len(items), "rate_a": ra["rate"], "rate_b": rb["rate"],
           "diff": ra["rate"] - rb["rate"], "diff_pp": round(100 * (ra["rate"] - rb["rate"]), 1),
           "paired": {"both_correct": p["both_correct"], "both_wrong": p["both_wrong"],
                      f"{a}_only": p["a_only"], f"{b}_only": p["b_only"]},
           "mcnemar_exact_p_two_sided": mcnemar_exact(p["a_only"], p["b_only"])}
    if boot:
        out["bootstrap"] = bootstrap_diff(t, items, a, b)
    return out


def write_csv(path, rows):
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir", required=True)
    ap.add_argument("--zip-sha256", default=None)
    a = ap.parse_args()
    run_dir = Path(a.run_dir)
    checks, raw, scored, counts = verify(run_dir)
    print("DATA INTEGRITY")
    for k, v in checks.items():
        print(f"  {'PASS' if v else 'FAIL'}  {k}")
    if not all(checks.values()):
        raise SystemExit("STOP: data integrity check failed; no results computed")

    t = table(scored)
    items = sorted(i for i in t if all(c in t[i] for c in PRIMARY))
    far = sorted(i for i in t if "L_false_far" in t[i])
    assert len(items) == 40 and len(far) == 25 and set(far) <= set(items)
    OUT.mkdir(exist_ok=True)

    # 2. primary rates (+ descriptive outcome breakdown from the frozen scorer)
    prim_rows, prim = [], {}
    for c in PRIMARY:
        r = rr(t, items, c)
        prim[c] = r
        rows = [t[i][c] for i in items]
        prim_rows.append({"condition": c, "correct": r["correct"], "n": r["n"], "repair_rate": round(r["rate"], 4),
                          "percent": round(100 * r["rate"], 1),
                          "corrupted_answer": sum(s["is_corrupted_answer"] for s in rows),
                          "other_wrong_numeric": sum(s["other_wrong_answer"] for s in rows),
                          "no_numeric_answer": sum(s["numeric_parse_failure"] for s in rows)})
    write_csv(OUT / "pilot_primary_results.csv", prim_rows)

    # 3-4. CCA
    cca = contrast(t, items, "L", "L_false_near", boot=True)

    # 8. item-level table
    lab = {(True, True): "both_correct", (False, False): "both_wrong", (True, False): "true_only",
           (False, True): "false_only"}
    item_rows = [{"item_id": i, "L_correct": int(t[i]["L"]["is_gold_correct"]),
                  "L_false_near_correct": int(t[i]["L_false_near"]["is_gold_correct"]),
                  "paired_outcome": lab[(t[i]["L"]["is_gold_correct"], t[i]["L_false_near"]["is_gold_correct"])]}
                 for i in items]
    write_csv(OUT / "pilot_paired_L_vs_false.csv", item_rows)

    # 5. mechanism decomposition
    mech = {"verification_effect_V_minus_L0": contrast(t, items, "V", "L0"),
            "correct_location_increment_L_minus_V": contrast(t, items, "L", "V"),
            "false_location_increment_L_false_near_minus_V": contrast(t, items, "L_false_near", "V"),
            "correct_content_advantage_L_minus_L_false_near": {k: v for k, v in cca.items() if k != "bootstrap"},
            "answer_ceiling_A": prim["A"]}

    # 6. far-false sensitivity on the same 25 items
    far_rates = {c: rr(t, far, c) for c in ["L0", "V", "L_false_near", "L", "A", "L_false_far"]}
    cca_near_25 = contrast(t, far, "L", "L_false_near", boot=True)
    cca_far_25 = contrast(t, far, "L", "L_false_far", boot=True)
    near_vs_far_25 = contrast(t, far, "L_false_near", "L_false_far")
    far_rows = [{"condition": c, "correct": r["correct"], "n": r["n"], "repair_rate": round(r["rate"], 4),
                 "percent": round(100 * r["rate"], 1)} for c, r in far_rates.items()]
    for name, x in [("CCA_near_25 (L - L_false_near)", cca_near_25), ("CCA_far_25 (L - L_false_far)", cca_far_25)]:
        far_rows.append({"condition": name, "correct": "", "n": 25, "repair_rate": round(x["diff"], 4),
                         "percent": x["diff_pp"]})
    write_csv(OUT / "pilot_far_sensitivity.csv", far_rows)

    # 7. m3p_06 sensitivity
    ex = [i for i in items if i != AMBIGUOUS_ITEM]
    sens = {"LABEL": "POST-HOC AMBIGUITY SENSITIVITY - NOT PRIMARY ANALYSIS", "excluded": AMBIGUOUS_ITEM,
            "n_items": len(ex), "rates": {c: rr(t, ex, c) for c in PRIMARY},
            "cca": contrast(t, ex, "L", "L_false_near", boot=True),
            "m3p_06_outcomes": {c: {"correct": t[AMBIGUOUS_ITEM][c]["is_gold_correct"],
                                    "numeric_parse_status": t[AMBIGUOUS_ITEM][c]["numeric_parse_status"],
                                    "parsed": t[AMBIGUOUS_ITEM][c]["numeric_parsed_answer"]}
                                for c in PRIMARY + ["L_false_far"] if c in t[AMBIGUOUS_ITEM]}}

    summary = {
        "LABEL": "FEASIBILITY PILOT - exploratory; not confirmatory evidence",
        "source": {"run_dir": str(run_dir), "final_zip_sha256": a.zip_sha256},
        "integrity_checks": checks, "condition_counts": counts,
        "scoring": "frozen scorer is_gold_correct (numeric parsed answer == gold); unchanged",
        "primary_rates": prim, "cca": cca, "item_pattern": {k: sum(r["paired_outcome"] == k for r in item_rows)
                                                             for k in lab.values()},
        "true_only_items": [r["item_id"] for r in item_rows if r["paired_outcome"] == "true_only"],
        "false_only_items": [r["item_id"] for r in item_rows if r["paired_outcome"] == "false_only"],
        "mechanism": mech,
        "far_sensitivity_25": {"items": far, "rates": far_rates, "cca_near_25": cca_near_25,
                               "cca_far_25": cca_far_25, "near_minus_far_25": near_vs_far_25},
        "m3p_06_sensitivity": sens,
        "flags_from_run": {"truncated_at_768": [f"{r['item_id']}/{r['analysis_condition']}" for r in raw
                                                if r["model_metadata"]["response"].get("finish_reason") == "length"],
                           "no_numeric_answer": [f"{s['item_id']}/{s['analysis_condition']}" for s in scored
                                                 if s["numeric_parse_failure"]]},
    }
    (OUT / "pilot_summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: summary[k] for k in ("primary_rates", "item_pattern", "true_only_items",
                                               "false_only_items")}, indent=1))
    print("CCA", json.dumps(cca, indent=1))
    print("MECH", json.dumps(mech, indent=1))
    print("FAR", json.dumps(summary["far_sensitivity_25"], indent=1))
    print("SENS", json.dumps(sens, indent=1))
    print("FLAGS", summary["flags_from_run"])
    print("primary breakdown", prim_rows)


if __name__ == "__main__":
    main()
