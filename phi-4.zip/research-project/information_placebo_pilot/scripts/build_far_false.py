"""Stage 7: L_false_far sensitivity condition for the 40-item M3 pilot (no model calls).

The primary file data/pilot/m3_pilot_40_conditions.jsonl is read, never written. Its condition
"L_false" is the primary matched control and is referred to as L_false_near from now on; the alias is
recorded in the manifest instead of rewriting the primary file, so its provenance hash stays fixed.

For each item a far false location is searched among steps 1 .. true_step-2 (so it is never the
immediate predecessor). Candidates are tiered:
  Tier 1: not a direct parent of the error step and not an ancestor of it in the dependency graph
  Tier 2: not a direct parent, but an indirect ancestor
  Tier 3: a direct parent (still >= 2 steps before the error)
The best available tier wins; within that tier the LATEST step (smallest distance >= 2) is chosen, which
keeps the far pointer's position as close as possible to the true error's position. No randomness is
needed (the choice is unique); SEED is kept for the record. Items with true_step <= 2 have no candidate
and are marked far_false_available = false.

Writes:
  data/pilot/m3_pilot_40_far_false_sensitivity.jsonl
  outputs/m3_pilot_40_far_false_manifest.json
  outputs/m3_pilot_40_far_false_review.txt
"""
import hashlib
import json
import statistics
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import build_conditions as bc  # noqa: E402

ROOT = bc.ROOT
PRIMARY = ROOT / "data" / "pilot" / "m3_pilot_40_conditions.jsonl"
OUT_JSONL = ROOT / "data" / "pilot" / "m3_pilot_40_far_false_sensitivity.jsonl"
OUT_MANIFEST = ROOT / "outputs" / "m3_pilot_40_far_false_manifest.json"
OUT_REVIEW = ROOT / "outputs" / "m3_pilot_40_far_false_review.txt"

SEED = 42
METADATA_VERSION = "m3_pilot40_far_false_v1"
CONDITION = "L_false_far"
MIN_FAR_DISTANCE = 2


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def relations(it):
    """step -> (direct parent of the error step?, ancestor of the error step?)"""
    chain = {c["calc_id"]: c for c in it["dependency_chain"]}
    step_of = {c["calc_id"]: c["step_id"] for c in it["dependency_chain"]}
    err = next(c for c in it["dependency_chain"] if c["step_id"] == it["error_step"])
    parents = set(err["dependencies_on_previous_calc_ids"])
    ancestors, stack = set(), list(parents)
    while stack:
        cid = stack.pop()
        if cid in ancestors:
            continue
        ancestors.add(cid)
        stack.extend(chain[cid]["dependencies_on_previous_calc_ids"])
    return ({step_of[c] for c in parents}, {step_of[c] for c in ancestors})


def tier(step, parent_steps, ancestor_steps):
    if step in parent_steps:
        return 3
    if step in ancestor_steps:
        return 2
    return 1


def choose_far(it):
    t = it["error_step"]
    parent_steps, ancestor_steps = relations(it)
    candidates = []
    for f in range(1, t - MIN_FAR_DISTANCE + 1):
        checks = bc.false_step_checks(it, f)
        candidates.append({"step": f, "tier": tier(f, parent_steps, ancestor_steps),
                           "valid": checks["ALL_PASS"], "checks": checks})
    valid = [c for c in candidates if c["valid"]]
    if not valid:
        return None, candidates, parent_steps, ancestor_steps
    best = min(valid, key=lambda c: (c["tier"], -c["step"]))
    return best, candidates, parent_steps, ancestor_steps


def dist(values):
    return {str(k): v for k, v in sorted(Counter(values).items())}


def mean(values):
    return round(statistics.mean(values), 4) if values else None


def pct(flags):
    return round(100 * sum(flags) / len(flags), 1) if flags else None


def main():
    src_sha_before, primary_sha_before = sha256(bc.SRC), sha256(PRIMARY)
    items = json.loads(bc.SRC.read_text(encoding="utf-8"))["items"]
    by_id = {it["id"]: it for it in items}
    primary = [json.loads(l) for l in PRIMARY.read_text(encoding="utf-8").splitlines()]
    prim = {(r["item_id"], r["condition"]): r for r in primary}
    assert len(primary) == 200

    records, rows, audit_rows = [], [], []
    for it in items:
        iid, t, n = it["id"], it["error_step"], it["n_steps"]
        L_row, near_row = prim[(iid, "L")], prim[(iid, "L_false")]
        near = near_row["pointed_step"]
        # the primary L prompt must be exactly what the shared template produces
        assert L_row["prompt"] == bc.build_prompt(it["question"], it["corrupted_steps_student"],
                                                  bc.feedback("L", t, near, it["gold_answer"]))
        best, candidates, parent_steps, ancestor_steps = choose_far(it)
        far = best["step"] if best else None
        rec = {
            "item_id": iid,
            "true_step": t,
            "false_step_near": near,
            "false_step_far": far,
            "far_false_available": best is not None,
            "near_distance": t - near,
            "far_distance": (t - far) if far else None,
            "near_direct_parent_of_error": near in parent_steps,
            "far_direct_parent_of_error": (far in parent_steps) if far else None,
            "near_ancestor_of_error": near in ancestor_steps,
            "far_ancestor_of_error": (far in ancestor_steps) if far else None,
            "trace_length": n,
            "true_relative_position": round(t / n, 4),
            "near_relative_position": round(near / n, 4),
            "far_relative_position": round(far / n, 4) if far else None,
            "far_false_tier": best["tier"] if best else None,
            "far_candidates_considered": [{"step": c["step"], "tier": c["tier"], "valid": c["valid"]}
                                          for c in candidates],
            "unavailable_reason": None if best else (
                f"true error at Step {t}: no step is >= {MIN_FAR_DISTANCE} steps earlier" if not candidates
                else "no candidate passed the correctness checks"),
        }
        records.append(rec)
        if best is None:
            continue
        fb = bc.feedback("L_false", t, far, it["gold_answer"])   # identical wording to L
        prompt = bc.build_prompt(it["question"], it["corrupted_steps_student"], fb)
        rows.append({
            "item_id": iid,
            "condition": CONDITION,
            "prompt": prompt,
            "true_error_step": t,
            "false_step_far": far,
            "far_distance": t - far,
            "far_false_tier": best["tier"],
            "gold_answer": it["gold_answer"],
            "corrupted_answer": it["corrupted_answer"],
            "trace_length": n,
            "far_relative_position": round(far / n, 4),
            "metadata_version": METADATA_VERSION,
        })
        audit_rows.append({"item_id": iid, "condition": CONDITION, "prompt": prompt, "_feedback": fb,
                           "pointed_step": far})

    # ------------- audits (same functions as the primary conditions)
    violations, natural = bc.leakage_audit(audit_rows, by_id)
    pairs = {r["item_id"]: {"L": prim[(r["item_id"], "L")], CONDITION: r} for r in audit_rows}
    matching = bc.matching_audit(pairs, false_condition=CONDITION, check_v=False)
    matching = {"L_vs_L_false_far_pairs_checked": matching["L_vs_L_false_pairs_checked"],
                "L_vs_L_false_far_differing_beyond_step_number": matching["L_vs_L_false_differing_beyond_step_number"],
                "details": matching["details"]}
    far_checks = {r["item_id"]: bc.false_step_checks(by_id[r["item_id"]], r["pointed_step"]) for r in audit_rows}
    far_invalid = [k for k, c in far_checks.items() if not c["ALL_PASS"]]
    far_equals_near = [r["item_id"] for r in records if r["false_step_far"] == r["false_step_near"]]

    # ------------- summaries
    elig = [r for r in records if r["far_false_available"]]
    tiers = Counter(r["far_false_tier"] for r in elig)
    manifest = {
        "metadata_version": METADATA_VERSION,
        "seed": SEED,
        "condition_alias": {"L_false": "L_false_near",
                            "note": "the primary file keeps the label 'L_false' unchanged for provenance; "
                                    "analysis should read it as L_false_near"},
        "source_file": "data/pilot/m3_pilot_40.json",
        "source_sha256": src_sha_before,
        "primary_conditions_file": "data/pilot/m3_pilot_40_conditions.jsonl",
        "primary_conditions_sha256": primary_sha_before,
        "selection_rules": {
            "candidate_steps": f"1 .. true_step - {MIN_FAR_DISTANCE}",
            "validity": ["before true error", "not the true error step", "identical to gold step",
                         "not downstream of the error", "contains a calculation", "calculation correct"],
            "tier_1": "not a direct parent and not an ancestor of the error step",
            "tier_2": "not a direct parent, indirect ancestor allowed",
            "tier_3": "direct parent allowed (never the immediate predecessor, since distance >= 2)",
            "within_tier": "latest qualifying step (smallest distance >= 2)",
        },
        "items_total": len(records),
        "far_false_available": len(elig),
        "far_false_unavailable": len(records) - len(elig),
        "tier_counts": {"1": tiers[1], "2": tiers[2], "3": tiers[3]},
        "distributions_all_40": {
            "true_step": dist(r["true_step"] for r in records),
            "near_false_step": dist(r["false_step_near"] for r in records),
            "near_distance": dist(r["near_distance"] for r in records),
        },
        "distributions_eligible_subset": {
            "true_step": dist(r["true_step"] for r in elig),
            "near_false_step": dist(r["false_step_near"] for r in elig),
            "far_false_step": dist(r["false_step_far"] for r in elig),
            "near_distance": dist(r["near_distance"] for r in elig),
            "far_distance": dist(r["far_distance"] for r in elig),
            "trace_length": dist(r["trace_length"] for r in elig),
        },
        "dependency_percentages": {
            "all_40": {"near_direct_parent_pct": pct([r["near_direct_parent_of_error"] for r in records]),
                       "near_ancestor_pct": pct([r["near_ancestor_of_error"] for r in records])},
            "eligible_subset": {
                "near_direct_parent_pct": pct([r["near_direct_parent_of_error"] for r in elig]),
                "far_direct_parent_pct": pct([r["far_direct_parent_of_error"] for r in elig]),
                "near_ancestor_pct": pct([r["near_ancestor_of_error"] for r in elig]),
                "far_ancestor_pct": pct([r["far_ancestor_of_error"] for r in elig]),
            },
        },
        "relative_position_means": {
            "all_40": {"true": mean([r["true_relative_position"] for r in records]),
                       "near": mean([r["near_relative_position"] for r in records])},
            "eligible_subset": {"true": mean([r["true_relative_position"] for r in elig]),
                                "near": mean([r["near_relative_position"] for r in elig]),
                                "far": mean([r["far_relative_position"] for r in elig])},
        },
        "prompt_validation": {
            "prompts": len(rows),
            "leakage_violations": len(violations), "leakage_details": violations,
            "natural_question_occurrences": natural,
            "matching": matching,
            "far_steps_failing_correctness_checks": far_invalid,
            "far_step_equal_to_near_step": far_equals_near,
        },
        "items": records,
    }

    with open(OUT_JSONL, "w", encoding="utf-8", newline="\n") as fh:
        for r in rows:
            fh.write(json.dumps(r, ensure_ascii=False) + "\n")
    OUT_MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    yn = {True: "yes", False: "no", None: "n/a"}
    with open(OUT_REVIEW, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("M3 PILOT (40 items): L_false_far SENSITIVITY REVIEW\n")
        fh.write("Step markers [TRUE]/[NEAR]/[FAR] and dependency notes appear ONLY in this file, never in a prompt.\n")
        fh.write("L_false in the primary file = L_false_near.\n\n")
        for rec in records:
            it = by_id[rec["item_id"]]
            fh.write("=" * 78 + "\n")
            fh.write(f"ITEM ID: {rec['item_id']}   trace length {rec['trace_length']}\n")
            fh.write(f"TRUE ERROR STEP: {rec['true_step']}   NEAR FALSE STEP: {rec['false_step_near']}   "
                     f"FAR FALSE STEP: {rec['false_step_far'] if rec['false_step_far'] else 'UNAVAILABLE'}\n")
            if not rec["far_false_available"]:
                fh.write(f"far_false_available = false ({rec['unavailable_reason']})\n")
            fh.write("\nTRACE (corrupted, as shown to the model):\n")
            for k, s in enumerate(it["corrupted_steps_student"], 1):
                tags = [lab for lab, v in (("TRUE", rec["true_step"]), ("NEAR", rec["false_step_near"]),
                                           ("FAR", rec["false_step_far"])) if v == k]
                fh.write(f"  Step {k}: {s}" + (f"   [{'/'.join(tags)}]" if tags else "") + "\n")
            fh.write("\nTRUE LOCATION FEEDBACK:  " + bc.feedback("L", rec["true_step"], None, None).replace("\n", " / ") + "\n")
            fh.write("NEAR FALSE FEEDBACK:     " + bc.feedback("L_false", None, rec["false_step_near"], None).replace("\n", " / ") + "\n")
            if rec["far_false_available"]:
                fh.write("FAR FALSE FEEDBACK:      " + bc.feedback("L_false", None, rec["false_step_far"], None).replace("\n", " / ") + "\n")
            fh.write("\nDEPENDENCY RELATION:\n")
            fh.write(f"  near directly feeds true error? {yn[rec['near_direct_parent_of_error']]}   "
                     f"near ancestor? {yn[rec['near_ancestor_of_error']]}\n")
            fh.write(f"  far directly feeds true error?  {yn[rec['far_direct_parent_of_error']]}   "
                     f"far ancestor? {yn[rec['far_ancestor_of_error']]}   far tier: {rec['far_false_tier']}\n")
            fh.write(f"  far candidates considered: {rec['far_candidates_considered']}\n\n")

    # ------------- provenance: inputs untouched
    assert sha256(bc.SRC) == src_sha_before and sha256(PRIMARY) == primary_sha_before

    print(json.dumps({k: manifest[k] for k in ("far_false_available", "far_false_unavailable", "tier_counts",
                                               "distributions_all_40", "distributions_eligible_subset",
                                               "dependency_percentages", "relative_position_means")}, indent=2))
    print(json.dumps(manifest["prompt_validation"], indent=2))
    if violations or matching["L_vs_L_false_far_differing_beyond_step_number"] or far_invalid or far_equals_near:
        sys.exit(2)


if __name__ == "__main__":
    main()
