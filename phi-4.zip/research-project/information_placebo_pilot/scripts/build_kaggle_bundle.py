"""Build the Kaggle upload package (no model is run here).

  python scripts/build_kaggle_bundle.py

1. verifies the four frozen experimental files against their frozen SHA-256 (stops on any difference)
2. (re)creates kaggle/pilot_bundle/ mirroring the repo layout (data/, outputs/, scripts/, configs/)
3. writes kaggle/pilot_bundle/manifest.json with the SHA-256 of every bundled file
4. writes kaggle/run_qwen3_pilot.ipynb (9 cells, stops after the 10-request smoke test) and
   kaggle/run_full_768_persistent.ipynb (11 cells, fresh-runtime 225-request run for Save & Run All)
5. writes kaggle/pilot_bundle.zip (upload this as a Kaggle Dataset) and kaggle/README_KAGGLE.md
"""
import hashlib
import json
import shutil
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import kaggle_runner as kr  # noqa: E402  (only constants are used; no torch import at module level)

KAGGLE = ROOT / "kaggle"
BUNDLE = KAGGLE / "pilot_bundle"
FILES = [
    "data/pilot/m3_pilot_40.json",
    "data/pilot/m3_pilot_40_conditions.jsonl",
    "data/pilot/m3_pilot_40_far_false_sensitivity.jsonl",
    "outputs/pilot_execution_order.json",
    "scripts/pilot_common.py",
    "scripts/parse_answers.py",
    "scripts/score_pilot.py",
    "scripts/run_pilot.py",          # the audited runner (resume, provenance, smoke selection)
    "scripts/backends.py",           # the audited HF backend + chat-template check
    "scripts/kaggle_runner.py",      # Kaggle-specific helpers (no full-pilot entry point)
    "scripts/kaggle_full_run.py",    # v5: fresh-runtime full run, checkpoints, final ZIP (persistence only)
    kr.CONFIG_REL,
]


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


CELLS = [
    ("markdown", """# Information-or-Placebo pilot: Qwen3-4B smoke test on a free Kaggle GPU

**Before running:** Settings -> Accelerator -> **GPU T4 x2** (recommended) · Settings -> **Internet on** ·
Add Input -> the uploaded dataset **info-placebo-pilot-bundle**.

Run the cells **in order, once**. Any failed check raises `SystemExit: STOP ...`: do not continue past it.
This notebook runs a canary plus **only the 10-request smoke test** (2 items x L0, V, L_false_near, L, A).
It never launches the 225-request pilot. Outputs: `/kaggle/working/results/`."""),
    ("code", """# CELL 1 - environment / GPU check (no CPU fallback)
import hashlib, json, sys
from pathlib import Path
hits = [m.parent for m in Path('/kaggle/input').rglob('manifest.json')
        if json.loads(m.read_text()).get('bundle_id') == 'info-placebo-pilot-bundle']
assert len(hits) == 1, f'attach exactly one info-placebo-pilot-bundle dataset (found {hits})'
BUNDLE_IN = hits[0]
_m = json.loads((BUNDLE_IN / 'manifest.json').read_text())
_r = BUNDLE_IN / 'scripts' / 'kaggle_runner.py'
assert hashlib.sha256(_r.read_bytes()).hexdigest() == _m['files']['scripts/kaggle_runner.py'], 'STOP: kaggle_runner.py hash mismatch'
sys.path.insert(0, str(BUNDLE_IN / 'scripts'))
import kaggle_runner as kr
GPU = kr.gpu_check()"""),
    ("code", """# CELL 2 - pin transformers/accelerate to the audited versions (Kaggle's CUDA torch is kept)
VERSIONS = kr.ensure_packages()"""),
    ("code", """# CELL 3 - copy bundle to /kaggle/working/pilot and verify ALL file hashes (frozen data included)
MANIFEST = kr.stage_and_verify()"""),
    ("code", """# CELL 4 - verify the pinned revision on the Hub, then load Qwen/Qwen3-4B from snapshots/<pinned commit>
# (FP16, cuda:0). Provenance = Hub SHA check before loading; transformers_commit_hash is informational (null OK).
# Public model: no token needed. If authentication is requested the cell stops and explains Kaggle Secrets.
BACKEND = kr.load_model()"""),
    ("code", """# CELL 5 - verify the real non-thinking chat template (enable_thinking=False; prompt never modified)
TEMPLATE = kr.template_report(BACKEND)"""),
    ("code", """# CELL 6 - non-experimental canary (stored only in results/diagnostics/)
CANARY = kr.canary(BACKEND)"""),
    ("code", """# CELL 7 - the 10-request experimental smoke test ONLY (independent requests, batch size 1)
# writes results/smoke_<max_new_tokens>/ (smoke_768 under bundle v3); never appends to an existing run
SMOKE_DIR = kr.smoke_test(BACKEND)"""),
    ("code", """# CELL 8 - parse and score the smoke outputs (plumbing check)
DIAG = kr.score_and_diagnose(SMOKE_DIR, GPU, VERSIONS)"""),
    ("code", """# CELL 9 - display diagnostics and stop
import pandas as pd
display(pd.read_json(SMOKE_DIR / 'scored_outputs.jsonl', lines=True)[
    ['run_index', 'item_id', 'analysis_condition', 'numeric_parse_status', 'numeric_parse_source',
     'strict_format_compliant', 'is_gold_correct', 'is_corrupted_answer']])
print('PIPELINE CHECK ONLY - NOT AN EXPERIMENTAL RESULT - N=2 ITEMS. Do not compare conditions.')
print('flagged responses:', DIAG['flagged_responses'])
print('gate:', DIAG['gate'])
print('DECISION:', DIAG['decision'])
print('Download /kaggle/working/results (Output panel, or File -> Save Version) and stop here.')"""),
]


PERSISTENT_CELLS = [
    ("markdown", """# Information-or-Placebo pilot: FULL 225-request run - fresh runtime, built for Save & Run All

**Run it with: File -> Save Version -> Save & Run All (Commit).** Do not run cells by hand.
Settings before saving: Accelerator **GPU T4 x2** · Internet **On** · Add Input -> dataset
**info-placebo-pilot-bundle** (bundle **v5**, exactly one copy attached).

Frozen protocol (no change): Qwen/Qwen3-4B @ 3101254bbe4169895668a0e7653c3fd1f313576e · FP16 · cuda:0 ·
Kaggle T4 · temperature 0 · do_sample False · num_beams 1 · enable_thinking False · max_new_tokens 768 ·
batch size 1 · stateless single user message, no system message, no history · frozen datasets, prompts,
conditions, false-hint assignments, execution order (seed 2026), parser and scorer.
225 requests = 40 x L0, V, L_false_near, L, A + 25 x L_false_far.

Every cell refuses to run unless the previous one completed, so a failed check can never be followed by
experimental requests. Outputs (kept as the saved version's Output):
`results/full_768/` · `checkpoints/checkpoint_025.zip ... checkpoint_225.zip` · **`results_full_768_FINAL.zip`**.
No repair rates, CCA, comparisons or tests are computed."""),
    ("code", """# CELL 1 - GPU / environment check (fresh runtime required; Kaggle T4; no CPU fallback)
import hashlib, json, sys
from pathlib import Path
hits = [m.parent for m in Path('/kaggle/input').rglob('manifest.json')
        if json.loads(m.read_text()).get('bundle_id') == 'info-placebo-pilot-bundle']
assert len(hits) == 1, f'STOP: attach exactly one info-placebo-pilot-bundle dataset (found {hits})'
BUNDLE_IN = hits[0]
_m = json.loads((BUNDLE_IN / 'manifest.json').read_text())
assert _m.get('bundle_version') == 5, f"STOP: bundle v5 required, found v{_m.get('bundle_version')}"
for _f in ('scripts/kaggle_runner.py', 'scripts/kaggle_full_run.py'):
    assert hashlib.sha256((BUNDLE_IN / _f).read_bytes()).hexdigest() == _m['files'][_f], f'STOP: {_f} hash mismatch'
sys.path.insert(0, str(BUNDLE_IN / 'scripts'))
import kaggle_full_run as kf
GPU = kf.cell1_environment()"""),
    ("code", """# CELL 2 - install / verify the audited package versions (transformers 5.19.0, accelerate 1.15.0)
VERSIONS = kf.cell2_packages()"""),
    ("code", """# CELL 3 - stage the bundle in /kaggle/working/pilot and verify every file hash (frozen data included)
MANIFEST = kf.cell3_stage()"""),
    ("code", """# CELL 4 - verify the pinned revision on the Hub, then load the exact Qwen3-4B checkpoint (FP16, cuda:0)
BACKEND = kf.cell4_load()"""),
    ("code", """# CELL 5 - verify FP16, cuda:0, non-thinking chat template (single user message) and greedy generation
TEMPLATE = kf.cell5_verify(BACKEND)"""),
    ("code", """# CELL 6 - small non-experimental 2+2 canary (stored only in results/diagnostics/)
CANARY = kf.cell6_canary(BACKEND)"""),
    ("code", """# CELL 7 - full pre-flight validation for the 225-request experiment (STOP here = nothing is sent)
CTX = kf.cell7_preflight(BACKEND, GPU, VERSIONS, MANIFEST)"""),
    ("code", """# CELL 8 - the exact deterministic 225 requests -> /kaggle/working/results/full_768/
# fsync after every request; checkpoints/checkpoint_025.zip ... checkpoint_225.zip ("CHECKPOINT READY: N/225")
kf.cell8_run(BACKEND, CTX)"""),
    ("code", """# CELL 9 - parse and score with the frozen parser + scorer (row counts only are shown)
SCORED = kf.cell9_score()"""),
    ("code", """# CELL 10 - final completeness / integrity diagnostics (no analysis)
DIAG = kf.cell10_diagnostics(CTX, SCORED)"""),
    ("code", """# CELL 11 - archive the complete run and verify it
FINAL = kf.cell11_final_zip()
from IPython.display import HTML, display
display(HTML("<div style='border:6px solid #c00;padding:18px;font-size:22px;font-weight:bold;color:#c00'>"
             "RUN COMPLETE<br>DOWNLOAD FROM SAVED VERSION OUTPUT:<br>results_full_768_FINAL.zip<br>"
             f"<span style='font-size:14px'>{FINAL['bytes']} bytes &middot; SHA-256 {FINAL['sha256']}</span></div>"))"""),
]


def notebook(cells=None):
    cells = cells or CELLS

    def cell(kind, src):
        lines = src.splitlines(keepends=True)
        c = {"cell_type": kind, "metadata": {}, "source": lines}
        if kind == "code":
            c.update(execution_count=None, outputs=[])
        return c
    return {"cells": [cell(k, s) for k, s in cells], "nbformat": 4, "nbformat_minor": 5,
            "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
                         "language_info": {"name": "python"},
                         "kaggle": {"accelerator": "gpu", "isInternetEnabled": True, "isGpuEnabled": True}}}


README = """# Running the Qwen3-4B smoke test on Kaggle (free GPU)

Nothing here runs on the laptop. The scientific experiment is unchanged: the same frozen prompts, execution
order, smoke items, parser, scorer and provenance checks.

## 1. Upload the bundle as a private Kaggle Dataset
kaggle.com -> Datasets -> New Dataset -> upload `kaggle/pilot_bundle.zip`
(Kaggle unzips it) -> title `info-placebo-pilot-bundle` -> Private -> Create.

## 2. Create the notebook
kaggle.com -> Code -> New Notebook -> File -> Import Notebook -> `kaggle/run_qwen3_pilot.ipynb`.

## 3. Notebook settings (right-hand panel)
- Accelerator: **GPU T4 x2** (recommended; P100 is checked and may be rejected by current PyTorch builds)
- Internet: **On** (requires a phone-verified Kaggle account; needed to download the model and pin packages)
- Add Input -> Your Datasets -> `info-placebo-pilot-bundle`

## 4. Run cells 1 -> 9 in order
Each gate stops with `SystemExit: STOP ...` on failure: GPU, package pins, file hashes, pinned revision
and dtype, chat template, canary. Cell 7 sends exactly 10 independent requests. Nothing runs after cell 9.

## 5. Bring the results back
Results are in `/kaggle/working/results/`:
- `smoke/`: raw_outputs.jsonl, parsed_outputs.jsonl, scored_outputs.jsonl, summary.json, environment.json,
  smoke_diagnostics.json, config.json, run_log.txt, paired_primary.csv
- `diagnostics/`: model_load.json, template_audit.json, canary.json (kept separate from the smoke run)

Download them from the Output panel, or use "Save Version -> Save & Run All" to persist them, and place
them under `kaggle/results/` locally.

## Tokens
None needed: Qwen/Qwen3-4B is public (Apache-2.0). If Hugging Face unexpectedly asks for authentication,
cell 4 stops and prints Kaggle Secrets instructions. Never paste a token into the notebook.

# FULL 225-request run, fresh runtime, Save & Run All (bundle v5, `kaggle/run_full_768_persistent.ipynb`)

Rerun of the frozen pilot (first run's files were lost; NOT a protocol change). v5 = v3 files byte-identical
+ `scripts/kaggle_full_run.py` (persistence only).

1. Datasets -> `info-placebo-pilot-bundle` -> New Version -> upload `kaggle/pilot_bundle.zip` (v5).
2. Code -> New Notebook -> File -> Import Notebook -> `kaggle/run_full_768_persistent.ipynb`.
3. Settings: Accelerator GPU T4 x2; Internet On; Add Input -> `info-placebo-pilot-bundle`.
4. Save Version -> Save & Run All (Commit) -> Save. Do not run cells by hand.
5. The browser can be closed. When the version finishes: notebook -> that version -> Output:
   `results_full_768_FINAL.zip` (+ `.sha256.txt`), `checkpoints/`, `results/`.
"""


def main():
    bad = [rel for rel, h in kr.FROZEN_SHA256.items() if sha(ROOT / rel) != h]
    if bad:
        sys.exit(f"STOP: frozen files changed: {bad}")
    print("frozen hashes verified:", len(kr.FROZEN_SHA256))
    if BUNDLE.exists():
        shutil.rmtree(BUNDLE)
    files = {}
    for rel in FILES:
        dst = BUNDLE / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / rel, dst)
        files[rel] = sha(dst)
        assert files[rel] == sha(ROOT / rel)
    manifest = {"bundle_id": kr.BUNDLE_ID, "bundle_version": 5,
                "changes_from_v3": ["persistence only: adds scripts/kaggle_full_run.py and the notebook "
                                    "run_full_768_persistent.ipynb (fresh runtime, Save & Run All, 11 guarded "
                                    "cells, checkpoint_025..225.zip, verified results_full_768_FINAL.zip). Every v3 "
                                    "file is byte-identical; no experimental setting, prompt, condition, false-hint "
                                    "assignment, order, parser or scorer changed. (v4 was an unused interim build.)"],
                "changes_from_v2": ["max_new_tokens 512 -> 768 (only change to the generation protocol; first Kaggle smoke test truncated m3p_04/A at 512)", "smoke runs are named results/smoke_<max_new_tokens> and never append to an existing run", "smoke diagnostics add generated_tokens_max, retries, per-response flags and the GO/NO-GO gate"],
                "changes_from_v1": ["revision provenance: Hub SHA (HfApi().model_info(repo, revision).sha) verified "
                                    "BEFORE loading; tokenizer+model loaded from snapshots/<pinned commit>; "
                                    "requested / hub_resolved / transformers_commit_hash recorded separately; "
                                    "transformers_commit_hash = null is no longer treated as a failure",
                                    "load_model re-uses an already-loaded model object instead of stacking a "
                                    "second copy on the GPU"],
                "created": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "model": "Qwen/Qwen3-4B", "model_revision": "3101254bbe4169895668a0e7653c3fd1f313576e",
                "frozen_experimental_sha256": kr.FROZEN_SHA256, "files": files,
                "notes": "Layout mirrors the project repo so the audited scripts run unchanged. "
                         "Every file hash is re-verified in the Kaggle notebook (cell 3) before inference."}
    (BUNDLE / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    (KAGGLE / "run_qwen3_pilot.ipynb").write_text(json.dumps(notebook(), indent=1) + "\n", encoding="utf-8")
    (KAGGLE / "run_full_768_persistent.ipynb").write_text(
        json.dumps(notebook(PERSISTENT_CELLS), indent=1) + "\n", encoding="utf-8")
    (KAGGLE / "README_KAGGLE.md").write_text(README, encoding="utf-8")
    zp = KAGGLE / "pilot_bundle.zip"
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(BUNDLE.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(BUNDLE).as_posix())
    (KAGGLE / "results" / "smoke").mkdir(parents=True, exist_ok=True)
    print(json.dumps({"bundle_files": len(files) + 1, "zip_bytes": zp.stat().st_size}, indent=2))


if __name__ == "__main__":
    main()
