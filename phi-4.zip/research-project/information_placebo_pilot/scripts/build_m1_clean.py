"""Stage 3: regenerate exactly 10 CLEAN M1 (wrong-operation) candidates for manual review.

Structural pipeline is imported UNCHANGED from build_m1_candidates.py (strict filter, explicit
dependency graph, corruption + propagation, independent validation). This script only adds
semantic controls on top of it:

  1. Unit check            - reject any swap that can create a dimensional mismatch (uncertain => reject)
  2. Local wording cue     - error-step wording that specifies the original operation
  3. Question wording cue  - question wording that specifies the original operation, attributed to
                             clauses; cues that cannot be attributed to a DIFFERENT calculation count
                             against the candidate (conservative)
  4. Numeric plausibility  - tighter band on the corrupted intermediate value
  5. Reviewer semantic check (recorded in REVIEWER_SEMANTIC_CHECK below, with reasons) for the
     sentence-level questions no keyword rule can answer ("does the sentence become nonsensical?").
     Candidates without a recorded check are never emitted; they are listed as pending instead.

No language model is called. Stage 2 outputs are not touched.

Usage (from the project root):
    PYTHONIOENCODING=utf-8 python scripts/build_m1_clean.py
"""
import json
import random
import re
import sys
from collections import Counter
from fractions import Fraction
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import build_m1_candidates as s2  # noqa: E402  (structural pipeline, unchanged)

ROOT = s2.ROOT
OUT_JSON = ROOT / "data" / "pilot" / "m1_candidates_10_clean.json"
OUT_REVIEW = ROOT / "outputs" / "m1_candidates_10_clean_review.txt"
OUT_STATS = ROOT / "outputs" / "m1_candidates_10_clean_stats.json"
OUT_POOL_AUDIT = ROOT / "outputs" / "m1_clean_pool_audit.txt"

SEED = 42
N_CANDIDATES = 10
INTERMEDIATE_BAND = (Fraction(1, 4), Fraction(4))   # corrupted / original value at the error step
DIVERSITY_CAPS = {"swap_pair": 6, "error_step": 3, "n_steps": 4}
N_PENDING_TO_LIST = 40

# ------------------------------------------------------------------ cue lexicon
# op -> words/phrases that, when they describe an operation, specify that operator.
CUES = {
    # "profit" is deliberately absent: it specifies '-' (revenue - cost) or '+' (price = cost + profit).
    # Directional words below were added after manual review of the first clean pool
    # ("6 inches above the rim", "60% faster", "went up", "20% under", "giving him 20 euros", "absent").
    "+": ["total", "totals", "altogether", "combined", "combine", "together", "sum", "in all", "plus", "add", "adds",
          "added", "additional", "additionally", "extra", "increase", "increases", "increased", "more", "another",
          "gain", "gains", "gained", "both", "overall", "above", "up", "went up", "faster", "higher", "taller",
          "longer", "older", "later", "markup", "tip", "fee", "fees", "tax", "giving", "gives", "gave", "help"],
    "-": ["remaining", "remain", "remains", "remainder", "left", "rest", "difference", "fewer", "less", "minus",
          "subtract", "subtracted", "spent", "spend", "spends", "change", "lost", "lose", "loses", "losing", "loss",
          "take away", "took away", "gave away", "give away", "gives away", "away", "off", "decrease", "decreases",
          "decreased", "discount", "cheaper", "short", "shortage", "need", "needs", "still", "after", "under", "below",
          "down", "absent", "without", "missing", "lack", "lacks", "died", "cracked", "broke", "broken"],
    "*": ["twice", "double", "doubled", "doubles", "triple", "tripled", "times", "times as many", "times as much",
          "multiply", "multiplied", "dozen", "dozens", "each", "per", "every", "percent", "percentage", "%"],
    "/": ["half", "halve", "halved", "halves", "divide", "divided", "divides", "dividing", "split", "equally",
          "evenly", "average", "a third", "one third", "one-third", "thirds", "a quarter", "one quarter",
          "quarters", "ratio", "share", "shared", "each", "per", "percent", "percentage", "%"],
}
# Comparative relations ("8 more than Frank", "older than", "3 times as many as") explicitly specify a
# relation between quantities; the needed operator depends on direction, so they are always flagged.
RELATIONAL_RE = re.compile(r"\b(?:mores?|less|fewer|\w+er)\s+(?:\w+\s+){0,2}than\b|\btimes\s+as\s+(?:many|much)\b|\bas\s+many\s+as\b|\bas\s+much\s+as\b",
                           re.IGNORECASE)
CLAUSE_SPLIT_RE = re.compile(r"[.;?!]|,|\bbut\b|\bwhile\b|\bwhereas\b|\band then\b", re.IGNORECASE)

# ------------------------------------------------------------------ reviewer semantic check
# Sentence-level semantic judgement that keyword rules cannot make. Filled in after reading each
# candidate's question + gold + corrupted trace in full. Keyed by (source_index, calc_id, replacement_operator).
# Recorded by: Claude (coding assistant) during dataset construction - NOT the project's human review,
# which remains pending in manual_review.approved.
def _reject(reason):
    return {"pass": False, "sentence_sensible": False, "values_plausible": False, "reason": reason,
            "sentence_note": reason, "values_note": reason}


REVIEWER_SEMANTIC_CHECK = {
    (5177, 2, "+"): _reject("'Sergio got 50 + 4 = 54 correct answers' exceeds the 50 questions in the exam"),
    (3903, 2, "+"): _reject("'4 + 1 = 5 more hours in his shift' exceeds the four-hour shift"),
    (3108, 2, "-"): _reject("spending on hamburgers AND milkshakes (14) is less than hamburgers alone (32, step 1)"),
    (7455, 2, "+"): _reject("profit per complex repair ($350) exceeds the $300 charged; profit cannot exceed price"),
    (5669, 2, "-"): _reject("total used on the cow ($700) is less than the $1300 of expenses alone (step 2)"),
    (2319, 1, "-"): _reject("selling price $700 is below the $1000 purchase price, contradicting a sale 'with a 30% profit'"),
    (1769, 2, "-"): _reject("9 students answering 'either green or pink' is fewer than the 15 who answered green (step 1)"),
    (3178, 2, "-"): _reject("daily distance 'afternoon and morning' (1460 m) is less than the morning distance alone (2555 m)"),
    (5158, 2, "+"): _reject("'Alex watched 15 + 2 = 17 more movies' exceeds the 15 movies Alex watched in total"),
    (6202, 1, "-"): _reject("'4 crows to begin with' although 5 crows flew away and 1 remained"),
    (3309, 1, "-"): _reject("selling price $5 is below the $10.50 cost, contradicting a $5.50 profit per birdhouse"),
    (5575, 2, "+"): _reject("the aunt's gift ($154) exceeds the $97 the sisters had in total after receiving it"),
    (277, 1, "+"): _reject("two puppies costing $1250 exceeds the $800 paid for all five"),
    (4609, 1, "+"): _reject("sum of the first two quizzes (374) exceeds the three-quiz sum (282); an average of 187 is impossible"),
    (7261, 1, "+"): _reject("4238 L consumed between two fill-ups of a 3000 L tank is impossible"),
    (4224, 1, "+"): _reject("green notebooks costing $70 exceeds the $45 total paid for all notebooks"),
    (568, 4, "-"): _reject("total cost $120,000 is less than the $200,000 component computed in step 4"),
    (5245, 1, "+"): _reject("profit per cookie ($1.75) exceeds its $1.50 selling price"),
    (7403, 1, "+"): _reject("'He trains 7+2=9 days' per week; a week has 7 days"),
    (825, 1, "-"): _reject("'everything' ($675) costs less than the bed alone ($750, step 1)"),
    (6128, 2, "+"): _reject("1800 seats taken exceeds the 1500 seats in the opera house"),
    (2387, 3, "+"): _reject("amount kept after the faire's cut ($2200) exceeds the $2000 revenue"),
    (3069, 1, "+"): _reject("'Bella will turn 18 in 26 years' although she is 8; she would be 34"),
    (15, 1, "+"): _reject("profit per DVD ($21) exceeds its $15 selling price"),
    (727, 1, "-"): _reject("vacation total of 9 shells is less than the 15 collected in the first 3 days (step 1)"),
    (5769, 1, "-"): _reject("17 'cows and sheep' is fewer than the 24 cows alone"),
    (5158, 1, "+"): _reject("'Hunter watched 12 + 2 = 14 more movies' exceeds the 12 movies Hunter watched in total"),
    (568, 1, "+"): _reject("'the next 18 + 8 = 26 years' cannot fit between age 8 and age 18"),
}


# ------------------------------------------------------------------ helpers
def find_cues(text, op):
    low = text.lower()
    hits = []
    for w in CUES[op]:
        if w == "%":
            if "%" in low:
                hits.append(w)
        elif re.search(r"\b" + re.escape(w) + r"\b", low):
            hits.append(w)
    return hits


def specifying_cues(text, orig, new):
    """Cues that support the original operator but not the replacement (a cue shared by both does not
    disambiguate). Relational comparatives are always returned."""
    hits = [w for w in find_cues(text, orig) if w not in CUES[new]]
    rel = [m.group(0) for m in RELATIONAL_RE.finditer(text)]
    return hits, rel


def clauses(q):
    return [c.strip() for c in CLAUSE_SPLIT_RE.split(q) if c and c.strip()]


def mentions_value(clause, v):
    if v in s2.prose_numbers(clause):
        return True
    low = clause.lower()
    for w, vals in s2.WORD_NUMBERS.items():
        if any(Fraction(x) == v for x in vals) and re.search(r"\b" + re.escape(w) + r"s?\b", low):
            return True
    for m in re.finditer(r"(" + s2.NUM_PAT + r")\s*%", clause):
        if s2.frac(m.group(1)) / 100 == v:
            return True
    return False


def question_operands(g, cid):
    c = g["calcs"][cid]
    return [v for v, s in zip(c["leaves"], c["operand_sources"]) if s == "question"]


# ------------------------------------------------------------------ checks
def unit_check(g, k, orig, new):
    """Return (mismatch: bool, reason)."""
    fam = {"+": "add", "-": "add", "*": "mul", "/": "mul"}
    if fam[orig] != fam[new]:
        if fam[orig] == "add":
            return True, (f"'{orig}'->'{new}': the gold step {orig}-combines two commensurable quantities (same unit); "
                          f"{'multiplying' if new == '*' else 'dividing'} them yields a squared/ratio unit that the sentence does not describe")
        return True, (f"'{orig}'->'{new}': operands of a {'product' if orig == '*' else 'quotient'} are in general not commensurable "
                      f"(e.g. amount x count); {'adding' if new == '+' else 'subtracting'} them mixes units")
    if fam[orig] == "add":
        return False, (f"'{orig}'->'{new}': both operands are already {'added' if orig == '+' else 'subtracted'} in the gold step, so "
                       f"they share a unit and the {'difference' if new == '-' else 'sum'} keeps that unit")
    return True, (f"'{orig}'->'{new}': swapping multiplication/division preserves the unit only if the factor is dimensionless; "
                  "this cannot be verified automatically, so the candidate is rejected as unit-uncertain")


def local_cue(g, k, orig, new):
    c = g["calcs"][k]
    text = s2.free_prose(g["lines"][c["line_index"]], c)
    hits, rel = specifying_cues(text, orig, new)
    if hits or rel:
        parts = []
        if hits:
            parts.append(f"error-step wording contains {hits}, which specifies '{orig}' (and not '{new}')")
        if rel:
            parts.append(f"error-step wording states an explicit comparative relation {rel}")
        return True, "; ".join(parts)
    other = find_cues(text, new)
    reason = f"error-step wording has no word that specifies '{orig}' over '{new}'"
    if other:
        reason += f" (wording contains {other}, which is compatible with the corrupted '{new}', not evidence against it)"
    return False, reason + f'. Step text: "{s2.clean(g["lines"][c["line_index"]]).strip()}"'


def question_cue(g, k, orig, new):
    """A cue ANYWHERE in the question that specifies the original operator (and not the replacement) flags
    the candidate. Attributing a cue to 'another step's clause' proved unreliable on manual inspection
    (e.g. "selling the remaining items at $40" sits in the $40 clause but specifies the corrupted 80-32),
    so no cue is ever explained away. The reason records whether the clause mentions a corrupted-step operand."""
    q = g["question"]
    target_vals = question_operands(g, k)
    found = []
    for cl in clauses(q):
        hits, rel = specifying_cues(cl, orig, new)
        if hits or rel:
            linked = any(mentions_value(cl, v) for v in target_vals)
            found.append(f'"{cl}" contains {hits + rel}' + (" (clause mentions an operand of the corrupted step)" if linked else ""))
    if found:
        return True, f"question wording can specify '{orig}': " + "; ".join(found)
    compatible = find_cues(q, new)
    reason = f"no word or comparative relation anywhere in the question specifies '{orig}' over '{new}'"
    if compatible:
        reason += f" (question contains {compatible}, compatible with the corrupted '{new}')"
    return False, reason


def numeric_plausibility(cor, g):
    lo, hi = INTERMEDIATE_BAND
    r = cor["corrupted_result"] / cor["original_result"]
    ok_mid = lo <= r <= hi
    f = cor["corrupted_final"]
    ok_final = f > 0 and f.denominator == 1   # final band [1/10, 10] already enforced structurally
    return ok_mid, ok_final, (f"corrupted intermediate {s2.num_out(cor['corrupted_result'])} vs gold {s2.num_out(cor['original_result'])} "
                              f"(ratio {float(r):.2f}, allowed [{float(lo)}, {float(hi)}]); corrupted final {s2.num_out(f)} vs gold "
                              f"{s2.num_out(g['final'])} (positive integer, ratio {float(f / g['final']):.2f}, allowed [0.1, 10])")


def review_block(i, r):
    out = ["=" * 78, f"CANDIDATE {i}   ({r['candidate_id']})", f"SOURCE INDEX: train[{r['source_index']}]",
           f"QUESTION: {r['question']}", "", "GOLD TRACE:"]
    out += [f"  Step {s}: {t}" for s, t in enumerate(r["gold_steps"], 1)]
    out += ["", "CORRUPTED TRACE:"]
    roles = {c["step_id"]: c["role"] for c in r["dependency_chain"] if c["role"] != "unaffected"}
    for s, t in enumerate(r["corrupted_steps"], 1):
        mark = {"INJECTED_ERROR": "   >>> INJECTED ERROR HERE <<<", "propagated": "   [recomputed from corrupted value]"}.get(roles.get(s), "")
        out.append(f"  Step {s}: {t}{mark}")
    out += ["", "INJECTED ERROR:", f"  error step: {r['error_step']}  (calc_id {r['calc_id']})",
            f"  original expression:  {r['original_expression']} = {r['original_result']}",
            f"  corrupted expression: {r['corrupted_expression']} = {r['corrupted_result']}",
            f"  operator swap: {r['original_operator']} -> {r['replacement_operator']}", "", "DEPENDENCY PROPAGATION:"]
    out += [f"  {line}" for line in r["propagation_explanation"]]
    sp = r["semantic_plausibility"]
    out += ["", f"GOLD ANSWER: {r['gold_answer']}", f"CORRUPTED ANSWER: {r['corrupted_answer']}", "",
            f"LOCAL WORDING CUE: {'yes' if r['local_wording_cue'] else 'no'}", f"  {r['local_wording_reason']}", "",
            f"QUESTION WORDING CUE: {'yes' if r['question_wording_cue'] else 'no'}", f"  {r['question_wording_reason']}", "",
            f"OVERALL OBVIOUSNESS: {'yes' if r['overall_obviousness'] else 'no'}", "",
            f"SEMANTIC PLAUSIBILITY: {'PASS' if sp['pass'] else 'FAIL'}", f"  {sp['reason']}"]
    for name, chk in sp["checks"].items():
        out.append(f"   - {name}: {'PASS' if chk['pass'] else 'FAIL'} [{chk['method']}] {chk['reason']}")
    v = r["automatic_validation"]
    out += ["", f"AUTOMATIC VALIDATION: {'PASS' if v['ALL_PASS'] else 'FAIL'}"]
    out += [f"  [{'PASS' if val is True else 'FAIL'}] {kk}" for kk, val in v.items() if kk != "ALL_PASS"]
    out.append("=" * 78)
    return "\n".join(out)


def propagation_explanation(r):
    lines = []
    chain = r["dependency_chain"]
    changed = {c["calc_id"] for c in chain if c["role"] != "unaffected"}
    for c in chain:
        if c["role"] == "INJECTED_ERROR":
            lines.append(f"Step {c['step_id']} (calc_{c['calc_id']}): INJECTED. Operator changed, operands kept: "
                         f"{c['gold_expression']}={c['gold_result']} -> {c['corrupted_expression']}={c['corrupted_result']}.")
        elif c["role"] == "propagated":
            ups = [d for d in c["dependencies_on_previous_calc_ids"] if d in changed]
            via = ", ".join(f"the result of calc_{d} (step {chain[d]['step_id']}: {chain[d]['gold_result']} -> {chain[d]['corrupted_result']})" for d in ups)
            lines.append(f"Step {c['step_id']} (calc_{c['calc_id']}): RECOMPUTED because it uses {via}; same operator(s), "
                         f"recomputed correctly: {c['gold_expression']}={c['gold_result']} -> {c['corrupted_expression']}={c['corrupted_result']}.")
        else:
            deps = c["dependencies_on_previous_calc_ids"]
            why = ("its operands come only from the question" if not deps else
                   f"it depends only on unchanged calc(s) {', '.join(f'calc_{d}' for d in deps)}")
            if c["step_id"] < r["error_step"]:
                why = "it precedes the error"
            lines.append(f"Step {c['step_id']} (calc_{c['calc_id']}): unchanged, {why}: {c['gold_expression']}={c['gold_result']}.")
    return lines


# ------------------------------------------------------------------ main
def main():
    records = [json.loads(l) for l in open(s2.RAW_TRAIN, encoding="utf-8")]
    eligible = {}
    for i, rec in enumerate(records):
        g, _ = s2.build_graph(rec)
        if g is not None:
            eligible[i] = g

    structural = []   # every corruption that passes the unchanged Stage 2 structural pipeline
    for i, g in eligible.items():
        for c in g["calcs"][:-1]:
            if len(c["ops"]) != 1:
                continue
            for new_op in [o for o in s2.OPS if o != c["ops"][0]]:
                cor, why = s2.make_corruption(g, c["calc_id"], new_op)
                if cor is None:
                    continue
                checks = s2.validate(records[i], g, cor)
                if checks["ALL_PASS"]:
                    structural.append((i, cor, checks))

    # ---- semantic layer, evaluated for every structurally valid corruption (non-exclusive flags)
    evaluated = []
    for i, cor, checks in structural:
        g = eligible[i]
        k, o, n = cor["calc_id"], cor["original_operator"], cor["replacement_operator"]
        lc, lr = local_cue(g, k, o, n)
        qc, qr = question_cue(g, k, o, n)
        um, ur = unit_check(g, k, o, n)
        ok_mid, ok_final, nr = numeric_plausibility(cor, g)
        evaluated.append(dict(i=i, cor=cor, checks=checks, lc=lc, lr=lr, qc=qc, qr=qr, um=um, ur=ur,
                              ok_mid=ok_mid, ok_final=ok_final, nr=nr))

    n0 = len(evaluated)
    seq = Counter()
    nonex = Counter()
    clean_pool = []
    for e in evaluated:
        nonex["local_wording_cue"] += e["lc"]
        nonex["question_wording_cue"] += e["qc"]
        nonex["unit_mismatch_or_unit_uncertain"] += e["um"]
        nonex["implausible_intermediate_value"] += not e["ok_mid"]
        nonex["implausible_final_value"] += not e["ok_final"]
        # sequential (first applicable reason), in the order the user listed the controls
        if e["um"]:
            seq["1_unit_mismatch_or_unit_uncertain"] += 1
        elif e["lc"]:
            seq["2_local_wording_cue"] += 1
        elif e["qc"]:
            seq["3_question_wording_cue"] += 1
        elif not (e["ok_mid"] and e["ok_final"]):
            seq["4_other_semantic_numeric_implausibility"] += 1
        else:
            clean_pool.append(e)

    # ---- seeded, diverse ranking of the clean pool; reviewer semantic check gates final selection
    rng = random.Random(SEED)
    by_item = {}
    for e in clean_pool:
        by_item.setdefault(e["i"], []).append(e)
    order = sorted(by_item)
    rng.shuffle(order)
    counts = {k: Counter() for k in DIVERSITY_CAPS}
    selected, pending, reviewer_rejected = [], [], []
    for i in order:
        if len(selected) >= N_CANDIDATES:
            break
        opts = sorted(by_item[i], key=lambda e: (abs(float(e["cor"]["corrupted_result"] / e["cor"]["original_result"]) - 1),
                                                 e["cor"]["calc_id"]))
        for e in opts:
            cor = e["cor"]
            kv = {"swap_pair": f"{cor['original_operator']}->{cor['replacement_operator']}", "error_step": cor["error_step"],
                  "n_steps": len(eligible[i]["lines"])}
            if not all(counts[k][kv[k]] < DIVERSITY_CAPS[k] for k in DIVERSITY_CAPS):
                continue
            key = (i, cor["calc_id"], cor["replacement_operator"])
            rev = REVIEWER_SEMANTIC_CHECK.get(key)
            if rev is None:
                pending.append(e)
                break           # one pending entry per item; do not fall through to a different corruption
            if not rev["pass"]:
                reviewer_rejected.append((key, rev["reason"]))
                continue
            e["rev"] = rev
            selected.append(e)
            for k in DIVERSITY_CAPS:
                counts[k][kv[k]] += 1
            break

    if pending:
        print(f"{len(pending)} candidate(s) need a reviewer semantic check before selection can complete:\n")
        for e in pending[:N_PENDING_TO_LIST]:
            g, cor = eligible[e["i"]], e["cor"]
            print("-" * 78)
            print(f"KEY ({e['i']}, {cor['calc_id']}, '{cor['replacement_operator']}')   error step {cor['error_step']}   "
                  f"{cor['original_operator']}->{cor['replacement_operator']}")
            print("Q:", g["question"])
            for s, (gl, cl) in enumerate(zip(g["lines"], cor["corrupted_lines"]), 1):
                print(f"  {s}. {s2.clean(gl)}")
                if gl != cl:
                    print(f"  {s}*{s2.clean(cl)}")
            print(f"  final {s2.num_out(g['final'])} -> {s2.num_out(cor['corrupted_final'])}")
            print("  local:", e["lr"])
            print("  question:", e["qr"])

    stats = {
        "seed": SEED,
        "structurally_valid_m1_corruptions_before_semantic_filtering": n0,
        "nonexclusive_flags": dict(nonex),
        "sequential_rejections": dict(sorted(seq.items())),
        "clean_pool_corruptions": len(clean_pool),
        "clean_pool_distinct_source_problems": len(by_item),
        "clean_pool_swap_distribution": dict(Counter(f"{e['cor']['original_operator']}->{e['cor']['replacement_operator']}" for e in clean_pool)),
        "clean_pool_error_step_distribution": dict(sorted(Counter(e["cor"]["error_step"] for e in clean_pool).items())),
        "reviewer_semantic_rejections": [{"key": list(k), "reason": r} for k, r in reviewer_rejected],
        "pending_reviewer_checks": len(pending),
    }
    if len(selected) < N_CANDIDATES:
        stats["status"] = (f"INCOMPLETE: {len(selected)} of {N_CANDIDATES} clean candidates; "
                           + (f"{len(pending)} reviewer checks pending" if pending else
                              "every remaining pool corruption failed the reviewer semantic check"))
        # write a full audit of the post-keyword pool so each verdict can be checked; no clean file is written
        audit = []
        for e in clean_pool:
            key = (e["i"], e["cor"]["calc_id"], e["cor"]["replacement_operator"])
            e["rev"] = REVIEWER_SEMANTIC_CHECK.get(key) or {"pass": None, "sentence_sensible": None, "values_plausible": None,
                                                           "reason": "not reviewed", "sentence_note": "", "values_note": ""}
            audit.append(make_record(e, records, eligible, f"pool_{len(audit) + 1:02d}"))
        with open(OUT_POOL_AUDIT, "w", encoding="utf-8") as f:
            f.write("POST-KEYWORD CLEAN POOL: FULL AUDIT (no candidate here is approved; markers exist ONLY in this file)\n\n")
            f.write("\n\n".join(review_block(n, r) for n, r in enumerate(audit, 1)) + "\n")
        with open(OUT_STATS, "w", encoding="utf-8") as f:
            json.dump(stats, f, indent=2, default=str)
        print(json.dumps(stats, indent=2, default=str))
        return 2

    out = [make_record(e, records, eligible, f"m1_clean_{n:02d}") for n, e in enumerate(selected, 1)]
    assert all(r["semantic_plausibility"]["pass"] and not r["overall_obviousness"] and r["automatic_validation"]["ALL_PASS"] for r in out)
    write_outputs(out, stats)
    return 0


def make_record(e, records, eligible, cand_id):
    i, cor, checks = e["i"], e["cor"], e["checks"]
    r = s2.build_record(i, records[i], eligible[i], cor, None, None, checks)
    for k in ("obvious_from_local_wording", "obviousness_reason"):
        r.pop(k)
    r["candidate_id"] = cand_id
    r["local_wording_cue"], r["local_wording_reason"] = e["lc"], e["lr"]
    r["question_wording_cue"], r["question_wording_reason"] = e["qc"], e["qr"]
    r["overall_obviousness"] = e["lc"] or e["qc"]
    rev = e["rev"]
    sp_checks = {
        "no_unit_mismatch": {"pass": not e["um"], "method": "automatic", "reason": e["ur"]},
        "no_contradiction_with_question_relation": {"pass": not e["qc"], "method": "automatic", "reason": e["qr"]},
        "corrupted_intermediate_plausible": {"pass": e["ok_mid"], "method": "automatic", "reason": e["nr"]},
        "corrupted_final_plausible": {"pass": e["ok_final"], "method": "automatic", "reason": e["nr"]},
        "same_family_swap_resembles_slip": {"pass": True, "method": "automatic",
                                            "reason": "+/- confusion (sign slip) keeps operands and unit; a known arithmetic/reasoning slip type"},
        "sentence_remains_sensible": {"pass": rev["sentence_sensible"], "method": "reviewer", "reason": rev["sentence_note"]},
        "values_plausible_in_context": {"pass": rev["values_plausible"], "method": "reviewer", "reason": rev["values_note"]},
    }
    r["semantic_plausibility"] = {
        "pass": all(c["pass"] is True for c in sp_checks.values()),
        "reason": rev["reason"],
        "reviewer": "Claude (coding assistant) during dataset construction; human review pending",
        "checks": sp_checks,
    }
    r["propagation_explanation"] = propagation_explanation(r)
    return r


def write_outputs(out, stats):
    with open(OUT_JSON, "w", encoding="utf-8") as f:
        json.dump({"seed": SEED, "generator": "scripts/build_m1_clean.py",
                   "structural_pipeline": "scripts/build_m1_candidates.py (unchanged)", "candidates": out},
                  f, indent=2, ensure_ascii=False)
    with open(OUT_REVIEW, "w", encoding="utf-8") as f:
        f.write("CLEAN M1 CANDIDATES FOR MANUAL REVIEW  (markers exist ONLY in this review file)\n\n")
        f.write("\n\n".join(review_block(n, r) for n, r in enumerate(out, 1)) + "\n")
    stats["status"] = "COMPLETE"
    stats["selected"] = {
        "source_indices": [r["source_index"] for r in out],
        "error_step_distribution": dict(sorted(Counter(r["error_step"] for r in out).items())),
        "swap_distribution": dict(Counter(f"{r['original_operator']}->{r['replacement_operator']}" for r in out)),
        "n_steps_distribution": dict(sorted(Counter(r["n_steps"] for r in out).items())),
        "all_validation_pass": all(r["automatic_validation"]["ALL_PASS"] for r in out),
        "all_semantic_pass": all(r["semantic_plausibility"]["pass"] for r in out),
        "any_obvious": any(r["overall_obviousness"] for r in out),
    }
    with open(OUT_STATS, "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2, default=str)
    print(open(OUT_REVIEW, encoding="utf-8").read())
    print(json.dumps(stats, indent=2, default=str))


if __name__ == "__main__":
    sys.exit(main())
