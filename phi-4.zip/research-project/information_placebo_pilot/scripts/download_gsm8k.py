"""Download GSM8K train/test JSONL from the official OpenAI repository.

Source: https://github.com/openai/grade-school-math (MIT license)
Files are pinned to a specific commit so reruns fetch identical bytes.
Raw files are written once to data/raw/ and never modified afterwards.

Usage (from the project root):
    python scripts/download_gsm8k.py
"""
import hashlib
import json
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RAW_DIR = ROOT / "data" / "raw"
LOG_DIR = ROOT / "logs"

REPO = "openai/grade-school-math"
# Pinned commit of the official repo (see logs/download_log.json for what was fetched).
COMMIT = "3101c7d5072418e28b9008a6636bde82a006892c"
FILES = ["train.jsonl", "test.jsonl"]
URL_TMPL = "https://raw.githubusercontent.com/{repo}/{commit}/grade_school_math/data/{name}"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    log = {"repo": REPO, "commit": COMMIT, "fetched_at": datetime.now(timezone.utc).isoformat(), "files": []}
    for name in FILES:
        dest = RAW_DIR / name
        url = URL_TMPL.format(repo=REPO, commit=COMMIT, name=name)
        if dest.exists():
            print(f"[skip] {dest} already exists (raw data is never overwritten)")
        else:
            print(f"[get ] {url}")
            urllib.request.urlretrieve(url, dest)
        n_lines = sum(1 for _ in open(dest, encoding="utf-8"))
        digest = sha256(dest)
        print(f"       {name}: {n_lines} lines, sha256={digest}")
        log["files"].append({"name": name, "url": url, "lines": n_lines, "sha256": digest})
    with open(LOG_DIR / "download_log.json", "w", encoding="utf-8") as f:
        json.dump(log, f, indent=2)
    return 0


if __name__ == "__main__":
    sys.exit(main())
