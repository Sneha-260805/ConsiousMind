"""Stage 1 inspection of GSM8K structure for controlled M1 (wrong-operation) corruption.

Reads data/raw/train.jsonl (never modified) and writes:
  outputs/gsm8k_inspection.json         per-example analysis for N examples (default: train idx 0..19)
  outputs/gsm8k_train_annotation_stats.json  aggregate statistics over the whole train split
  outputs/representative_examples.txt   5 representative examples in readable form

Nothing here calls an LLM, and nothing here writes corrupted data to data/pilot/.
The "throwaway swap test" only computes, in memory, what would happen if one
single-operator annotation had its operator swapped, to measure feasibility.

Usage (from the project root):
    python scripts/inspect_gsm8k.py
    python scripts/inspect_gsm8k.py --n 20 --start 0 --show 1 2 3 4 5
"""
import argparse
import ast
import json
import operator
import re
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RAW_TRAIN = ROOT / "data" / "raw" / "train.jsonl"
OUT_DIR = ROOT / "outputs"

ANNOT_RE = re.compile(r"<<([^<>]*)>>")
NUM_RE = re.compile(r"(?<![\w.])-?\d[\d,]*(?:\.\d+)?|(?<![\w.])\.\d+")
FINAL_SEP = "\n#### "
# A visible calculation as written in prose: optional "a op b = " echo, the <<...>> annotation, then the visible result.
_NUMTOK = r"\$?\(?\d[\d,]*(?:\.\d+)?\)?%?"
CALC_SPAN_RE = re.compile(r"(?:" + _NUMTOK + r"\s*(?:[x×*/+\-÷]\s*" + _NUMTOK + r"\s*)+=\s*)?\$?<<[^<>]*>>\$?\d[\d,]*(?:\.\d+)?")
ALGEBRA_RE = re.compile(r"\bLet [A-Za-z] be\b|\b\d+[A-Z]\b|\b[a-z]\s*=\s*\d")

# Small numbers implied by words in the question (e.g. "half" -> 2). Used only for provenance tracing.
WORD_NUMBERS = {
    "half": [2, 0.5], "twice": [2], "double": [2], "triple": [3], "thrice": [3], "quarter": [4, 0.25],
    "dozen": [12], "one": [1], "two": [2], "three": [3], "four": [4], "five": [5], "six": [6],
    "seven": [7], "eight": [8], "nine": [9], "ten": [10], "eleven": [11], "twelve": [12],
    "thirteen": [13], "fourteen": [14], "fifteen": [15], "sixteen": [16], "seventeen": [17],
    "eighteen": [18], "nineteen": [19], "twenty": [20], "thirty": [30], "forty": [40], "fifty": [50],
    "hundred": [100], "thousand": [1000], "third": [3], "fourth": [4], "fifth": [5], "tenth": [10],
    "percent": [100], "%": [100], "once": [1], "pair": [2],
}
# World-knowledge constants that commonly appear without being stated in the question.
IMPLICIT_CONSTANTS = {1, 2, 7, 10, 12, 24, 30, 52, 60, 100, 365, 1000}

BINOPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
          ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod, ast.Pow: operator.pow}
OP_SYMBOL = {ast.Add: "+", ast.Sub: "-", ast.Mult: "*", ast.Div: "/", ast.FloorDiv: "//", ast.Mod: "%", ast.Pow: "**"}
M1_SWAP = {"+": "-", "-": "+", "*": "/", "/": "*"}


# ---------------------------------------------------------------- helpers
def to_num(s):
    s = s.replace(",", "")
    try:
        v = float(s)
    except ValueError:
        return None
    return int(v) if v.is_integer() else v


def close(a, b):
    if a is None or b is None:
        return False
    return abs(a - b) <= 1e-6 * max(1.0, abs(a), abs(b)) or round(a, 2) == round(b, 2)


def safe_eval(expr):
    """Evaluate a pure arithmetic expression. Returns (value, n_binops, ops, operands) or raises ValueError."""
    tree = ast.parse(expr, mode="eval")
    ops, operands = [], []

    def ev(node):
        if isinstance(node, ast.Expression):
            return ev(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            operands.append(node.value)
            return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in BINOPS:
            left, right = ev(node.left), ev(node.right)
            if isinstance(node.op, ast.Pow) and abs(right) > 100:
                raise ValueError("exponent too large")
            ops.append(OP_SYMBOL[type(node.op)])
            return BINOPS[type(node.op)](left, right)
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
            return -ev(node.operand)
        raise ValueError(f"unsupported node {type(node).__name__}")

    val = ev(tree)
    return val, len(ops), ops, operands


def numbers_in(text):
    return [n for n in (to_num(m.group()) for m in NUM_RE.finditer(text)) if n is not None]


def question_numbers(q):
    nums = set(numbers_in(q))
    low = q.lower()
    for w, vals in WORD_NUMBERS.items():
        if re.search(r"\b" + re.escape(w) + r"\b", low) or (w == "%" and "%" in q):
            nums.update(vals)
    # percentages: "25%" also usable as 0.25
    for m in re.finditer(r"(\d+(?:\.\d+)?)\s*%", q):
        nums.add(to_num(str(float(m.group(1)) / 100)))
    return nums


def strip_annotations(text):
    return ANNOT_RE.sub("", text)


def free_prose(text):
    """Prose with every annotated calculation span (visible echo + annotation + visible result) removed."""
    return CALC_SPAN_RE.sub(" ", text)


# ---------------------------------------------------------------- per-example analysis
def analyse(idx, rec):
    q, a = rec["question"], rec["answer"]
    issues = []
    if FINAL_SEP in a:
        body, final_raw = a.rsplit(FINAL_SEP, 1)
    else:
        body, final_raw = a, None
        issues.append("no '#### ' final-answer separator")
    final = to_num(final_raw.strip()) if final_raw is not None else None
    if final_raw is not None and final is None:
        issues.append(f"final answer not numeric: {final_raw!r}")

    lines = [ln for ln in body.split("\n") if ln.strip()]
    q_nums = question_numbers(q)

    annots, prior_results = [], []  # prior_results: list of (annotation_index, value)
    for step_i, line in enumerate(lines, start=1):
        for m in ANNOT_RE.finditer(line):
            inner = m.group(1)
            rec_a = {"step": step_i, "raw": m.group(0), "expression": None, "stated_result": None,
                     "evaluated": None, "evaluates_correctly": None, "n_operators": None, "operators": [],
                     "operands": [], "operand_sources": [], "visible_result_after": None, "parse_error": None}
            if inner.count("=") != 1:
                rec_a["parse_error"] = f"expected exactly one '=', got {inner.count('=')}"
            else:
                expr, res = inner.split("=")
                rec_a["expression"], rec_a["stated_result"] = expr, to_num(res.strip())
                try:
                    val, nops, ops, operands = safe_eval(expr)
                    rec_a.update(evaluated=val, n_operators=nops, operators=ops, operands=operands,
                                 evaluates_correctly=close(val, rec_a["stated_result"]))
                except (ValueError, SyntaxError, ZeroDivisionError, TypeError) as e:
                    rec_a["parse_error"] = f"{type(e).__name__}: {e}"
            # Is the stated result echoed visibly right after the annotation (e.g. ">>24 clips")?
            after = line[m.end():m.end() + 15]
            after_nums = numbers_in(after)
            rec_a["visible_result_after"] = bool(after_nums) and close(after_nums[0], rec_a["stated_result"])
            # Provenance of each operand
            for opd in rec_a["operands"]:
                srcs = []
                for (k, v) in prior_results:
                    if close(opd, v):
                        srcs.append(f"result#{k}")
                if opd in q_nums or any(close(opd, x) for x in q_nums):
                    srcs.append("question")
                if not srcs and opd in IMPLICIT_CONSTANTS:
                    srcs.append("implicit_constant")
                rec_a["operand_sources"].append(srcs or ["UNRESOLVED"])
            annots.append(rec_a)
            if rec_a["stated_result"] is not None:
                prior_results.append((len(annots) - 1, rec_a["stated_result"]))

    # Dependency edges between annotations
    edges, ambiguous = [], 0
    for j, an in enumerate(annots):
        for srcs in an["operand_sources"]:
            prev = [int(s.split("#")[1]) for s in srcs if s.startswith("result#")]
            if len(srcs) > 1:
                ambiguous += 1
            for i in prev:
                edges.append([i, j])
    n_unresolved = sum(srcs == ["UNRESOLVED"] for an in annots for srcs in an["operand_sources"])

    # Numbers that appear in prose (outside annotated calc spans) but come from neither the question,
    # any annotation result, nor a common constant => a value computed in prose without an annotation.
    known = set(q_nums) | {v for _, v in prior_results} | IMPLICIT_CONSTANTS
    hidden_values = []
    for i, ln in enumerate(lines, start=1):
        for x in numbers_in(free_prose(ln)):
            if not any(close(x, k) for k in known):
                hidden_values.append({"step": i, "value": x})
    algebraic = bool(ALGEBRA_RE.search(body))

    last_res = annots[-1]["stated_result"] if annots else None
    final_matches_last = close(final, last_res)
    any_bad_eval = any(an["evaluates_correctly"] is False for an in annots)
    any_parse_err = any(an["parse_error"] for an in annots)

    # ------------- throwaway M1 swap feasibility test (in memory only, nothing saved as data)
    swap_tests = []
    for k, an in enumerate(annots):
        if an["n_operators"] != 1 or an["operators"][0] not in M1_SWAP or an["parse_error"]:
            continue
        old_op = an["operators"][0]
        new_op = M1_SWAP[old_op]
        new_expr = an["expression"].replace(old_op, new_op, 1) if an["expression"].count(old_op) == 1 else None
        if new_expr is None:
            continue
        try:
            new_val = safe_eval(new_expr)[0]
        except (ZeroDivisionError, OverflowError, ValueError):
            continue
        # propagate through annotation chain by value substitution of exact dependent operands
        values = {k: new_val}
        for j in range(k + 1, len(annots)):
            aj = annots[j]
            if aj["parse_error"] or not aj["operands"]:
                continue
            deps = [(p, srcs) for p, srcs in zip(aj["operands"], aj["operand_sources"])
                    if any(s.startswith("result#") and int(s.split("#")[1]) in values for s in srcs)]
            if not deps:
                continue
            expr_j = aj["expression"]
            for p, srcs in deps:
                src = next(int(s.split("#")[1]) for s in srcs if s.startswith("result#") and int(s.split("#")[1]) in values)
                # replace the literal token for p with the new upstream value (first occurrence only)
                tok = re.search(r"(?<![\d.])" + re.escape(_fmt(p)) + r"(?![\d.])", expr_j.replace(",", ""))
                if tok:
                    e = expr_j.replace(",", "")
                    expr_j = e[:tok.start()] + _fmt(values[src]) + e[tok.end():]
            if any(values[int(s.split("#")[1])] is None for _, srcs in deps for s in srcs if s.startswith("result#") and int(s.split("#")[1]) in values):
                values[j] = None
                continue
            try:
                values[j] = safe_eval(expr_j)[0]
            except (ValueError, SyntaxError, ZeroDivisionError, TypeError, OverflowError):
                values[j] = None
        new_final = values.get(len(annots) - 1, last_res)
        # how many times does the old intermediate value appear in later prose (outside annotations)?
        old_val = an["stated_result"]
        later_prose = free_prose("\n".join(lines[an["step"]:]))
        prose_mentions = sum(close(x, old_val) for x in numbers_in(later_prose))
        same_step_free = sum(close(x, old_val) for x in numbers_in(free_prose(lines[an["step"] - 1])))
        swap_tests.append({
            "annotation_index": k, "step": an["step"], "original": an["expression"], "corrupted": new_expr,
            "op_change": f"{old_op} -> {new_op}", "original_value": old_val, "corrupted_value": _round(new_val),
            "corrupted_value_is_integer": _is_int(new_val), "corrupted_value_non_negative": new_val is not None and new_val >= 0,
            "propagated_final": _round(new_final), "final_changes": new_final is not None and not close(new_final, final),
            "is_final_step": k == len(annots) - 1,
            "old_value_mentions_in_later_prose": prose_mentions,
            "old_value_mentions_in_same_step_prose": same_step_free,
        })

    # ------------- suitability heuristic (conservative)
    reasons = []
    if any_parse_err: reasons.append("annotation parse error")
    if any_bad_eval: reasons.append("annotation result disagrees with its own expression")
    if not annots: reasons.append("no calculator annotations")
    if not final_matches_last: reasons.append("final answer != last annotation result")
    if n_unresolved: reasons.append(f"{n_unresolved} operand(s) not traceable to question or earlier result")
    if ambiguous: reasons.append(f"{ambiguous} operand(s) with ambiguous provenance (value coincidence)")
    if hidden_values: reasons.append("value(s) computed in prose without annotation: " + ", ".join(f"{h['value']} (step {h['step']})" for h in hidden_values))
    if algebraic: reasons.append("algebraic/symbolic solution (variables); annotations do not capture the reasoning")
    if annots and not (2 <= len(annots) <= 6): reasons.append(f"{len(annots)} annotations (want 2-6)")
    clean_swaps = [s for s in swap_tests if s["corrupted_value_is_integer"] and s["corrupted_value_non_negative"]
                   and s["final_changes"]]
    if not clean_swaps: reasons.append("no single-op swap that yields a plausible (non-negative integer) changed answer")
    suitable = not reasons
    if suitable:
        why = (f"{len(annots)} well-formed annotations, all operands traceable, final answer = last annotation, "
               f"{len(clean_swaps)} clean single-op swap candidate(s)")
    else:
        why = "; ".join(reasons)

    return {
        "source": "gsm8k/train.jsonl", "source_index": idx,
        "question": q, "original_answer_text": a,
        "extracted_final_answer": final,
        "calculator_expressions": [an["raw"] for an in annots],
        "n_calculator_expressions": len(annots),
        "proposed_steps": [{"step": i, "text": ln, "text_without_annotations": strip_annotations(ln)}
                           for i, ln in enumerate(lines, start=1)],
        "n_steps": len(lines),
        "annotation_details": annots,
        "dependency_edges": edges,
        "explicitly_chained": bool(edges),
        "hidden_unannotated_values": hidden_values,
        "algebraic_solution": algebraic,
        "final_equals_last_annotation": final_matches_last,
        "throwaway_swap_tests": swap_tests,
        "suitable_for_M1": suitable,
        "suitability_reason": why,
        "data_issues": issues,
    }


def _fmt(v):
    if v is None:
        return "None"
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return repr(v) if isinstance(v, float) else str(v)


def _round(v):
    if v is None:
        return None
    return int(v) if float(v).is_integer() else round(v, 4)


def _is_int(v):
    return v is not None and abs(v - round(v)) < 1e-9


# ---------------------------------------------------------------- aggregate stats over full train split
def aggregate(records):
    c = Counter()
    n_annots = Counter()
    for idx, rec in enumerate(records):
        r = analyse(idx, rec)
        c["examples"] += 1
        n_annots[r["n_calculator_expressions"]] += 1
        dets = r["annotation_details"]
        c["annotations"] += len(dets)
        c["annotations_parse_error"] += sum(bool(d["parse_error"]) for d in dets)
        c["annotations_wrong_result"] += sum(d["evaluates_correctly"] is False for d in dets)
        c["annotations_single_operator"] += sum(d["n_operators"] == 1 for d in dets)
        c["annotations_multi_operator"] += sum((d["n_operators"] or 0) > 1 for d in dets)
        c["annotations_without_visible_result_after"] += sum(not d["visible_result_after"] for d in dets)
        c["examples_with_zero_annotations"] += r["n_calculator_expressions"] == 0
        c["examples_final_ne_last_annotation"] += not r["final_equals_last_annotation"]
        c["examples_with_unresolved_operand"] += any("UNRESOLVED" in s for d in dets for s in d["operand_sources"])
        c["examples_with_ambiguous_operand"] += any(len(s) > 1 for d in dets for s in d["operand_sources"])
        c["examples_with_hidden_unannotated_value"] += bool(r["hidden_unannotated_values"])
        c["examples_algebraic"] += r["algebraic_solution"]
        c["examples_explicitly_chained"] += r["explicitly_chained"]
        c["examples_with_data_issue"] += bool(r["data_issues"])
        c["examples_suitable_heuristic"] += r["suitable_for_M1"]
        sw = r["throwaway_swap_tests"]
        c["swap_candidates"] += len(sw)
        c["swap_candidates_old_value_free_mention_in_later_prose"] += sum(s["old_value_mentions_in_later_prose"] > 0 for s in sw)
        c["swap_candidates_old_value_free_mention_in_same_step"] += sum(s["old_value_mentions_in_same_step_prose"] > 0 for s in sw)
        c["swap_candidates_nonint_or_negative"] += sum(not (s["corrupted_value_is_integer"] and s["corrupted_value_non_negative"]) for s in sw)
        c["swap_candidates_final_step"] += sum(s["is_final_step"] for s in sw)
    return {"counts": dict(c), "annotations_per_example_histogram": dict(sorted(n_annots.items()))}


# ---------------------------------------------------------------- pretty printing
def pretty(r):
    out = []
    out.append("=" * 88)
    out.append(f"EXAMPLE  train[{r['source_index']}]")
    out.append("-" * 88)
    out.append("PROBLEM\n  " + r["question"])
    out.append("GOLD SOLUTION\n  " + r["original_answer_text"].replace("\n", "\n  "))
    out.append("EXTRACTED STEPS")
    for st in r["proposed_steps"]:
        out.append(f"  {st['step']}. {st['text_without_annotations']}")
    out.append("CALCULATIONS FOUND")
    for i, d in enumerate(r["annotation_details"]):
        srcs = ", ".join(f"{o}<-{'/'.join(s)}" for o, s in zip(d["operands"], d["operand_sources"]))
        flag = "" if d["evaluates_correctly"] else f"  [!! {d['parse_error'] or 'stated result != evaluated'}]"
        out.append(f"  #{i} (step {d['step']}) {d['raw']}   operands: {srcs}{flag}")
    if r["dependency_edges"]:
        out.append("  dependency edges (result#i -> annotation#j): " + ", ".join(f"{i}->{j}" for i, j in r["dependency_edges"]))
    for s in r["throwaway_swap_tests"]:
        out.append(f"  [throwaway swap] #{s['annotation_index']}: {s['original']} -> {s['corrupted']} = {s['corrupted_value']}"
                   f" | propagated final = {s['propagated_final']} | old value reappears in later prose x{s['old_value_mentions_in_later_prose']}")
    out.append(f"FINAL ANSWER\n  {r['extracted_final_answer']}")
    out.append(f"SUITABLE FOR M1?  {'yes' if r['suitable_for_M1'] else 'no'}")
    out.append(f"WHY?\n  {r['suitability_reason']}")
    if r["data_issues"]:
        out.append(f"DATA ISSUES: {r['data_issues']}")
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", type=int, default=0)
    ap.add_argument("--n", type=int, default=20)
    ap.add_argument("--show", type=int, nargs="*", default=None,
                    help="train indices to print as representative examples (default: chosen in REPRESENTATIVE)")
    args = ap.parse_args()

    records = [json.loads(l) for l in open(RAW_TRAIN, encoding="utf-8")]
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    sample = [analyse(i, records[i]) for i in range(args.start, args.start + args.n)]
    with open(OUT_DIR / "gsm8k_inspection.json", "w", encoding="utf-8") as f:
        json.dump(sample, f, indent=2, ensure_ascii=False)

    stats = aggregate(records)
    with open(OUT_DIR / "gsm8k_train_annotation_stats.json", "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2)

    show = args.show if args.show is not None else REPRESENTATIVE
    text = "\n\n".join(pretty(analyse(i, records[i])) for i in show)
    with open(OUT_DIR / "representative_examples.txt", "w", encoding="utf-8") as f:
        f.write(text + "\n")

    print(text)
    print("\n" + "=" * 88)
    print(f"Sample train[{args.start}:{args.start + args.n}]: "
          f"{sum(r['suitable_for_M1'] for r in sample)}/{len(sample)} pass the conservative suitability heuristic")
    for r in sample:
        print(f"  train[{r['source_index']:>4}] n_calc={r['n_calculator_expressions']} suitable={'Y' if r['suitable_for_M1'] else 'n'}  {r['suitability_reason']}")
    print("\nFull-train aggregate:")
    print(json.dumps(stats, indent=2))
    return 0


# Representative examples printed by default (chosen after manually reviewing train[0:20]):
#   0  short clean chain (suitable)
#   3  longer clean chain, suitable, but gold solution names the wrong person ("Maila" vs "Julie")
#  19  value coincidence (200 from question == 200 from earlier result) -> naive propagation gives a WRONG final
#   9  value computed in prose with no annotation (54*5 = 270) -> annotation chain is incomplete
#  10  algebraic solution (S, 2S, 4S); annotations capture only fragments of the reasoning
REPRESENTATIVE = [0, 3, 19, 9, 10]

if __name__ == "__main__":
    sys.exit(main())
