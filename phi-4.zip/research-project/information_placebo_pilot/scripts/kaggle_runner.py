"""Kaggle-side helpers for the Information-or-Placebo pilot (Qwen/Qwen3-4B, free Kaggle GPU).

Used by kaggle/run_qwen3_pilot.ipynb. Everything experimental goes through the SAME audited harness
(run_pilot.execute, backends.HFTransformersBackend, parse_answers, score_pilot), so the prompts, smoke-item
selection, execution order, parsing and scoring are identical to the local pipeline.

Deliberately NOT provided: any function that runs the full 225-request pilot. The notebook stops after the
10-request smoke test.
"""
import hashlib
import json
import os
import re
import shutil
import statistics
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

BUNDLE_ID = "info-placebo-pilot-bundle"
WORK = Path("/kaggle/working/pilot")              # writable copy of the bundle (mirrors the repo layout)
RESULTS = Path("/kaggle/working/results")          # smoke -> results/smoke, canary -> results/diagnostics
CONFIG_REL = "configs/qwen3_4b_kaggle.json"
PINNED_PACKAGES = {"transformers": "5.19.0", "accelerate": "1.15.0"}   # same as the audited local env
# frozen experimental inputs (must match the local project exactly)
FROZEN_SHA256 = {
    "data/pilot/m3_pilot_40.json": "2f6ba3f034a3aeb7c57cd5245b59d692aa3b7d95762b5d6d1c02e9b143eec190",
    "data/pilot/m3_pilot_40_conditions.jsonl": "b664f96d4a531a95de965ab11f52ed4b5fd183ddde99c700960a1f6dc2b426a1",
    "data/pilot/m3_pilot_40_far_false_sensitivity.jsonl": "d7327d59dff90b2a9df83fb9c3ac4872ad83d82c3a6271888fa4eb846ef2ca16",
    "outputs/pilot_execution_order.json": "1678c95a21655671b1a8445f63ef5f19798255533eab58cf5b8d85d8205d384b",
}
CANARY_PROMPT = "What is 2 + 2?\nReturn the final answer on the last line exactly as:\nFINAL_ANSWER: <answer>"
HF_TOKEN_HELP = (
    "Hugging Face asked for authentication. Qwen/Qwen3-4B is public, so this is unexpected. Do NOT paste a "
    "token into the notebook. Instead: Kaggle editor -> Add-ons -> Secrets -> add a secret named HF_TOKEN "
    "(a read-only token from huggingface.co/settings/tokens), tick it for this notebook, then run:\n"
    "    from kaggle_secrets import UserSecretsClient\n"
    "    import os; os.environ['HF_TOKEN'] = UserSecretsClient().get_secret('HF_TOKEN')\n"
    "and re-run the model-load cell.")


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def save(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def stop(msg):
    raise SystemExit("STOP: " + msg)


# ------------------------------------------------------------------ CELL 1: GPU
def gpu_check():
    """CUDA must be available and must actually execute an FP16 kernel (catches GPUs the installed
    PyTorch build no longer supports). Never falls back to CPU."""
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")   # deterministic cuBLAS (set before CUDA init)
    import torch
    info = {"checked": now(), "torch": torch.__version__, "torch_cuda_build": torch.version.cuda,
            "cuda_available": torch.cuda.is_available()}
    print("torch.cuda.is_available():", info["cuda_available"])
    if not info["cuda_available"]:
        stop("CUDA is not available. In the Kaggle editor: Settings -> Accelerator -> GPU T4 x2 (or P100), "
             "then restart the session. The notebook will not run on CPU.")
    p = torch.cuda.get_device_properties(0)
    info.update(device_count=torch.cuda.device_count(), device_name=torch.cuda.get_device_name(0),
                capability=f"{p.major}.{p.minor}", vram_gb=round(p.total_memory / 1e9, 2),
                arch_list=torch.cuda.get_arch_list())
    print("torch.cuda.get_device_name(0):", info["device_name"])
    print("GPU VRAM (GB):", info["vram_gb"], "| compute capability:", info["capability"],
          "| GPUs visible:", info["device_count"])
    try:
        a = torch.randn(256, 256, device="cuda:0", dtype=torch.float16)
        val = float((a @ a).float().abs().mean())
        torch.cuda.synchronize()
        info["fp16_kernel_ok"] = val == val
    except Exception as e:                                      # e.g. "no kernel image is available"
        info["fp16_kernel_ok"] = False
        info["fp16_kernel_error"] = repr(e)
    print("FP16 CUDA kernel test:", "OK" if info["fp16_kernel_ok"] else info.get("fp16_kernel_error"))
    if not info["fp16_kernel_ok"]:
        stop("this GPU cannot run the installed PyTorch CUDA kernels (common with P100 on recent PyTorch). "
             "Switch the accelerator to 'GPU T4 x2' and restart.")
    if info["vram_gb"] < 12:
        stop(f"GPU has {info['vram_gb']} GB VRAM; FP16 Qwen3-4B needs about 9-10 GB plus headroom.")
    return info


# ------------------------------------------------------------------ CELL 2: packages
def ensure_packages():
    """Pin transformers/accelerate to the audited versions; keep Kaggle's own CUDA build of torch.
    Must run BEFORE transformers is imported in this session."""
    from importlib import metadata
    if "transformers" in sys.modules:
        stop("transformers is already imported in this session; restart the session and run cells in order.")
    need = []
    for pkg, ver in PINNED_PACKAGES.items():
        try:
            have = metadata.version(pkg)
        except metadata.PackageNotFoundError:
            have = None
        print(f"{pkg}: installed {have}, required {ver}")
        if have != ver:
            need.append(f"{pkg}=={ver}")
    if need:
        print("installing:", need, "(torch is left untouched)")
        r = subprocess.run([sys.executable, "-m", "pip", "install", "-q", *need], capture_output=True, text=True)
        print(r.stdout[-2000:], r.stderr[-2000:])
        if r.returncode != 0:
            stop("pip install failed (is Internet enabled in Settings? It requires a phone-verified account).")
    vers = {p: metadata.version(p) for p in ["torch", "transformers", "accelerate", "safetensors", "tokenizers",
                                              "huggingface_hub"]}
    print("versions:", vers)
    if any(vers[p] != v for p, v in PINNED_PACKAGES.items()):
        stop("pinned versions not active; restart the session and re-run from CELL 1.")
    return vers


# ------------------------------------------------------------------ CELL 3: bundle + hashes
def find_bundle():
    hits = []
    for m in Path("/kaggle/input").rglob("manifest.json"):
        try:
            if json.loads(m.read_text(encoding="utf-8")).get("bundle_id") == BUNDLE_ID:
                hits.append(m.parent)
        except Exception:
            pass
    if len(hits) != 1:
        stop(f"expected exactly one uploaded bundle with manifest bundle_id={BUNDLE_ID}, found {hits}. "
             "Attach the dataset via 'Add Input'.")
    return hits[0]


def stage_and_verify():
    """Copy the read-only bundle to /kaggle/working/pilot and verify EVERY file against manifest.json, and
    the four frozen experimental files against the hard-coded frozen hashes. Any difference -> STOP."""
    src = find_bundle()
    manifest = json.loads((src / "manifest.json").read_text(encoding="utf-8"))
    if WORK.exists():
        shutil.rmtree(WORK)
    shutil.copytree(src, WORK)
    bad = []
    for rel, h in manifest["files"].items():
        p = WORK / rel
        if not p.exists():
            bad.append(f"missing {rel}")
        elif sha256_file(p) != h:
            bad.append(f"hash mismatch {rel}")
    for rel, h in FROZEN_SHA256.items():
        if manifest["files"].get(rel) != h or sha256_file(WORK / rel) != h:
            bad.append(f"frozen hash mismatch {rel}")
    print(f"bundle: {src}\nfiles checked: {len(manifest['files'])} | frozen experimental files: {len(FROZEN_SHA256)}")
    for rel, h in FROZEN_SHA256.items():
        got = sha256_file(WORK / rel)
        print(f"  {rel}: {got[:16]}...  {'OK' if got == h else 'MISMATCH'}")
    if bad:
        stop("hash verification failed: " + "; ".join(bad))
    sys.path.insert(0, str(WORK / "scripts"))
    print("all hashes match; scripts importable from", WORK / "scripts")
    return manifest


# ------------------------------------------------------------------ CELL 4: model
def _auth_guard(e):
    if any(s in repr(e) for s in ("401", "403", "GatedRepo", "Unauthorized", "authentication")):
        print(HF_TOKEN_HELP)
        stop("authentication required")


def load_model():
    """Provenance = Hub SHA verified BEFORE loading (HfApi().model_info(repo, revision).sha == pinned),
    then tokenizer + model loaded from the local snapshot directory of that commit. Transformers'
    config._commit_hash is recorded but never required (None is normal).
    If a model object loaded earlier in this session still exists it is re-used (no reload, no download);
    a second 8 GB copy is never stacked on the GPU."""
    import gc
    import torch
    import backends as be
    cfg = json.loads((WORK / CONFIG_REL).read_text(encoding="utf-8"))
    try:
        hub_sha = be.verify_pinned_revision(cfg["model"], cfg["model_revision"])
    except be.BackendConfigError as e:
        stop(str(e))
    except Exception as e:
        _auth_guard(e)
        raise
    print("requested_revision:   ", cfg["model_revision"])
    print("hub_resolved_revision:", hub_sha, "(verified before loading)")

    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")          # isinstance() over all objects can touch deprecated torch attrs
        existing = [o for o in gc.get_objects() if isinstance(o, be.HFTransformersBackend)]
    t0 = time.time()
    if len(existing) > 1:
        stop(f"{len(existing)} model objects in memory; restart the session")
    if existing and hasattr(existing[0], "provenance"):
        backend, how = existing[0], "re-used the model object already loaded in this session (no reload)"
    elif existing:
        stop("a model object from an older bundle version is in memory; use the session-1 bridge cell or "
             "restart the session")
    else:
        gc.collect()
        torch.cuda.empty_cache()
        if torch.cuda.memory_allocated(0) > 1e9:
            stop("GPU memory is still occupied by an earlier attempt; restart the session")
        torch.cuda.reset_peak_memory_stats(0)
        try:
            backend = be.make_backend(cfg)
        except Exception as e:
            _auth_guard(e)
            raise
        how = "loaded from the pinned snapshot (Hub cache re-used; no forced re-download)"
    eff = backend.effective_settings()
    load = {"loaded": now(), "how": how, "load_seconds": round(time.time() - t0, 1),
            "requested_revision": cfg["model_revision"], "hub_resolved_revision": hub_sha,
            "transformers_commit_hash": eff.get("transformers_commit_hash"),
            "snapshot_path": eff.get("snapshot_path"), "effective_settings": eff, "versions": backend.versions(),
            "gpu_memory_allocated_gb": round(torch.cuda.memory_allocated(0) / 1e9, 2),
            "gpu_memory_peak_gb": round(torch.cuda.max_memory_allocated(0) / 1e9, 2)}
    save(RESULTS / "diagnostics" / "model_load.json", load)
    print(how)
    print("transformers_commit_hash:", load["transformers_commit_hash"], "(informational; null is fine)")
    print("snapshot_path:", load["snapshot_path"])
    print("model dtype:", eff["dtype"], "| device:", eff["device"])
    print("enable_thinking:", eff["enable_thinking"], "| decoding:", eff["decoding"],
          "| max_new_tokens:", eff["max_new_tokens"])
    print(f"GPU memory allocated {load['gpu_memory_allocated_gb']} GB")
    if eff["hub_resolved_revision"] != cfg["model_revision"]:
        stop("model was not loaded from the Hub-verified pinned revision")
    if "float16" not in eff["dtype"] or eff["device"] != "cuda:0":
        stop(f"unexpected dtype/device {eff['dtype']} {eff['device']}")
    if (eff["enable_thinking"] is not False or eff["max_new_tokens"] != cfg["max_new_tokens"]
            or eff["decoding"] != "greedy (do_sample=False, num_beams=1)"):
        stop("generation settings differ from the protocol")
    return backend


# ------------------------------------------------------------------ CELL 5: template
def template_report(backend):
    """The backend already refused to start unless check_chat_template passed; this re-renders harmless
    probes with the real tokenizer and shows the wrapper (backend metadata only, never dataset text)."""
    import backends as be
    probes = ["Harmless probe one: describe a red apple in five words.",
              "Second harmless probe -- what colour is the sky on a clear day? (answer briefly)"]
    be.TEMPLATE_PROBES[:] = probes
    res = be.check_chat_template(backend.render, enable_thinking=False)
    t_on = backend.render(probes[0], True)
    i = t_on.index(probes[0])
    esc = lambda s: s.encode("unicode_escape").decode("ascii")
    audit = {"checked": now(), "checks": {k: v for k, v in res.items() if k not in ("prefix", "suffix")},
             "non_thinking_wrapper": {"prefix": res["prefix"], "suffix": res["suffix"]},
             "thinking_wrapper_for_comparison": {"prefix": t_on[:i], "suffix": t_on[i + len(probes[0]):]},
             "same_wrapper_as_startup_check": res["prefix"] == backend.template_check["prefix"]
                                               and res["suffix"] == backend.template_check["suffix"]}
    save(RESULTS / "diagnostics" / "template_audit.json", audit)
    print("non-thinking:", esc(res["prefix"]) + "<USER PROMPT PLACEHOLDER>" + esc(res["suffix"]))
    print("thinking    :", esc(t_on[:i]) + "<USER PROMPT PLACEHOLDER>" + esc(t_on[i + len(probes[0]):]))
    print("checks:", audit["checks"])
    if not audit["same_wrapper_as_startup_check"]:
        stop("template wrapper differs between checks")
    return audit


# ------------------------------------------------------------------ CELL 6: canary
def canary(backend):
    """Non-experimental. Stored only in results/diagnostics/, never in the smoke-test directory."""
    from parse_answers import parse_response
    t0 = time.perf_counter()
    res = backend.generate(CANARY_PROMPT)
    lat = time.perf_counter() - t0
    p = parse_response(res.text)
    think = "<think>" in res.text or "</think>" in res.text or bool(res.metadata.get("think_tag_in_output"))
    out = {"DIAGNOSTIC_ONLY": "canary; not an experimental result", "timestamp": now(), "prompt": CANARY_PROMPT,
           "response": res.text, "metadata": res.metadata, "latency_seconds": round(lat, 2), "parse": p,
           "checks": {"numeric_answer_is_4": p["numeric_parsed_answer"] == "4",
                      "no_visible_thinking": not think,
                      "parser_succeeds": p["numeric_parse_status"] == "ok"}}
    out["passed"] = all(out["checks"].values())
    save(RESULTS / "diagnostics" / "canary.json", out)
    print("canary response:", repr(res.text))
    print("latency", out["latency_seconds"], "s | new tokens", res.metadata.get("new_tokens"),
          "| checks", out["checks"])
    if not out["passed"]:
        stop("canary failed; do not run experimental prompts")
    return out


# ------------------------------------------------------------------ CELL 7: smoke test (10 requests only)
def smoke_test(backend, run_id=None):
    """Fresh smoke run named after the token limit (e.g. results/smoke_768); never appends to an old run."""
    import argparse
    import torch
    import run_pilot as rp
    cfg = json.loads((WORK / CONFIG_REL).read_text(encoding="utf-8"))
    run_id = run_id or f"smoke_{cfg['max_new_tokens']}"
    if (RESULTS / run_id / "raw_outputs.jsonl").exists():
        stop(f"results/{run_id} already has outputs; refusing to append (archive it or use a new run_id)")
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats(0)
    args = argparse.Namespace(config=str(WORK / CONFIG_REL), run_id=run_id, mode="smoke", dry_run=False,
                              sequential=False, max_requests=None, output_root=str(RESULTS))
    run_dir, stats = rp.execute(args, backend=backend)
    selected = json.loads((run_dir / "config.json").read_text(encoding="utf-8"))["selected_requests"]
    assert len(selected) == 10 and {r["analysis_condition"] for r in selected} == \
        {"L0", "V", "L_false_near", "L", "A"}, "smoke selection is not 2 items x 5 primary conditions"
    print("smoke run directory:", run_dir, "| stats:", stats)
    return run_dir


# ------------------------------------------------------------------ CELL 8/9: score + diagnostics
def environment_record(gpu, versions):
    import torch
    return {"recorded": now(), "python": sys.version, "gpu": gpu, "package_versions": versions,
            "kaggle_docker_image": os.environ.get("KAGGLE_DOCKER_IMAGE"),
            "kaggle_kernel_run_type": os.environ.get("KAGGLE_KERNEL_RUN_TYPE"),
            "cublas_workspace_config": os.environ.get("CUBLAS_WORKSPACE_CONFIG"),
            "cudnn_version": torch.backends.cudnn.version()}


def score_and_diagnose(run_dir, gpu, versions):
    import torch
    from score_pilot import score_run
    summary, scored = score_run(run_dir)
    raw = [json.loads(l) for l in (Path(run_dir) / "raw_outputs.jsonl").read_text(encoding="utf-8").splitlines()]
    lat = [r["latency_seconds"] for r in raw]
    toks = [r["model_metadata"]["response"].get("new_tokens") for r in raw]
    fails = Path(run_dir) / "transport_failures.jsonl"
    diag = {
        "LABEL": "PIPELINE CHECK ONLY - NOT AN EXPERIMENTAL RESULT - N=2 ITEMS",
        "requested": summary["n_planned"], "completed": summary["n_completed"],
        "transport_failures": len(fails.read_text(encoding="utf-8").splitlines()) if fails.exists() else 0,
        "numeric_parse_ok": sum(not s["numeric_parse_failure"] for s in scored),
        "numeric_parse_failures": sum(s["numeric_parse_failure"] for s in scored),
        "strict_format_ok": sum(not s["strict_format_failure"] for s in scored),
        "strict_format_failures": sum(s["strict_format_failure"] for s in scored),
        "final_line_fallback_count": sum(s["numeric_parse_source"] == "final_line_fallback" for s in scored),
        "hit_max_new_tokens": sum(r["model_metadata"]["response"].get("finish_reason") == "length" for r in raw),
        "think_tag_in_any_output": any(r["model_metadata"]["response"].get("think_tag_in_output") for r in raw),
        "latency_mean_s": round(statistics.mean(lat), 2) if lat else None,
        "latency_median_s": round(statistics.median(lat), 2) if lat else None,
        "generated_tokens_mean": round(statistics.mean([t for t in toks if t is not None]), 1) if toks else None,
        "generated_tokens_max": max([t for t in toks if t is not None], default=None),
        "retries": sum(r["attempt_count"] - 1 for r in raw),
        "gpu_peak_memory_gb": round(torch.cuda.max_memory_allocated(0) / 1e9, 2),
        "gold_matches_pipeline_check_only": sum(s["is_gold_correct"] for s in scored),
    }
    # per-response flags
    by_key = {s["request_key"]: s for s in scored}
    flags = []
    for r in raw:
        m, sc = r["model_metadata"]["response"], by_key[r["request_key"]]
        f = {"hits_max_new_tokens": m.get("finish_reason") == "length",
             "numeric_parse_failed": sc["numeric_parse_failure"],
             "lacks_final_answer": re.search(r"final_answer\s*:", r["raw_response"], re.I) is None,
             "visible_thinking": "<think>" in r["raw_response"] or "</think>" in r["raw_response"]
                                 or bool(m.get("think_tag_in_output"))}
        if any(f.values()):
            flags.append({"item_id": r["item_id"], "condition": r["analysis_condition"],
                          "new_tokens": m.get("new_tokens"), **{k: v for k, v in f.items() if v}})
    diag["flagged_responses"] = flags
    # acceptance gate for moving to the 225-request pilot (decision stays with the researcher)
    import pilot_common as pc
    frozen = {q["request_key"]: q["prompt"] for q in pc.load_requests()}
    gate = {"completed_10_of_10": diag["completed"] == 10 == diag["requested"],
            "transport_failures_0": diag["transport_failures"] == 0,
            "numeric_parse_10_of_10": diag["numeric_parse_ok"] == 10,
            "hit_max_new_tokens_0": diag["hit_max_new_tokens"] == 0,
            "no_visible_thinking": not diag["think_tag_in_any_output"]
                                   and not any(f.get("visible_thinking") for f in flags),
            "prompts_byte_identical_to_frozen": all(r["prompt"] == frozen[r["request_key"]] for r in raw)}
    diag["gate"] = gate
    diag["decision"] = ("GO (pending researcher approval; the 225-request pilot is NOT launched)"
                        if all(gate.values()) else "NO-GO")
    save(Path(run_dir) / "smoke_diagnostics.json", diag)
    save(Path(run_dir) / "environment.json", environment_record(gpu, versions))
    for k, v in diag.items():
        print(f"{k:34s} {v}")
    print("\nNo condition comparison is made. The notebook stops here; the 225-request pilot is NOT launched.")
    return diag
