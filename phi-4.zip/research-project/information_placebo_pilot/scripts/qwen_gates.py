"""Gated preparation of the real Qwen3-4B backend (run inside .venv-qwen).

Each subcommand is one gate; it saves its evidence under outputs/diagnostics/ and exits non-zero on
failure, so nothing later runs:

  env        record interpreter, pip and package versions
  tokenizer  resolve the pinned revision, download ONLY config/tokenizer files, audit the real chat template
  ram        free-RAM gate (>= min_free_ram_gb from the config)
  canary     RAM gate -> download pinned weights -> load -> ONE non-experimental canary prompt
             (stored only in outputs/diagnostics/qwen3_canary/) -> optionally --then-smoke: the 10-request
             smoke test through run_pilot with the SAME loaded backend

The canary never touches outputs/runs/. Experimental prompts are never printed here.
"""
import argparse
import hashlib
import json
import os
import platform
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import backends as be  # noqa: E402
import pilot_common as pc  # noqa: E402

CFG_PATH = pc.ROOT / "configs" / "qwen3_4b_pilot.json"
SETUP_DIR = pc.ROOT / "outputs" / "diagnostics" / "qwen3_setup"
CANARY_DIR = pc.ROOT / "outputs" / "diagnostics" / "qwen3_canary"
CANARY_PROMPT = "What is 2 + 2?\nReturn the final answer on the last line exactly as:\nFINAL_ANSWER: <answer>"
TOKENIZER_PATTERNS = ["config.json", "generation_config.json", "tokenizer.json", "tokenizer_config.json",
                      "vocab.json", "merges.txt", "special_tokens_map.json", "added_tokens.json",
                      "model.safetensors.index.json"]
PROBES = ["Harmless probe one: describe a red apple in five words.",
          "Second harmless probe -- what colour is the sky on a clear day? (answer briefly)"]


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def save(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def cfg():
    return json.loads(CFG_PATH.read_text(encoding="utf-8"))


def esc(s):
    return s.encode("unicode_escape").decode("ascii")


# ------------------------------------------------------------------ env
def cmd_env(_):
    pip = subprocess.run([sys.executable, "-m", "pip", "--version"], capture_output=True, text=True).stdout.strip()
    freeze = subprocess.run([sys.executable, "-m", "pip", "freeze"], capture_output=True, text=True).stdout.split()
    info = {"recorded": now(), "python": platform.python_version(), "executable": sys.executable,
            "in_venv": sys.prefix != sys.base_prefix, "pip": pip, "platform": platform.platform(),
            "key_packages": be.package_versions(["torch", "transformers", "accelerate", "safetensors", "tokenizers",
                                                 "huggingface_hub", "bitsandbytes", "numpy", "psutil"]),
            "pip_freeze": freeze}
    try:
        import torch
        info["torch_build"] = {"import_ok": True, "version": torch.__version__,
                               "cuda_available": torch.cuda.is_available(),
                               "xpu_available": bool(getattr(torch, "xpu", None) and torch.xpu.is_available()),
                               "default_num_threads": torch.get_num_threads()}
    except Exception as e:                       # e.g. WinError 4551: Smart App Control blocks unsigned DLLs
        info["torch_build"] = {"import_ok": False, "error": f"{type(e).__name__}: {e}"}
    save(SETUP_DIR / "environment.json", info)
    print(json.dumps({k: info[k] for k in ("python", "pip", "in_venv", "key_packages", "torch_build")}, indent=2))
    if not info["torch_build"]["import_ok"]:
        sys.exit("GATE FAILED: torch cannot be imported in this environment")


# ------------------------------------------------------------------ tokenizer + template
def cmd_tokenizer(_):
    from huggingface_hub import HfApi, snapshot_download
    c = cfg()
    api = HfApi()
    info = api.model_info(c["model"], revision=c["model_revision"], files_metadata=True)
    resolved = info.sha
    files = [{"name": s.rfilename, "size": s.size} for s in info.siblings]
    weights = [f for f in files if f["name"].endswith(".safetensors")]
    rev_ok = resolved == c["model_revision"]
    local = snapshot_download(c["model"], revision=c["model_revision"], allow_patterns=TOKENIZER_PATTERNS)
    downloaded = sorted(p.name for p in Path(local).iterdir())
    leaked_weights = [n for n in downloaded if n.endswith((".safetensors", ".bin", ".pt"))]
    model_cfg = json.loads((Path(local) / "config.json").read_text(encoding="utf-8"))
    gen_cfg = json.loads((Path(local) / "generation_config.json").read_text(encoding="utf-8"))
    rev = {"checked": now(), "repo": c["model"], "requested_revision": c["model_revision"],
           "resolved_commit": resolved, "revision_matches": rev_ok, "repo_files": files,
           "weight_files": weights, "weight_bytes_total": sum(f["size"] or 0 for f in weights),
           "downloaded_files_this_step": downloaded, "weights_downloaded_this_step": leaked_weights,
           "model_config_summary": {k: model_cfg.get(k) for k in ("architectures", "model_type", "torch_dtype",
                                                                   "num_hidden_layers", "hidden_size",
                                                                   "num_attention_heads", "num_key_value_heads",
                                                                   "vocab_size", "tie_word_embeddings",
                                                                   "max_position_embeddings")},
           "generation_config": gen_cfg}
    save(SETUP_DIR / "revision_check.json", rev)
    print(json.dumps({k: rev[k] for k in ("resolved_commit", "revision_matches", "weight_bytes_total",
                                          "downloaded_files_this_step", "weights_downloaded_this_step")}, indent=2))
    print("weight files:", [(w["name"], w["size"]) for w in weights])
    print("model config:", rev["model_config_summary"])
    if not rev_ok or leaked_weights:
        sys.exit("GATE FAILED: revision mismatch or weights downloaded during tokenizer step")

    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(c["model"], revision=c["model_revision"])

    def render(p, think):
        return tok.apply_chat_template([{"role": "user", "content": p}], tokenize=False,
                                       add_generation_prompt=True, enable_thinking=think)

    be.TEMPLATE_PROBES[:] = PROBES          # harmless probes, unrelated to the dataset
    audit = {"checked": now(), "resolved_commit": resolved,
             "chat_template_sha256": hashlib.sha256(tok.chat_template.encode("utf-8")).hexdigest(),
             "tokenizer_class": type(tok).__name__}
    try:
        res = be.check_chat_template(render, enable_thinking=False)
        audit["checks"] = {k: v for k, v in res.items() if k not in ("prefix", "suffix")}
        audit["non_thinking_wrapper"] = {"prefix": res["prefix"], "suffix": res["suffix"]}
        audit["passed"] = True
    except be.BackendConfigError as e:
        audit["passed"] = False
        audit["failure"] = str(e)
    t_on = render(PROBES[0], True)
    t_off = render(PROBES[0], False)
    i_on = t_on.index(PROBES[0])
    audit["thinking_wrapper_for_comparison"] = {"prefix": t_on[:i_on], "suffix": t_on[i_on + len(PROBES[0]):]}
    audit["thinking_vs_nonthinking_differ"] = t_on != t_off
    audit["difference"] = ("non-thinking suffix = thinking suffix + " + repr(t_off[len(t_on):])
                           if t_off.startswith(t_on) else "renders differ (not a pure suffix extension)")
    audit["probe_counts"] = [render(p, False).count(p) for p in PROBES]
    save(SETUP_DIR / "template_audit.json", audit)
    if audit["passed"]:
        w = audit["non_thinking_wrapper"]
        print("\nnon-thinking render:\n  " + esc(w["prefix"]) + "<USER PROMPT PLACEHOLDER>" + esc(w["suffix"]))
        tw = audit["thinking_wrapper_for_comparison"]
        print("thinking render (comparison only):\n  " + esc(tw["prefix"]) + "<USER PROMPT PLACEHOLDER>" + esc(tw["suffix"]))
    print(json.dumps({k: audit[k] for k in ("passed", "chat_template_sha256", "thinking_vs_nonthinking_differ",
                                            "difference", "probe_counts")}, indent=2))
    print("checks:", audit.get("checks") or audit.get("failure"))
    if not audit["passed"]:
        sys.exit("GATE FAILED: chat template check")


# ------------------------------------------------------------------ RAM gate
def ram_status():
    import psutil
    vm, sw = psutil.virtual_memory(), psutil.swap_memory()
    return {"measured": now(), "total_gb": round(vm.total / 1e9, 2), "available_gb": round(vm.available / 1e9, 2),
            "used_percent": vm.percent, "pagefile_total_gb": round(sw.total / 1e9, 2),
            "pagefile_used_gb": round(sw.used / 1e9, 2), "pagefile_percent": sw.percent}


def ram_gate(tag):
    need = cfg()["min_free_ram_gb"]
    st = ram_status() | {"required_available_gb": need}
    st["passed"] = st["available_gb"] >= need
    st["shortfall_gb"] = round(max(0.0, need - st["available_gb"]), 2)
    save(SETUP_DIR / f"ram_gate_{tag}.json", st)
    print(json.dumps(st, indent=2))
    return st


def cmd_ram(_):
    if not ram_gate("pre_load")["passed"]:
        sys.exit("GATE FAILED: not enough free RAM")


# ------------------------------------------------------------------ download + load + canary (+ smoke)
def cmd_canary(args):
    import psutil
    from huggingface_hub import snapshot_download
    c = cfg()
    if not ram_gate("pre_download")["passed"]:
        sys.exit("GATE FAILED: not enough free RAM")
    t0 = time.time()
    local = Path(snapshot_download(c["model"], revision=c["model_revision"]))
    weights = sorted(local.glob("*.safetensors"))
    dl = {"finished": now(), "seconds": round(time.time() - t0, 1), "snapshot_dir": str(local),
          "weight_files": [{"name": w.name, "bytes": w.stat().st_size} for w in weights],
          "weight_bytes_total": sum(w.stat().st_size for w in weights)}
    save(SETUP_DIR / "download.json", dl)
    print("download:", json.dumps(dl, indent=2))
    if not ram_gate("pre_load")["passed"]:
        sys.exit("GATE FAILED: not enough free RAM right before loading")

    proc = psutil.Process()
    rss_before = proc.memory_info().rss
    t0 = time.time()
    try:
        backend = be.make_backend(c)
    except Exception as e:
        save(SETUP_DIR / "model_load.json", {"failed": now(), "error": repr(e)})
        sys.exit(f"GATE FAILED: model load raised {e!r}")
    load_s = time.time() - t0
    eff = backend.effective_settings()
    after = ram_status()
    mi = proc.memory_info()
    load = {"loaded": now(), "load_seconds": round(load_s, 1), "effective_settings": eff,
            "versions": backend.versions(), "process_rss_before_gb": round(rss_before / 1e9, 2),
            "process_rss_after_gb": round(mi.rss / 1e9, 2),
            "process_peak_working_set_gb": round(getattr(mi, "peak_wset", 0) / 1e9, 2) or None,
            "system_after_load": after}
    save(SETUP_DIR / "model_load.json", load)
    print("load:", json.dumps({k: load[k] for k in ("load_seconds", "process_rss_before_gb", "process_rss_after_gb",
                                                    "process_peak_working_set_gb")}, indent=2))
    print("dtype/device/hub revision:", eff["dtype"], eff["device"], eff["hub_resolved_revision"])
    if after["available_gb"] < 1.0 or after["pagefile_percent"] > 90:
        sys.exit("GATE FAILED: severe memory pressure after load")

    # ---- canary (diagnostic only; never written to outputs/runs)
    from parse_answers import parse_response
    t0 = time.perf_counter()
    res = backend.generate(CANARY_PROMPT)
    lat = time.perf_counter() - t0
    p = parse_response(res.text)
    visible_think = "<think>" in res.text or "</think>" in res.text or res.metadata.get("think_tag_in_output")
    canary = {"DIAGNOSTIC_ONLY": "canary; not an experimental result", "timestamp": now(),
              "prompt": CANARY_PROMPT, "response": res.text, "metadata": res.metadata,
              "latency_seconds": round(lat, 2), "parse": p, "effective_settings": eff,
              "checks": {"responded": bool(res.text.strip()), "no_visible_thinking_block": not visible_think,
                         "final_answer_parseable": p["numeric_parse_status"] == "ok",
                         "metadata_recorded": bool(res.metadata), "latency_measured": lat > 0}}
    canary["passed"] = all(canary["checks"].values())
    save(CANARY_DIR / "canary.json", canary)
    print("canary response:", repr(res.text))
    print("canary:", json.dumps({k: canary[k] for k in ("latency_seconds", "checks", "passed")}, indent=2),
          "| parsed:", p["numeric_parsed_answer"], "| tokens:", res.metadata.get("new_tokens"))
    if not canary["passed"]:
        sys.exit("GATE FAILED: canary")

    if args.then_smoke:
        import run_pilot as rp
        sargs = argparse.Namespace(config=str(CFG_PATH), run_id=args.run_id, mode="smoke", dry_run=False,
                                   sequential=False, max_requests=None, output_root=None)
        run_dir, stats = rp.execute(sargs, backend=backend)
        mi = proc.memory_info()
        perf = {"finished": now(), "stats": stats, "process_rss_end_gb": round(mi.rss / 1e9, 2),
                "process_peak_working_set_gb": round(getattr(mi, "peak_wset", 0) / 1e9, 2) or None,
                "system_end": ram_status()}
        save(run_dir / "process_memory.json", perf)
        print("smoke:", json.dumps(perf, indent=2))


# ------------------------------------------------------------------ download only (no loading)
def cmd_download(_):
    """Download every repo file at the pinned revision via the Hub cache (resumable). Never imports torch
    and never instantiates the model. Integrity = index shards present + sizes equal the Hub metadata +
    no .incomplete leftovers; no multi-GB hashing."""
    from huggingface_hub import HfApi, snapshot_download
    from huggingface_hub.constants import HF_HUB_CACHE
    c = cfg()
    info = HfApi().model_info(c["model"], revision=c["model_revision"], files_metadata=True)
    if info.sha != c["model_revision"]:
        sys.exit(f"GATE FAILED: revision resolved to {info.sha}, expected {c['model_revision']}")
    expected = {s.rfilename: s.size for s in info.siblings}
    lfs_sha = {s.rfilename: (s.lfs.sha256 if getattr(s, "lfs", None) else None) for s in info.siblings}
    start = datetime.now(timezone.utc)
    t0 = time.time()
    local = Path(snapshot_download(c["model"], revision=c["model_revision"]))
    elapsed = time.time() - t0
    end = datetime.now(timezone.utc)

    present = {p.name: p.stat().st_size for p in local.iterdir() if p.is_file()}
    index = json.loads((local / "model.safetensors.index.json").read_text(encoding="utf-8"))
    shards = sorted(set(index["weight_map"].values()))
    repo_cache = Path(HF_HUB_CACHE) / ("models--" + c["model"].replace("/", "--"))
    incomplete = [str(p.relative_to(repo_cache)) for p in repo_cache.rglob("*.incomplete")]
    problems = []
    for name, size in expected.items():
        if name not in present:
            problems.append(f"missing {name}")
        elif size is not None and present[name] != size:
            problems.append(f"size mismatch {name}: {present[name]} != {size}")
    problems += [f"index references missing shard {s}" for s in shards if s not in present]
    problems += [f"zero-byte file {n}" for n, b in present.items() if b == 0]
    problems += [f"leftover partial download {p}" for p in incomplete]
    rec = {"repository": c["model"], "requested_revision": c["model_revision"], "resolved_commit": info.sha,
           "cache_dir": str(HF_HUB_CACHE), "snapshot_dir": str(local),
           "download_start": start.isoformat(timespec="seconds"), "download_end": end.isoformat(timespec="seconds"),
           "elapsed_seconds": round(elapsed, 1),
           "files": [{"name": n, "bytes": present.get(n), "expected_bytes": expected[n],
                      "lfs_sha256_from_hub": lfs_sha[n]} for n in sorted(expected)],
           "weight_shards": [{"name": s, "bytes": present.get(s), "expected_bytes": expected.get(s)} for s in shards],
           "total_bytes_on_disk": sum(present.values()),
           "weight_bytes": sum(present.get(s, 0) for s in shards),
           "integrity": {"all_expected_files_present": not any(p.startswith("missing") for p in problems),
                         "sizes_match_hub_metadata": not any(p.startswith("size mismatch") for p in problems),
                         "all_index_shards_present": not any("missing shard" in p for p in problems),
                         "no_zero_byte_files": not any(p.startswith("zero-byte") for p in problems),
                         "no_incomplete_files": not incomplete, "sha256_recomputed": False,
                         "problems": problems, "passed": not problems},
           "model_loaded": False}
    save(SETUP_DIR / "download.json", rec)
    print(json.dumps({k: rec[k] for k in ("resolved_commit", "snapshot_dir", "elapsed_seconds", "weight_shards",
                                          "total_bytes_on_disk", "integrity")}, indent=2))
    if problems:
        sys.exit("GATE FAILED: download integrity")


# ------------------------------------------------------------------ sequential per-shard download + SHA-256
def keep_awake(on):
    """Windows only: ask the OS not to sleep while THIS process runs (SetThreadExecutionState).
    Not a power-setting change; it ends automatically when the process exits."""
    if os.name != "nt":
        return False
    import ctypes
    ES_CONTINUOUS, ES_SYSTEM_REQUIRED = 0x80000000, 0x00000001
    flags = ES_CONTINUOUS | (ES_SYSTEM_REQUIRED if on else 0)
    return bool(ctypes.windll.kernel32.SetThreadExecutionState(flags))


def sha256_of(path, block=8 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(block), b""):
            h.update(chunk)
    return h.hexdigest()


def cmd_download_sequential(_):
    from huggingface_hub import HfApi, hf_hub_download, snapshot_download
    from huggingface_hub.constants import HF_HUB_CACHE
    c = cfg()
    log_path = SETUP_DIR / "download_sequential.json"
    info = HfApi().model_info(c["model"], revision=c["model_revision"], files_metadata=True)
    rec = {"repository": c["model"], "requested_revision": c["model_revision"], "resolved_commit": info.sha,
           "cache_dir": str(HF_HUB_CACHE), "started": now(), "keep_awake_requested": keep_awake(True),
           "shards": [], "model_loaded": False}
    if info.sha != c["model_revision"]:
        save(log_path, rec | {"failed": "revision mismatch"})
        sys.exit(f"STOP: revision resolved to {info.sha}")
    meta = {s.rfilename: {"size": s.size, "sha256": s.lfs.sha256 if getattr(s, "lfs", None) else None}
            for s in info.siblings}
    # small non-weight files first (already-complete files are skipped by the Hub cache)
    local = Path(snapshot_download(c["model"], revision=c["model_revision"], ignore_patterns=["*.safetensors"]))
    index = json.loads((local / "model.safetensors.index.json").read_text(encoding="utf-8"))
    shards = sorted(set(index["weight_map"].values()))
    rec["index_shards"] = shards
    save(log_path, rec)
    for name in shards:
        exp = meta[name]
        entry = {"name": name, "expected_bytes": exp["size"], "expected_sha256": exp["sha256"]}
        path = local / name
        try:
            if path.exists() and path.stat().st_size == exp["size"]:
                entry["action"] = "already complete in cache; not re-downloaded (verified below)"
                entry["download_seconds"] = 0.0
            else:
                entry["action"] = "downloaded (fresh, sequential)"
                entry["start"] = now()
                print(f"{now()} downloading {name} ({exp['size']} bytes) ...", flush=True)
                t0 = time.time()
                path = Path(hf_hub_download(c["model"], name, revision=c["model_revision"]))
                entry["download_seconds"] = round(time.time() - t0, 1)
                entry["end"] = now()
            entry["actual_bytes"] = path.stat().st_size
            t0 = time.time()
            entry["actual_sha256"] = sha256_of(path)
            entry["hash_seconds"] = round(time.time() - t0, 1)
        except Exception as e:
            entry["error"] = f"{type(e).__name__}: {e}"
            entry["result"] = "FAIL"
            rec["shards"].append(entry)
            save(log_path, rec | {"stopped_at": name})
            keep_awake(False)
            sys.exit(f"STOP: {name} failed: {entry['error']}")
        entry["size_ok"] = entry["actual_bytes"] == exp["size"]
        entry["sha256_ok"] = entry["actual_sha256"] == exp["sha256"]
        entry["result"] = "PASS" if entry["size_ok"] and entry["sha256_ok"] else "FAIL"
        rec["shards"].append(entry)
        save(log_path, rec)
        print(f"{now()} {name}: {entry['result']} bytes={entry['actual_bytes']} sha256_ok={entry['sha256_ok']} "
              f"download_s={entry['download_seconds']} hash_s={entry['hash_seconds']}", flush=True)
        if entry["result"] != "PASS":
            keep_awake(False)
            sys.exit(f"STOP: {name} failed verification")

    # final integrity audit over the whole snapshot
    present = {p.name: p.stat().st_size for p in local.iterdir() if p.is_file()}
    repo_cache = Path(HF_HUB_CACHE) / ("models--" + c["model"].replace("/", "--"))
    incomplete = [str(p.relative_to(repo_cache)) for p in repo_cache.rglob("*.incomplete")]
    missing = [n for n in meta if n not in present]
    size_bad = [n for n in meta if n in present and meta[n]["size"] is not None and present[n] != meta[n]["size"]]
    zero = [n for n, b in present.items() if b == 0]
    rec["final_audit"] = {
        "resolved_commit_matches": info.sha == c["model_revision"],
        "all_expected_files_present": not missing, "missing": missing,
        "sizes_match_hub_metadata": not size_bad, "size_mismatches": size_bad,
        "all_index_shards_present": all(s in present for s in shards),
        "all_weight_shard_sha256_match": all(s["sha256_ok"] for s in rec["shards"]),
        "no_zero_byte_files": not zero, "zero_byte_files": zero,
        "no_incomplete_files": not incomplete, "incomplete_files": incomplete,
        "model_loaded": False,
        "total_weight_bytes": sum(present[s] for s in shards),
        "total_snapshot_bytes": sum(present.values()),
        "snapshot_dir": str(local),
    }
    fa = rec["final_audit"]
    fa["passed"] = all(fa[k] for k in ("resolved_commit_matches", "all_expected_files_present",
                                       "sizes_match_hub_metadata", "all_index_shards_present",
                                       "all_weight_shard_sha256_match", "no_zero_byte_files", "no_incomplete_files"))
    rec["finished"] = now()
    keep_awake(False)
    save(log_path, rec)
    print(json.dumps(fa, indent=2), flush=True)
    if not fa["passed"]:
        sys.exit("STOP: final integrity audit failed")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("download-sequential")
    sub.add_parser("env")
    sub.add_parser("tokenizer")
    sub.add_parser("ram")
    sub.add_parser("download")
    cp = sub.add_parser("canary")
    cp.add_argument("--then-smoke", action="store_true")
    cp.add_argument("--run-id", default="qwen3_4b_smoke_01")
    a = ap.parse_args()
    {"env": cmd_env, "tokenizer": cmd_tokenizer, "ram": cmd_ram, "download": cmd_download,
     "download-sequential": cmd_download_sequential, "canary": cmd_canary}[a.cmd](a)


if __name__ == "__main__":
    main()
