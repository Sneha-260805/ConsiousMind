"""TEST ONLY: harness tests with the deterministic mock backend and an in-process fake HTTP server.
No model is loaded and no external endpoint is contacted. Every run writes to a temporary directory
named test_runs, never to outputs/runs.

  python -m unittest scripts/test_harness.py -v      (from the project root)
"""
import argparse
import http.server
import json
import shutil
import sys
import tempfile
import threading
import unittest
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import backends as be  # noqa: E402
import pilot_common as pc  # noqa: E402
import run_pilot as rp  # noqa: E402
from parse_answers import parse_response  # noqa: E402
from score_pilot import score_row  # noqa: E402

MOCK_CFG = pc.ROOT / "configs" / "mock_test.json"


def args(run_id, mode="full", dry_run=False, output_root=None, max_requests=None, sequential=False, config=MOCK_CFG):
    return argparse.Namespace(config=str(config), run_id=run_id, mode=mode, dry_run=dry_run, sequential=sequential,
                              max_requests=max_requests, output_root=str(output_root) if output_root else None)


def thousands(n):
    return f"{n:,}"


# Controlled mock responses cycling over request keys: (text, strict status, numeric status, outcome).
# outcome is judged on the NUMERIC parser (repair metric); strict status is the format diagnostic.
def scripted_case(i, gold, corr):
    cases = [
        (f"Let me check.\nFINAL_ANSWER: {gold}", "ok", "ok", "gold"),
        (f"Work...\nFINAL_ANSWER: ${thousands(gold)}", "ok", "ok", "gold"),
        (f"FINAL_ANSWER: {gold}.0", "ok", "ok", "gold"),
        (f"I agree with the solution.\nFINAL_ANSWER: {corr}", "ok", "ok", "corrupted"),
        (f"FINAL_ANSWER: {gold + 7}", "ok", "ok", "other"),
        ("I am not sure what the answer is.", "missing", "missing", "fail"),
        (f"FINAL_ANSWER: {corr}\nWait, recheck.\nFINAL_ANSWER: {gold}", "ok", "ok", "gold"),
        (f"FINAL_ANSWER: about {gold} dollars", "non_numeric", "ok", "gold"),
        (f"final_answer: {corr}", "missing", "ok", "corrupted"),
        (f"FINAL_ANSWER: {gold} or {corr}", "non_numeric", "ambiguous", "fail"),
        (f"Step 2 gives {corr - 1}.\nSo the answer is {gold}.", "missing", "ok", "gold"),
        (f"Totals: {gold} and {corr}", "missing", "ambiguous", "fail"),
    ]
    return cases[i % len(cases)]


class TempWorld:
    """Copies the frozen inputs into a temp dir so tamper tests never touch the real files."""

    def __init__(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="pilot_harness_"))
        self.files = {}
        for name, path in pc.INPUT_FILES.items():
            dst = self.tmp / "inputs" / name
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, dst)
            self.files[name] = dst
        self.order = self.tmp / "pilot_execution_order.json"
        self.root = self.tmp / "test_runs"

    def cleanup(self):
        shutil.rmtree(self.tmp, ignore_errors=True)


def build_script(files):
    reqs = pc.load_requests(files)
    script, expected = {}, {}
    for i, r in enumerate(sorted(reqs, key=lambda r: r["request_key"])):
        text, strict, numeric, outcome = scripted_case(i, r["gold_answer"], r["corrupted_answer"])
        script[r["prompt_sha256"]] = text
        expected[r["request_key"]] = (strict, numeric, outcome)
    return script, expected


# ------------------------------------------------------------------ execution order
class TestExecutionOrder(unittest.TestCase):
    def test_order(self):
        reqs = pc.load_requests()
        doc1 = pc.order_document(reqs, pc.input_hashes())
        doc2 = pc.order_document(list(reversed(reqs)), pc.input_hashes())
        self.assertEqual(doc1["order"], doc2["order"], "order must not depend on input row order")
        order = doc1["order"]
        self.assertEqual(len(order), 225)
        self.assertEqual(len({o["request_key"] for o in order}), 225)
        self.assertEqual([o["run_index"] for o in order], list(range(225)))
        c = Counter(o["analysis_condition"] for o in order)
        self.assertEqual(c, Counter({"L0": 40, "V": 40, "L_false_near": 40, "L": 40, "A": 40, "L_false_far": 25}))
        self.assertNotIn("L_false", c)
        for o in order:
            if o["condition_source"] == "L_false":
                self.assertEqual((o["analysis_condition"], o["source_file"]), ("L_false_near", pc.PRIMARY))
            if o["condition_source"] == "L_false_far":
                self.assertEqual(o["source_file"], pc.SENSITIVITY)
        other = pc.order_document(reqs, pc.input_hashes(), seed=1)["order"]
        self.assertNotEqual([o["request_key"] for o in order], [o["request_key"] for o in other])

    def test_prompts_are_frozen_text(self):
        for r in pc.load_requests():
            src = pc.INPUT_FILES[r["source_file"]].read_text(encoding="utf-8").splitlines()[r["row_index"]]
            self.assertEqual(json.loads(src)["prompt"], r["prompt"])


# ------------------------------------------------------------------ parser
class TestParser(unittest.TestCase):
    CASES = [
        ("FINAL_ANSWER: 1920", "ok", "1920", False),
        ("reasoning\nFINAL_ANSWER: 1920", "ok", "1920", False),
        ("FINAL_ANSWER: $1,920", "ok", "1920", False),
        ("FINAL_ANSWER: 1,920", "ok", "1920", False),
        ("FINAL_ANSWER: 1920.0", "ok", "1920", False),
        ("FINAL_ANSWER: 1920.00", "ok", "1920", False),
        ('FINAL_ANSWER: "1920"', "ok", "1920", False),
        ("FINAL_ANSWER:    1920   ", "ok", "1920", False),
        ("FINAL_ANSWER:1920", "ok", "1920", False),
        ("FINAL_ANSWER: 1920.", "ok", "1920", False),
        ("**FINAL_ANSWER:** 1920", "ok", "1920", False),
        ("FINAL_ANSWER: **1920**", "ok", "1920", False),
        ("FINAL_ANSWER: `1920`", "ok", "1920", False),
        ("FINAL_ANSWER: -5", "ok", "-5", False),
        ("FINAL_ANSWER: 2.5", "ok", "2.5", False),
        ("FINAL_ANSWER: $1,234,567", "ok", "1234567", False),
        ("FINAL_ANSWER: 12\nmore text\nFINAL_ANSWER: 13", "ok", "13", True),
        ("FINAL_ANSWER: 13\nFINAL_ANSWER: abc", "non_numeric", None, True),
        ("The answer is 1920.", "missing", None, False),
        ("final_answer: 1920", "missing", None, False),
        ("Final Answer: 1920", "missing", None, False),
        ("", "missing", None, False),
        ("FINAL_ANSWER: <answer>", "non_numeric", None, False),
        ("FINAL_ANSWER: 1920 dollars", "non_numeric", None, False),
        ("FINAL_ANSWER: about 1920", "non_numeric", None, False),
        ("FINAL_ANSWER: 1,92", "non_numeric", None, False),
        ("FINAL_ANSWER: 12,3456", "non_numeric", None, False),
        ("FINAL_ANSWER: 40*48", "non_numeric", None, False),
        ("FINAL_ANSWER:\n1920", "non_numeric", None, False),
        ("FINAL_ANSWER: 1920 or 1880", "non_numeric", None, False),
    ]

    def test_cases(self):
        for text, status, value, multiple in self.CASES:
            with self.subTest(text=text):
                p = parse_response(text)
                self.assertEqual(p["strict_parse_status"], status)
                self.assertEqual(p["strict_parsed_answer"], value)
                self.assertEqual(p["multiple_final_answer_fields"], multiple)

    def test_last_line_flag(self):
        self.assertTrue(parse_response("x\nFINAL_ANSWER: 5")["final_answer_on_last_line"])
        self.assertFalse(parse_response("FINAL_ANSWER: 5\nThanks!")["final_answer_on_last_line"])


    def test_strict_ok_implies_numeric_same_value(self):
        for text, status, value, _ in self.CASES:
            if status == "ok":
                p = parse_response(text)
                self.assertEqual((p["numeric_parse_status"], p["numeric_parsed_answer"]), ("ok", value), text)


class TestNumericParser(unittest.TestCase):
    # (response, numeric status, value, source, strict status, strict format compliant)
    CASES = [
        ("FINAL_ANSWER: 1920 dollars", "ok", "1920", "final_answer_field", "non_numeric", False),
        ("final_answer: 1920", "ok", "1920", "final_answer_field", "missing", False),
        ("Final_Answer: $1,920", "ok", "1920", "final_answer_field", "missing", False),
        ("FINAL_ANSWER: 1920 or 1880", "ambiguous", None, "final_answer_field", "non_numeric", False),
        ("The answer is 1920.", "ok", "1920", "final_line_fallback", "missing", False),
        ("So 40 * 48 = 1920.", "ambiguous", None, "final_line_fallback", "missing", False),
        ("Step 1: 2/5*80 = 32.\nStep 2: 80-32 = 48.\nStep 3: 40*48 = 1920.\nThe total is $1,920.",
         "ok", "1920", "final_line_fallback", "missing", False),
        ("FINAL_ANSWER: 1920", "ok", "1920", "final_answer_field", "ok", True),
        ("FINAL_ANSWER: $1,920", "ok", "1920", "final_answer_field", "ok", True),
        ("FINAL_ANSWER: 1920.0", "ok", "1920", "final_answer_field", "ok", True),
        ("FINAL_ANSWER: 1920\nHope this helps!", "ok", "1920", "final_answer_field", "ok", False),
        ("FINAL_ANSWER: between 1900 and 2000", "ambiguous", None, "final_answer_field", "non_numeric", False),
        ("FINAL_ANSWER: 40*48 = 1920", "ambiguous", None, "final_answer_field", "non_numeric", False),
        ("FINAL_ANSWER: unknown", "non_numeric", None, "final_answer_field", "non_numeric", False),
        ("FINAL_ANSWER: 99\nThe answer is 1920.", "ok", "99", "final_answer_field", "ok", False),
        ("I could not solve it.", "missing", None, None, "missing", False),
        ("", "missing", None, None, "missing", False),
        ("The answer is 1920.\n\n   ", "ok", "1920", "final_line_fallback", "missing", False),
        ("Answer in the 3rd step: 1920", "ok", "1920", "final_line_fallback", "missing", False),
        ("FINAL_ANSWER: 1,92", "non_numeric", None, "final_answer_field", "non_numeric", False),
        ("**Final_Answer:** **$1,920**", "ok", "1920", "final_answer_field", "missing", False),
    ]

    def test_cases(self):
        for text, status, value, source, strict, compliant in self.CASES:
            with self.subTest(text=text):
                p = parse_response(text)
                self.assertEqual(p["numeric_parse_status"], status)
                self.assertEqual(p["numeric_parsed_answer"], value)
                self.assertEqual(p["numeric_parse_source"], source)
                self.assertEqual(p["numeric_ambiguous"], status == "ambiguous")
                self.assertEqual(p["strict_parse_status"], strict)
                self.assertEqual(p["strict_format_compliant"], compliant)


# ------------------------------------------------------------------ scorer
class TestScorer(unittest.TestCase):
    def row(self, text, gold=1920, corr=1880):
        return score_row({**parse_response(text), "gold_answer": gold, "corrupted_answer": corr})

    def flags(self, r):
        return (r["is_gold_correct"], r["is_corrupted_answer"], r["other_wrong_answer"],
                r["numeric_parse_failure"], r["strict_format_failure"])

    def test_flags(self):
        self.assertEqual(self.flags(self.row("FINAL_ANSWER: $1,920")), (True, False, False, False, False))
        self.assertEqual(self.flags(self.row("FINAL_ANSWER: 1880.0")), (False, True, False, False, False))
        self.assertEqual(self.flags(self.row("FINAL_ANSWER: 1921")), (False, False, True, False, False))
        # benign formatting deviations: correct answer, strict format failure
        self.assertEqual(self.flags(self.row("FINAL_ANSWER: 1920 dollars")), (True, False, False, False, True))
        self.assertEqual(self.flags(self.row("final_answer: 1880")), (False, True, False, False, True))
        self.assertEqual(self.flags(self.row("The answer is 1920.")), (True, False, False, False, True))
        # ambiguous / missing / non-numeric are numeric parse failures, never counted as gold
        for t in ("FINAL_ANSWER: 1920 or 1880", "no answer", "FINAL_ANSWER: none", "Totals: 1920 and 1880"):
            self.assertEqual(self.flags(self.row(t)), (False, False, False, True, True), t)
        self.assertFalse(self.row("FINAL_ANSWER: 1920.5")["is_gold_correct"])
        r = self.row("FINAL_ANSWER: 1920 dollars")
        self.assertEqual((r["strict_is_gold_correct"], r["is_gold_correct"]), (False, True))


# ------------------------------------------------------------------ chat template checks (fake renderers)
def qwen3_like(prompt, enable_thinking):
    """Mimics the documented Qwen3 template for one user message (no tokenizer download needed)."""
    s = f"<|im_start|>user\n{prompt}<|im_end|>\n<|im_start|>assistant\n"
    return s + ("" if enable_thinking else "<think>\n\n</think>\n\n")


class TestChatTemplateCheck(unittest.TestCase):
    def test_qwen3_like_passes(self):
        r = be.check_chat_template(qwen3_like, enable_thinking=False)
        self.assertTrue(r["empty_think_block_prefilled"])
        self.assertEqual(r["prefix"], "<|im_start|>user\n")
        self.assertEqual(r["suffix"], "<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n")

    def test_violations_are_caught(self):
        bad = {
            "ignores switch": lambda p, t: f"<|im_start|>user\n{p}<|im_end|>\n<|im_start|>assistant\n",
            "system prompt": lambda p, t: "<|im_start|>system\nBe helpful.<|im_end|>\n" + qwen3_like(p, t),
            "appends /no_think": lambda p, t: qwen3_like(p + (" /think" if t else " /no_think"), t),
            "content-dependent": lambda p, t: qwen3_like(p, t) + ("x" if "A" in p else ""),
            "non-empty think": lambda p, t: qwen3_like(p, True) + ("<think>Let me think" if not t else ""),
            "prompt altered": lambda p, t: qwen3_like(p.replace("Step", "step"), t),
        }
        for name, render in bad.items():
            with self.subTest(name=name), self.assertRaises(be.BackendConfigError):
                be.check_chat_template(render, enable_thinking=False)

    def test_hf_backend_refuses_low_ram_before_loading(self):
        cfg = json.loads((pc.ROOT / "configs" / "qwen3_4b_pilot.json").read_text(encoding="utf-8"))
        cfg["min_free_ram_gb"] = 10 ** 6       # impossible: must refuse before importing torch or downloading
        with self.assertRaises(be.BackendConfigError):
            be.make_backend(cfg)


# ------------------------------------------------------------------ end-to-end with the mock backend
class TestMockRuns(unittest.TestCase):
    def setUp(self):
        self.w = TempWorld()
        self.script, self.expected = build_script(self.w.files)

    def tearDown(self):
        self.w.cleanup()

    def run_mock(self, run_id, mock, **kw):
        return rp.execute(args(run_id, output_root=self.w.root, **kw), backend=mock, files=self.w.files,
                          order_path=self.w.order, sleep=lambda s: None)

    def test_full_run_persistence_parse_score(self):
        mock = be.MockBackend({}, script=self.script)
        run_dir, stats = self.run_mock("TEST_full", mock)
        self.assertEqual(stats["completed_now"], 225)
        raw = [json.loads(l) for l in (run_dir / "raw_outputs.jsonl").read_text(encoding="utf-8").splitlines()]
        self.assertEqual(len(raw), 225)
        # exact frozen prompt was sent and stored; one call per request; calls followed the run order
        src = {r["request_key"]: r["prompt"] for r in pc.load_requests(self.w.files)}
        self.assertEqual(len(mock.calls), 225)
        self.assertEqual(len(set(mock.calls)), 225)
        for row, sent in zip(raw, mock.calls):
            self.assertEqual(row["prompt"], src[row["request_key"]])
            self.assertEqual(sent, row["prompt"])
            self.assertTrue(row["test_only"])
            self.assertTrue(row["raw_response"].startswith(be.MOCK_BANNER))
        self.assertEqual([r["run_index"] for r in raw], list(range(225)))
        order = json.loads(self.w.order.read_text(encoding="utf-8"))["order"]
        self.assertEqual([r["request_key"] for r in raw], [o["request_key"] for o in order])
        # scoring matches the controlled expectations exactly
        scored = {json.loads(l)["request_key"]: json.loads(l)
                  for l in (run_dir / "scored_outputs.jsonl").read_text(encoding="utf-8").splitlines()}
        for key, (strict, numeric, outcome) in self.expected.items():
            s = scored[key]
            self.assertEqual(s["strict_parse_status"], strict, key)
            self.assertEqual(s["numeric_parse_status"], numeric, key)
            self.assertEqual(s["is_gold_correct"], outcome == "gold", key)
            self.assertEqual(s["is_corrupted_answer"], outcome == "corrupted", key)
            self.assertEqual(s["other_wrong_answer"], outcome == "other", key)
            self.assertEqual(s["numeric_parse_failure"], outcome == "fail", key)
        summary = json.loads((run_dir / "summary.json").read_text(encoding="utf-8"))
        self.assertTrue(summary["TEST_ONLY"])
        for cond, m in summary["by_analysis_condition"].items():
            rows = [s for s in scored.values() if s["analysis_condition"] == cond]
            self.assertEqual(m["n"], len(rows))
            self.assertEqual(m["gold_correct"], sum(s["is_gold_correct"] for s in rows))
        # paired tables: 40 primary items; far subset = exactly the 25 eligible items, same-item rates
        prim = (run_dir / "paired_primary.csv").read_text(encoding="utf-8").splitlines()
        self.assertEqual(prim[0], "item_id,L0_correct,V_correct,L_false_near_correct,L_correct,A_correct")
        self.assertEqual(len(prim), 41)
        far = (run_dir / "paired_far_subset.csv").read_text(encoding="utf-8").splitlines()
        self.assertEqual(len(far), 26)
        self.assertTrue(far[0].endswith("L_false_far_correct"))
        fs = summary["far_subset"]
        self.assertEqual(fs["n_items"], 25)
        for cond, m in fs["rates_on_same_items"].items():
            self.assertEqual(m["n"], 25, cond)
            expect = sum(scored[k]["is_gold_correct"] for k in scored
                         if scored[k]["analysis_condition"] == cond and scored[k]["item_id"] in fs["items"])
            self.assertEqual(m["gold_correct"], expect)
        self.assertEqual(json.loads((run_dir / "config.json").read_text(encoding="utf-8"))["TEST_ONLY"], True)

    def test_resume_after_crash_no_duplicates(self):
        crash = be.MockBackend({}, script=self.script, crash_after_calls=37)
        with self.assertRaises(be.SimulatedCrash):
            self.run_mock("TEST_resume", crash)
        run_dir = self.w.root / "TEST_resume"
        before = (run_dir / "raw_outputs.jsonl").read_bytes()
        self.assertEqual(len(before.splitlines()), 37)
        self.assertFalse((run_dir / "run.lock").exists(), "lock must be released after a crash")
        mock2 = be.MockBackend({}, script=self.script)
        _, stats = self.run_mock("TEST_resume", mock2)
        self.assertEqual(stats["completed_now"], 188)
        self.assertEqual(len(mock2.calls), 188)
        after = (run_dir / "raw_outputs.jsonl").read_bytes()
        self.assertTrue(after.startswith(before), "completed rows must never be rewritten")
        keys = [json.loads(l)["request_key"] for l in after.splitlines()]
        self.assertEqual(len(keys), 225)
        self.assertEqual(len(set(keys)), 225)
        mock3 = be.MockBackend({}, script=self.script)
        _, stats = self.run_mock("TEST_resume", mock3)
        self.assertEqual((stats["completed_now"], len(mock3.calls)), (0, 0), "a finished run sends nothing")
        self.assertIn("RESUME", (run_dir / "run_log.txt").read_text(encoding="utf-8"))

    def test_torn_final_line_is_repaired(self):
        with self.assertRaises(be.SimulatedCrash):
            self.run_mock("TEST_torn", be.MockBackend({}, script=self.script, crash_after_calls=5))
        raw = self.w.root / "TEST_torn" / "raw_outputs.jsonl"
        with open(raw, "ab") as fh:
            fh.write(b'{"run_id": "TEST_torn", "request_key": "prim')      # crash mid-write
        _, stats = self.run_mock("TEST_torn", be.MockBackend({}, script=self.script))
        self.assertEqual(stats["completed_now"], 220)
        keys = [json.loads(l)["request_key"] for l in raw.read_text(encoding="utf-8").splitlines()]
        self.assertEqual(len(set(keys)), 225)
        self.assertIn("RECOVERY: truncated a torn final line", (self.w.root / "TEST_torn" / "run_log.txt").read_text(encoding="utf-8"))

    def test_transport_retry_and_exhaustion(self):
        reqs = sorted(pc.load_requests(self.w.files), key=lambda r: r["request_key"])
        flaky, dead = reqs[0], reqs[1]
        mock = be.MockBackend({}, script=self.script,
                              transport_failures={flaky["prompt_sha256"]: 2, dead["prompt_sha256"]: 99})
        run_dir, stats = self.run_mock("TEST_retry", mock)    # mock_test.json: max_attempts = 3
        raw = {json.loads(l)["request_key"]: json.loads(l)
               for l in (run_dir / "raw_outputs.jsonl").read_text(encoding="utf-8").splitlines()}
        self.assertEqual(raw[flaky["request_key"]]["attempt_count"], 3)
        self.assertEqual(sum(1 for c in mock.calls if c == flaky["prompt"]), 3, "retries resend the same prompt")
        self.assertNotIn(dead["request_key"], raw, "no model response -> no raw row")
        self.assertEqual(stats["transport_failed"], 1)
        fails = (run_dir / "transport_failures.jsonl").read_text(encoding="utf-8").splitlines()
        self.assertEqual(json.loads(fails[0])["attempt_count"], 3)
        summary = json.loads((run_dir / "summary.json").read_text(encoding="utf-8"))
        cond = dead["analysis_condition"]
        self.assertEqual(summary["by_analysis_condition"][cond]["not_completed"], 1)
        # on resume only the failed request is attempted again
        mock2 = be.MockBackend({}, script=self.script)
        _, stats2 = self.run_mock("TEST_retry", mock2)
        self.assertEqual(mock2.calls, [dead["prompt"]])
        self.assertEqual(stats2["completed_now"], 1)

    def test_model_output_is_never_retried(self):
        bad = {h: "garbage output with no answer" for h in self.script}
        mock = be.MockBackend({}, script=bad)
        run_dir, stats = self.run_mock("TEST_noretry", mock, mode="smoke")
        self.assertEqual(len(mock.calls), 10)
        rows = [json.loads(l) for l in (run_dir / "raw_outputs.jsonl").read_text(encoding="utf-8").splitlines()]
        self.assertTrue(all(r["attempt_count"] == 1 for r in rows))
        s = json.loads((run_dir / "summary.json").read_text(encoding="utf-8"))
        self.assertTrue(all(m["numeric_parse_failure_rate"] == 1.0 for m in s["by_analysis_condition"].values()))

    def test_hash_change_blocks_resume(self):
        with self.assertRaises(be.SimulatedCrash):
            self.run_mock("TEST_hash", be.MockBackend({}, script=self.script, crash_after_calls=3))
        src = self.w.files["m3_pilot_40.json"]
        src.write_bytes(src.read_bytes() + b" ")                       # any byte change
        self.w.order.unlink()                                          # even with a fresh order file
        with self.assertRaises(SystemExit) as cm:
            self.run_mock("TEST_hash", be.MockBackend({}, script=self.script))
        self.assertIn("input file hashes changed", str(cm.exception))

    def test_order_file_mismatch_blocks(self):
        self.run_mock("TEST_order", be.MockBackend({}, script=self.script), mode="smoke")
        doc = json.loads(self.w.order.read_text(encoding="utf-8"))
        doc["order"][0], doc["order"][1] = doc["order"][1], doc["order"][0]
        doc["order_sha256"] = "tampered"
        self.w.order.write_text(json.dumps(doc), encoding="utf-8")
        with self.assertRaises(SystemExit):
            self.run_mock("TEST_order2", be.MockBackend({}, script=self.script), mode="smoke")

    def test_config_change_blocks_resume(self):
        with self.assertRaises(be.SimulatedCrash):
            self.run_mock("TEST_cfg", be.MockBackend({}, script=self.script, crash_after_calls=2))
        cfg = json.loads(MOCK_CFG.read_text(encoding="utf-8"))
        cfg["max_new_tokens"] = 256
        alt = self.w.tmp / "alt.json"
        alt.write_text(json.dumps(cfg), encoding="utf-8")
        with self.assertRaises(SystemExit) as cm:
            self.run_mock("TEST_cfg", be.MockBackend({}, script=self.script), config=alt)
        self.assertIn("model config changed", str(cm.exception))
        with self.assertRaises(SystemExit) as cm:
            self.run_mock("TEST_cfg", be.MockBackend({}, script=self.script), mode="smoke")
        self.assertIn("mode changed", str(cm.exception))

    def test_lock_blocks_concurrent_run(self):
        run_dir = self.w.root / "TEST_lock"
        run_dir.mkdir(parents=True)
        (run_dir / "run.lock").write_text("held", encoding="utf-8")
        with self.assertRaises(SystemExit) as cm:
            self.run_mock("TEST_lock", be.MockBackend({}, script=self.script), mode="smoke")
        self.assertIn("run.lock", str(cm.exception))

    def test_smoke_and_dry_run(self):
        run_dir, stats = rp.execute(args("DRY_smoke", mode="smoke", dry_run=True, output_root=self.w.root),
                                    backend=None, files=self.w.files, order_path=self.w.order)
        self.assertEqual(stats, {"planned": 10, "sent": 0})
        self.assertFalse((run_dir / "raw_outputs.jsonl").exists())
        planned = [json.loads(l) for l in (run_dir / "planned_requests.jsonl").read_text(encoding="utf-8").splitlines()]
        self.assertEqual(len(planned), 10)
        self.assertEqual(Counter(p["analysis_condition"] for p in planned),
                         Counter({c: 2 for c in pc.PRIMARY_CONDITIONS}))
        cfg = json.loads((run_dir / "config.json").read_text(encoding="utf-8"))
        steps = sorted(t for _, t in cfg["smoke_items"])
        self.assertEqual(len(steps), 2)
        self.assertEqual(steps[0], 2)
        self.assertGreaterEqual(steps[1], 4)
        self.assertTrue(cfg["TEST_ONLY"] and cfg["dry_run"])

    def test_output_root_guards(self):
        with self.assertRaises(SystemExit):     # mock may not write outside a test_runs tree
            rp.execute(args("X", mode="smoke", output_root=self.w.tmp / "runs"),
                       backend=be.MockBackend({}), files=self.w.files, order_path=self.w.order)
        real = json.loads((pc.ROOT / "configs" / "pilot_model.example.json").read_text(encoding="utf-8"))
        real.update({"backend": "openai_compatible", "model": "placeholder-not-called", "base_url": "http://127.0.0.1:9"})
        p = self.w.tmp / "real.json"
        p.write_text(json.dumps(real), encoding="utf-8")
        with self.assertRaises(SystemExit):     # a real backend may not write into a test_runs tree
            rp.execute(args("Y", mode="smoke", output_root=self.w.root, config=p),
                       backend=be.MockBackend({}), files=self.w.files, order_path=self.w.order)
        real["model"] = ""
        p.write_text(json.dumps(real), encoding="utf-8")
        with self.assertRaises(SystemExit):     # empty model name is refused for real backends
            rp.load_model_config(p)


# ------------------------------------------------------------------ revision provenance (fake Hub, no network)
class TestRevisionProvenance(unittest.TestCase):
    PIN = "3101254bbe4169895668a0e7653c3fd1f313576e"

    class FakeApi:
        def __init__(self, sha):
            self.sha, self.calls = sha, []

        def model_info(self, repo_id, revision=None):
            self.calls.append((repo_id, revision))
            return argparse.Namespace(sha=self.sha)

    def test_hub_sha_must_equal_pinned(self):
        api = self.FakeApi(self.PIN)
        self.assertEqual(be.verify_pinned_revision("Qwen/Qwen3-4B", self.PIN, api=api), self.PIN)
        self.assertEqual(api.calls, [("Qwen/Qwen3-4B", self.PIN)])
        with self.assertRaises(be.BackendConfigError):
            be.verify_pinned_revision("Qwen/Qwen3-4B", self.PIN, api=self.FakeApi("0" * 40))

    def test_snapshot_dir_must_be_the_pinned_commit(self):
        good = f"/cache/hub/models--Qwen--Qwen3-4B/snapshots/{self.PIN}"
        self.assertEqual(be.pinned_snapshot("Qwen/Qwen3-4B", self.PIN, downloader=lambda **k: good).name, self.PIN)
        for bad in ["/cache/hub/models--Qwen--Qwen3-4B/snapshots/" + "1" * 40, "/somewhere/else/" + self.PIN]:
            with self.subTest(bad=bad), self.assertRaises(be.BackendConfigError):
                be.pinned_snapshot("Qwen/Qwen3-4B", self.PIN, downloader=lambda **k: bad)


# ------------------------------------------------------------------ HTTP adapters vs a local fake server
class FakeServer(http.server.BaseHTTPRequestHandler):
    script = []          # list of (status, body) served in order
    received = []

    def do_POST(self):
        n = int(self.headers["Content-Length"])
        FakeServer.received.append((self.path, json.loads(self.rfile.read(n))))
        status, body = FakeServer.script.pop(0)
        data = json.dumps(body).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *a):
        pass


class TestHTTPAdapters(unittest.TestCase):
    """Fake local server only: verifies request shape and error classification, no model involved."""

    @classmethod
    def setUpClass(cls):
        cls.httpd = http.server.HTTPServer(("127.0.0.1", 0), FakeServer)
        cls.url = f"http://127.0.0.1:{cls.httpd.server_address[1]}"
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()

    def cfg(self, backend):
        return {"backend": backend, "model": "fake-model", "model_revision": "", "temperature": 0,
                "max_new_tokens": 512, "seed": 2026, "quantization": "", "device": "", "notes": "",
                "base_url": self.url, "timeout_seconds": 5}

    def test_openai_compatible(self):
        FakeServer.received.clear()
        FakeServer.script[:] = [(500, {"error": "boom"}), (429, {"error": "slow down"}), (400, {"error": "bad"}),
                                (200, {"model": "fake-model", "choices": [{"message": {"content": "FINAL_ANSWER: 7"},
                                                                           "finish_reason": "stop"}]}),
                                (200, {"choices": [{"message": {"content": None}, "finish_reason": "content_filter"}]})]
        b = be.make_backend(self.cfg("openai_compatible"))
        with self.assertRaises(be.TransportError):
            b.generate("P")
        with self.assertRaises(be.TransportError):
            b.generate("P")
        with self.assertRaises(be.BackendConfigError):
            b.generate("P")
        r = b.generate("P")
        self.assertEqual(r.text, "FINAL_ANSWER: 7")
        empty = b.generate("P")
        self.assertEqual((empty.text, empty.metadata["finish_reason"]), ("", "content_filter"))
        path, body = FakeServer.received[0]
        self.assertEqual(path, "/chat/completions")
        self.assertEqual(body["messages"], [{"role": "user", "content": "P"}])
        self.assertEqual((body["temperature"], body["max_tokens"], body["seed"], body["stream"]), (0, 512, 2026, False))
        self.assertNotIn("top_p", body)

    def test_ollama(self):
        FakeServer.received.clear()
        FakeServer.script[:] = [(503, {"error": "loading"}),
                                (200, {"model": "fake-model", "message": {"content": "FINAL_ANSWER: 9"},
                                       "done_reason": "stop"})]
        b = be.make_backend(self.cfg("ollama"))
        with self.assertRaises(be.TransportError):
            b.generate("Q")
        self.assertEqual(b.generate("Q").text, "FINAL_ANSWER: 9")
        path, body = FakeServer.received[0]
        self.assertEqual(path, "/api/chat")
        self.assertEqual(body["options"], {"temperature": 0, "num_predict": 512, "seed": 2026})
        self.assertEqual(body["messages"], [{"role": "user", "content": "Q"}])

    def test_connection_refused_is_transport(self):
        cfg = self.cfg("openai_compatible")
        cfg["base_url"] = "http://127.0.0.1:9"
        with self.assertRaises(be.TransportError):
            be.make_backend(cfg).generate("P")


if __name__ == "__main__":
    unittest.main(verbosity=2)
