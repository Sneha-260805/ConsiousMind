# Stage A: reliability-gated diagnostic feedback (simulated critics)

This stage is a controlled feasibility test. The solver is Qwen/Qwen3-4B with the frozen pilot protocol, and the
critics are simulated with known reliability (0.60 / 0.70 / 0.80 / 0.90).

- **Plan and interpretation rules:** [STAGE_A_PLAN.md](STAGE_A_PLAN.md)
- **GPU instructions:** [RUNBOOK.md](RUNBOOK.md)

**Status:** infrastructure built and validated locally. **NO REAL MODEL RESULTS YET.**

## Quickstart (laptop: no model, standard library only)

```bash
cd experiments/stage_a_reliability_gating
python scripts/01_build_dataset.py           # fresh M3 items (no pilot overlap) + tune/eval split (frozen)
python scripts/02_generate_simulated_critics.py
python scripts/03_build_requests.py          # request grid + execution order + prompt audits (frozen)
python tests/run_all.py                      # 46 tests
python scripts/04_smoke_test.py --solver mock                         # TEST ONLY pipeline check
python scripts/05_run_inference.py --solver mock --run-id mock_full   # TEST ONLY full mock pass
python scripts/06_analyze_results.py --phase tune --run-dir outputs/test_runs/mock_full
python scripts/06_analyze_results.py --phase eval --run-dir outputs/test_runs/mock_full
python scripts/07_package_results.py --run-dir outputs/test_runs/mock_full --analysis-dir outputs/analysis/mock_full
python scripts/08_build_kaggle_bundle.py     # Kaggle dataset zip + notebook
```

- Scripts 01–03 are already run; their outputs are frozen. Re-running them checks that the rebuild is byte-identical
  and stops if it is not.
- Mock runs can only write to `outputs/test_runs/`, and every mock CSV row is labelled
  `NO REAL MODEL RESULTS YET - TEST ONLY MOCK SOLVER`.
- On Kaggle the solver is `--solver qwen` (see RUNBOOK.md).

## Current frozen state

| | |
|---|---|
| fresh items | **28** (target ~80; short because validation was not relaxed; see the dataset manifest) |
| split | 14 `stage_a_tune` / 14 `stage_a_eval` (by problem, stratified by true error step) |
| overlap with the 40-item pilot | 0 by problem identity, 0 by question text |
| physical requests | 168 (28 items × L0, V, LOC@true, LOC@false, ATTN@true, ATTN@false) |
| logical grid | 560 cells (28 items × 4 regimes × 5 core policies) |
| hashes | `data/manifests/FROZEN_HASHES.json` |

## Layout

```
configs/stage_a.json         all settings and seeds (JSON: PyYAML is not installed; the pilot uses JSON too)
src/                         dataset_builder, m3_adapter, review_verdicts (Stage-A reviewer verdicts),
                             simulated_critic, feedback_policies, prompt_builder, request_builder, parser, scorer,
                             persistence, runner, solver_loader, mock_solver, analysis, figures, critic_interface
                             (Stage-B placeholder), frozen_pilot (hash-verified read-only access to the pilot)
scripts/01..08               pipeline steps (see the docstring at the top of each)
data/generated/              frozen items, split, critics, requests, logical grid, execution order, review file
data/manifests/              dataset / critic / request manifests, FROZEN_HASHES.json
tests/                       local validation suite (unittest)
outputs/                     test_runs/ (mock only), runs/ (real only), analysis/, dataset_build/
kaggle/                      bundle + notebook (built by script 08)
```

## Reused from the pilot (read-only, SHA-256 verified)

Nothing in `information_placebo_pilot/` is modified, and bytecode writing is disabled when importing from it.

- **M3 corruption, realism, wording and validation:** `build_m1_candidates`, `build_m3_candidates`,
  `build_m3_pilot40`, including their recorded reviewer verdicts.
- **False-step validity and histogram matching, prompt template:** `build_conditions`.
- **Answer parser v2.0:** `parse_answers`.
- **Model backend and Hub-revision check:** `backends`.
- **Kaggle GPU and package checks:** `kaggle_runner`.
- **Solver config:** the frozen `configs/qwen3_4b_kaggle.json`.

## Decisions taken (2026-10-11)

- The primary policy uses **one global threshold pair**; per-regime pairs are a sensitivity analysis only.
- There are **no exact correctness quotas**. Instead, the primary analysis averages over 2,000 independent critic
  realizations per regime, with tune-only seeds for threshold selection and separate eval seeds for evaluation. It
  needs no extra model calls. The single frozen realization is a secondary analysis with McNemar.
- The GSM8K test split is not used. One retained corruption per problem. No GPU inference.

## Human review (pending)

Claude's verdicts are not human validation. The review folder `review/` contains:

- `manual_review_blinded.md` and `manual_review_form.csv`: the 69 M3 candidates judged only by Claude in Stage A.
  They are blinded (no verdicts, random order).
- `UNBLINDING_KEY_do_not_open_before_review.json`: open only after the review is complete.
- `candidate_expansion_report.md`: the pool accounting, a breakdown of the 90 problems where every slip was rejected,
  the full option inventory by error step, a later-step-first dry run, and an unapproved delta "what-if".

The scripts are `python scripts/09_export_manual_review.py` and `python scripts/10_candidate_expansion_report.py`.

## Open decisions for the researcher

1. **Pool size (28 items).** Under the existing generator and rules, no further train problem is available unless a
   human overturns a Claude rejection, or the slip-delta set is extended (see the expansion report).
2. **Later-step errors.** None of the 28 retained problems has an automatically valid later-step alternative. Later
   steps exist only behind Claude site or gold-text rejections, or behind a generator extension.
