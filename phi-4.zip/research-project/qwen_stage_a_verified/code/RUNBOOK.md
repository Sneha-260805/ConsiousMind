# Stage A runbook: running on Kaggle (GPU T4)

Nothing in this folder downloads or runs Qwen on the laptop. The real solver refuses to start unless CUDA is present
and the code is running on Kaggle (or `STAGE_A_ALLOW_MODEL_LOAD=1` is set on another GPU machine).

## 0. Local preparation (laptop)

```bash
cd experiments/stage_a_reliability_gating
python tests/run_all.py                    # must end with ALL TESTS PASSED (writes tests/LAST_PASS.json)
python scripts/04_smoke_test.py --solver mock   # mock pipeline check (TEST ONLY)
python scripts/08_build_kaggle_bundle.py   # refuses unless the tests passed on the current code
```

This writes:

- `kaggle/stage_a_bundle.zip`: the dataset to upload;
- `kaggle/stage_a_run.ipynb`: the notebook;
- `kaggle/BUNDLE_INFO.json`: the SHA-256 of both.

## 1. Upload to Kaggle

1. **Datasets → New Dataset**: upload `kaggle/stage_a_bundle.zip` and name it `stage-a-reliability-gating-bundle`.
   Kaggle unzips it.
2. **Code → New Notebook → File → Import Notebook**: choose `kaggle/stage_a_run.ipynb`.
3. Notebook **Settings**:
   - **Accelerator:** GPU T4 x2. The protocol uses one T4 (cuda:0), as in the pilot.
   - **Internet:** On. Needed for the pinned `transformers`/`accelerate` and the Hub revision check; this requires a
     phone-verified account.
   - **Add Input:** the `stage-a-reliability-gating-bundle` dataset (exactly one copy).

You don't move any files by hand. Cell 2 copies the bundle to `/kaggle/working/stage_a_bundle` and verifies the
SHA-256 of every file. Cell 4 re-runs the local test suite on the GPU machine before any request is sent.

## 2. Smoke test (5 requests)

Set `MODE = "smoke"` in Cell 1, then either **Run All** in the interactive session (short) or **Save Version →
Save & Run All**. The smoke test:

- loads the model (Hub revision verified before loading, FP16, cuda:0, non-thinking chat template checked);
- runs a 2+2 canary;
- sends 5 frozen prompts, one per prompt kind first;
- re-generates the first prompt once as a determinism probe (diagnostics only).

Inspect it in a new cell or in the version's Output:

```python
import json, pathlib
d = pathlib.Path('/kaggle/working/stage_a_runs/smoke_qwen')
print(json.load(open(d / 'smoke_gate.json')))              # GO / NO-GO + each gate
print(json.load(open(d / 'run_diagnostics.json')))         # parse status, truncations, think tags
for l in open(d / 'raw_outputs.jsonl'):
    r = json.loads(l); print(r['request_key'], r['model_metadata']['response'].get('new_tokens'),
                              r['model_metadata']['response'].get('finish_reason')); print(r['raw_response'][-300:])
```

**Truncation check.** `run_diagnostics.json → truncated_at_max_new_tokens` must be empty, meaning no response hit
768 tokens (`finish_reason == "length"`). A truncated response is recorded as an observed outcome. Never regenerate
it and never change `max_new_tokens`.

**GO criteria** (same as the pilot):

- 5/5 completed;
- 0 transport failures;
- 5/5 numerically parsed;
- 0 truncations;
- no visible `<think>`;
- prompts byte-identical to the frozen grid;
- the determinism probe gives identical text.

GO is a recommendation. **The full run still needs the researcher's explicit approval.**

## 3. Full Stage-A run

Set `MODE = "full"` in Cell 1, then **File → Save Version → Save & Run All (Commit)**.

- Do **not** rely on an open browser tab or an interactive session. The committed version runs in the background,
  and its `/kaggle/working` becomes the version's **Output**, which persists after the session ends. The pilot's
  first 225-request run was lost because it lived only in an interactive runtime.
- Expected size: 168 requests at about 33 s each (pilot mean), roughly 1.5–2 h including model load. The Kaggle
  session limit is 12 h.
- Run command used by the notebook:
  ```bash
  python scripts/05_run_inference.py --solver qwen --run-id stage_a_qwen3_4b --output-root /kaggle/working/stage_a_runs
  ```

**Checkpoints** go to `/kaggle/working/stage_a_runs/stage_a_qwen3_4b/checkpoints/`:

- `checkpoint_0010.zip`, `checkpoint_0020.zip`, …, then `checkpoint_FINAL.zip`;
- each holds exactly the first N completed rows plus the run manifest;
- `raw_outputs.jsonl` itself is appended, flushed and fsync'ed after **every** request.

## 4. Resume

- **Same session:** rerun the same command (or Cell 5). Completed request keys are skipped and never regenerated.
- **After a failed or stopped committed version:** its Output still contains `stage_a_runs/stage_a_qwen3_4b/`.
  1. Open the notebook → **Add Input → Notebook Output** → select that version.
  2. In Cell 1, set `RESUME_FROM` to its run directory, or to its latest checkpoint ZIP, for example
     `/kaggle/input/<notebook>/stage_a_runs/stage_a_qwen3_4b/checkpoints/checkpoint_0080.zip`.
  3. Run **Save Version → Save & Run All** again.

  The runner checks that the earlier run has the same identity (model revision, request grid, order, config hashes)
  and that every row matches its frozen prompt. It then imports those rows and only generates the rest.
- Only transport errors are retried, at most 3 attempts. Model outputs are never retried, whether wrong, empty,
  malformed, refused or truncated.
- A crash writes `runtime_failure_<time>.json` and keeps all files.

## 5. Confirm the completed request count

```python
import json; d = '/kaggle/working/stage_a_runs/stage_a_qwen3_4b'
print(json.load(open(f'{d}/state.json')))                       # completed / planned
print(sum(1 for _ in open(f'{d}/raw_outputs.jsonl')))           # must be 168
print(json.load(open(f'{d}/run_diagnostics.json'))['duplicate_keys'])   # must be 0
```

## 6. Analysis and packaging

These run automatically in Cells 6–7 when `MODE = "full"`:

```bash
python scripts/06_analyze_results.py --phase tune --run-dir <run> --out-dir <analysis>   # freezes thresholds (tune only)
python scripts/06_analyze_results.py --phase eval --run-dir <run> --out-dir <analysis>   # eval only, frozen thresholds
python scripts/07_package_results.py --run-dir <run> --analysis-dir <analysis>
```

Final archive:

- `/kaggle/working/stage_a_runs/stage_a_qwen3_4b_FINAL.zip`
- `stage_a_qwen3_4b_FINAL.zip.sha256.txt`, with the SHA-256 printed at the end of Cell 7.

The archive holds:

- raw outputs, scored outputs and run log;
- the run manifest (exact model revision and input hashes), state and transport failures;
- the frozen items, split, critics, physical requests (every prompt and its SHA-256), logical grid and execution
  order;
- the configs, including the frozen solver config;
- the code;
- the environment manifest;
- the frozen thresholds and all analysis CSVs and figures;
- `ARCHIVE_INDEX.json`, with the SHA-256 of every member.

## 7. Download and verify

- Kaggle → the notebook → the version → **Output** → download `stage_a_qwen3_4b_FINAL.zip` and its `.sha256.txt`.
- Or use the CLI: `kaggle kernels output <user>/<notebook-slug> -p ./stage_a_download`.

Verify on the laptop:

```bash
python scripts/07_package_results.py --verify stage_a_download/stage_a_runs/stage_a_qwen3_4b_FINAL.zip
certutil -hashfile stage_a_download\stage_a_runs\stage_a_qwen3_4b_FINAL.zip SHA256    # Windows
sha256sum stage_a_download/stage_a_runs/stage_a_qwen3_4b_FINAL.zip                      # Linux/macOS
```

The printed SHA-256 must equal the one in `.sha256.txt` and the one printed by Cell 7. Keep the archive unmodified;
analyse a copy.
