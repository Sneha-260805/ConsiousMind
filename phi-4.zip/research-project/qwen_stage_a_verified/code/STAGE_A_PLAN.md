# Stage A plan: controlled feasibility test of reliability-gated diagnostic feedback

## The question Stage A answers

Under controlled critic reliability, is there an operating regime where **reliability-gated feedback** gives a better
repair-versus-misdirection trade-off than either of two simpler policies?

- **Verification only (V):** tell the solver that the final answer is wrong.
- **Always forwarding the critic's predicted location (ALWAYS_LOCATION).**

Stage A is not meant to prove that the method works. It checks whether the idea is worth a real critic (Stage B).

## Why simulated critics come first

A real critic has some accuracy and some confidence quality, and neither is known in advance. Suppose gated feedback
failed with a real critic. We could not tell whether:

- **(A)** the gating idea is wrong, or
- **(B)** the critic was simply bad: inaccurate, or confident in the wrong places.

Stage A removes (B). A simulated critic has a known target reliability r (0.60, 0.70, 0.80, 0.90). For each item:

- it draws a confidence p_i ~ Beta(r·10, (1−r)·10);
- it is right with probability p_i, so p is calibrated by construction;
- when right, it points at the true first error; when wrong, it points at the item's pre-validated false step.

If gating does not help even with a calibrated, known-reliability critic, a real critic will not rescue it. If it
does help, Stage B asks whether a real critic's confidence is good enough.

The critic realisation is generated once, frozen (`data/generated/simulated_critics.json`) and shared by every
policy, so policies never see different predictions.

The **constant-confidence control** reuses exactly the same predictions but removes the information in p:

- **permuted:** the p values are shuffled across items;
- **constant:** p = r for every item.

If gating only beats the alternatives when p is informative, the control should lose that advantage. The control
needs no extra model calls.

## Why the items must not overlap the pilot

The 40-item pilot (Qwen3-4B, same M3 slips) already shaped our expectations: verification helps a lot, a correct
location adds little, a wrong location hurts. Re-using those problems would test the new policy on items whose
behaviour we have already seen. Stage A items are therefore chosen by **original GSM8K problem identity** (split +
index, and also normalised question text), and the overlap audit is part of the dataset manifest. Pilot findings are
not built into anything here; they only motivated the question.

## Why tune and eval are separate

The gate has two thresholds (tau_low, tau_high). Picking them on the same items we report on would overstate the
benefit. Items are split by problem into `stage_a_tune` and `stage_a_eval`.

- Thresholds are chosen on tune only, with a rule fixed in `configs/stage_a.json` before any model output exists.
- They are then frozen and hashed (`thresholds_frozen.json`).
- The eval phase refuses to run without them.
- The tune-phase code drops every eval row before it computes anything.

`stage_a_eval` is a held-out **feasibility** set. It is not the final paper test set.

## What each policy means

| Policy | Feedback the solver sees | Role |
|---|---|---|
| L0 | none | no-feedback baseline (no hint that anything is wrong) |
| V | "The final answer in the proposed solution is wrong." | verification-only baseline |
| ALWAYS_LOCATION | V + "The first mistake is in Step k." (k = critic's prediction) | always trust the critic |
| RELIABILITY_GATED | p ≥ tau_high: V + location · tau_low ≤ p < tau_high: V + "Pay special attention to Step k." · p < tau_low: V only | the proposed method |
| ORACLE_LOCATION | V + true first-error step | non-deployable upper reference for localisation |
| GENERIC_REFLECTION (optional) | "Review the proposed solution carefully before giving your final answer." | reflection placebo |
| ANSWER_GIVEN_REFERENCE (optional) | "The correct final answer is X." | answer-given reference (not a location oracle) |

The wording of V, LOCATE and ANSWER is byte-identical to the pilot, and every prompt is checked against the pilot
template.

## How requests are organised

Because a wrong critic always points at the item's one pre-validated false step, every policy, regime and threshold
pair needs one of only six prompts per item:

- L0
- V
- LOC@true
- LOC@false
- ATTN@true
- ATTN@false

With greedy decoding a prompt gets the same answer whichever policy sends it, so each of these is sent to the model
exactly once (28 items × 6 = 168 requests).

The **logical grid** keeps the requested bookkeeping: item × regime × critic version × policy × threshold version ×
solver. It records which physical request supplies each cell. The smoke test includes a determinism probe that
re-generates one prompt.

## Metrics (scoring contract fixed in `src/scorer.py`)

Each response gets exactly one of four outcomes:

- **repair:** the parsed answer equals the gold answer (primary metric);
- **corrupted-answer retention:** it equals the trace's corrupted final answer;
- **misdirected repair:** the answer changed, but to a value that is neither gold nor the corrupted answer;
- **parse failure.**

Truncation and strict-format compliance are reported as diagnostics. The parser is the frozen pilot parser:

- it reads the last `FINAL_ANSWER:` field;
- it falls back to the final line only if no such field exists;
- it never searches the reasoning body.

## Averaging over many simulated critics (primary analysis)

With only 14 items per split, a single critic draw is noisy: one frozen "0.90" critic was right on 14/14 tune items
but only 9/14 eval items. We do not force exact quotas of correct predictions. Instead, the primary analysis averages
every policy over **many independent critic realizations per regime**:

- 2,000 for tune and 2,000 for eval (`configs/stage_a.json → multi_realization`).
- Each realization uses the same Beta/Bernoulli model as above.
- **Threshold selection uses only tune-namespace seeds on `stage_a_tune`.**
- **Held-out evaluation uses only eval-namespace seeds on `stage_a_eval`.**
- The two seed sets are disjoint by construction (tested).

A realization only decides which of an item's 6 existing prompts each policy would send, so **no additional model
calls are needed**. The tests check that every policy × realization × threshold pair resolves to a frozen prompt.

Reported rates are means over all (realization, item) cells. Two kinds of uncertainty are reported separately:

- **Item sampling:** a paired bootstrap over items, using each item's realization-averaged outcome.
- **Critic-draw variability:** the 2.5–97.5% range across realizations, plus the share of realizations in which A
  beats B.

The single frozen realization is kept as a **secondary** analysis (`*_frozen_realization.csv`). Its outcomes are
binary, so it carries the four paired cells and the exact McNemar test.

The primary gated policy uses **one global threshold pair**, chosen on realization-averaged, regime-averaged tune
metrics. Per-regime pairs are reported only as a sensitivity analysis.

## Statistics

Comparisons are paired: the same items (and, in the primary analysis, the same critic realization) get every policy.
For each comparison we report:

- the difference with a 95% paired-bootstrap CI over items (10,000 resamples, recorded seed);
- in the primary analysis, the realization range and the share of realizations favouring A;
- in the secondary frozen-realization analysis, the four cells (both / A only / B only / neither) and an exact
  McNemar p-value.

Each reliability regime is reported separately; regimes are never pooled into one headline.

Primary comparisons on eval:

1. GATED vs V (repair): does selective specificity add anything beyond "the answer is wrong"?
2. GATED vs ALWAYS_LOCATION (repair and misdirection): does gating limit the damage of unreliable locations?

Also reported:

- ORACLE vs GATED (distance from perfect localisation);
- V vs L0 (verification effect);
- GATED vs the permuted-confidence control.

## What counts as promising, and what a negative result means

Labels per regime, declared before any data (δ = 0.05, `configs/stage_a.json`):

- **STRONG FEASIBILITY SIGNAL** requires all three:
  - gated repair ≥ V repair + δ on eval;
  - gated misdirection < ALWAYS_LOCATION misdirection on eval;
  - the repair gain over V (≥ δ) also present on tune.
- **PROMISING / MIXED:** gated repair within δ of V (or better), and misdirection at least δ lower than
  ALWAYS_LOCATION.
- **NO SUPPORT:** anything else, for example gated repair below V, or no safety advantage over ALWAYS_LOCATION.
- If no threshold pair satisfies the tune constraints, the report says **NO FEASIBLE GATING OPERATING POINT FOUND ON
  TUNE SET**. No winner is forced.

A negative result is a legitimate finding: under these conditions, varying feedback specificity by critic confidence
does not beat simply saying "the answer is wrong", or does not reduce harm relative to always forwarding the
location. Thresholds are never re-tuned after eval results have been seen.

## Why this is feasibility evidence, not proof

Stage A is limited in several ways:

- one solver;
- one error type (M3 arithmetic slips);
- simulated critics;
- a small item set.

### Current dataset size

The fresh pool has **28** valid items, against a target of about 80, giving 14 tune and 14 eval items. Under the
pilot's frozen M3 and realism rules, which are deliberately not relaxed, GSM8K train has only about 68 clean problems
in total, and the pilot already used 40. At n = 14, one item is about 7 percentage points, and the realised accuracy
of a "0.90" critic on 14 items can be far from 0.90. Results should be read as effect sizes with wide intervals.
Decisions about enlarging the pool (GSM8K test split, several slips per problem) are open; see the README.

Also, 23 of the 28 items have their error at Step 2, so their only valid false step is Step 1.

Even a strong signal would only justify Stage B (a real critic and confidence calibration) and a pre-registered
confirmatory study. It would not justify any claim of superiority or novelty.
