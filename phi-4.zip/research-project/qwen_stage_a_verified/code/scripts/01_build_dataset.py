"""Build the fresh Stage-A GSM8K M3 items (no overlap with the 40-item pilot) and the tune/eval split.

    python scripts/01_build_dataset.py            # exits 2 and lists items if reviewer verdicts are pending
    python scripts/01_build_dataset.py --rebuild  # only if a deliberate change to the frozen items is intended
No model is called. Output: data/generated/stage_a_items.json, stage_a_split.json, stage_a_items_review.txt,
data/manifests/dataset_manifest.json.
"""
import argparse
import json
import sys

import _bootstrap  # noqa: F401
from src import common as C
from src.dataset_builder import build

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--rebuild", action="store_true", help="allow replacing frozen files whose rebuild differs")
    a = ap.parse_args()
    res = build(C.load_config(), rebuild=a.rebuild)
    print(json.dumps(res, indent=2, default=str))
    sys.exit(2 if res["status"] == "PENDING_REVIEW" else 0)
