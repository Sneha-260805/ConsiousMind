"""Generate and freeze the simulated critics (target reliability 0.60 / 0.70 / 0.80 / 0.90).

    python scripts/02_generate_simulated_critics.py
Reads the frozen items + split; writes data/generated/simulated_critics.json and data/manifests/critic_manifest.json.
The realisation is generated once; every feedback policy later reads this same file.
"""
import argparse
import json
import sys

import _bootstrap  # noqa: F401
from src import common as C
from src.simulated_critic import simulate

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--rebuild", action="store_true")
    a = ap.parse_args()
    cfg = C.load_config()
    items_doc, split = C.read_json(C.ITEMS_FILE), C.read_json(C.SPLIT_FILE)
    if split["items_file_sha256"] != C.sha256_file(C.ITEMS_FILE):
        raise SystemExit("STOP: split file does not belong to the current items file")
    doc = simulate(items_doc["items"], split["assignment"], cfg)
    doc["items_file_sha256"] = C.sha256_file(C.ITEMS_FILE)
    doc["split_file_sha256"] = C.sha256_file(C.SPLIT_FILE)
    sha, status = C.write_frozen(C.CRITICS_FILE, C.write_json, doc, a.rebuild)
    man = {"generated": C.now(), "critics_file": C.rel(C.CRITICS_FILE), "sha256": sha, "status": status,
           "critic_version": doc["critic_version"], "summary": doc["summary"],
           "generated_with_python": "%d.%d.%d" % sys.version_info[:3],
           "items_file_sha256": doc["items_file_sha256"], "split_file_sha256": doc["split_file_sha256"]}
    C.write_json(C.CRITIC_MANIFEST, man)
    print(json.dumps(man, indent=2))
