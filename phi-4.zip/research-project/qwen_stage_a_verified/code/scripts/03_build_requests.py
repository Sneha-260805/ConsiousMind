"""Build the full request grid (physical requests + logical grid), the seeded execution order and the prompt audit
BEFORE any inference. Every prompt is checked byte-for-byte against the frozen pilot template.

    python scripts/03_build_requests.py
Exit code 2 if any audit fails (nothing is frozen in that case).
"""
import argparse
import json
import sys

import _bootstrap  # noqa: F401
from src import common as C
from src import frozen_pilot as fp
from src import request_builder as rb

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--rebuild", action="store_true")
    a = ap.parse_args()
    cfg = C.load_config()
    items = C.read_json(C.ITEMS_FILE)["items"]
    critics = C.read_json(C.CRITICS_FILE)
    if critics["items_file_sha256"] != C.sha256_file(C.ITEMS_FILE):
        raise SystemExit("STOP: critics file does not belong to the current items file")
    bc = fp.module("build_conditions", cfg)
    physical = rb.build_physical(items, cfg)
    logical = rb.build_logical(items, critics, cfg)
    audit = rb.audit_prompts(physical, {it["item_id"]: it for it in items}, bc.build_prompt,
                             {"VERIFY": bc.VERIFY, "LOCATE": bc.LOCATE, "ORACLE": bc.ORACLE,
                              "HEADER": bc.HEADER, "INSTRUCTION": bc.INSTRUCTION})
    summary = rb.summarize(physical, logical)
    if not audit["ALL_PASS"] or not summary["every_logical_cell_resolves_to_a_physical_request"]:
        print(json.dumps({"audit": audit, "summary": summary}, indent=2, default=str))
        sys.exit(2)
    order = rb.execution_order(physical, cfg["requests"]["execution_order_seed"])
    shas = {}
    shas[C.rel(C.REQUESTS_FILE)] = C.write_frozen(C.REQUESTS_FILE, C.write_jsonl, physical, a.rebuild)
    shas[C.rel(C.GRID_FILE)] = C.write_frozen(C.GRID_FILE, C.write_jsonl, logical, a.rebuild)
    shas[C.rel(C.ORDER_FILE)] = C.write_frozen(C.ORDER_FILE, C.write_json, order, a.rebuild)
    man = {"generated": C.now(), "request_version": rb.REQUEST_VERSION, "solver_tag": cfg["requests"]["solver_tag"],
           "solver": cfg["solver"], **summary,
           "execution_order": {k: v for k, v in order.items() if k != "order"},
           "prompt_audit": {k: v for k, v in audit.items()},
           "frozen_files": {k: {"sha256": s, "status": st} for k, (s, st) in shas.items()},
           "inputs_sha256": {C.rel(C.ITEMS_FILE): C.sha256_file(C.ITEMS_FILE),
                             C.rel(C.SPLIT_FILE): C.sha256_file(C.SPLIT_FILE),
                             C.rel(C.CRITICS_FILE): C.sha256_file(C.CRITICS_FILE),
                             C.rel(C.CONFIG_PATH): C.sha256_file(C.CONFIG_PATH)}}
    C.write_json(C.REQUEST_MANIFEST, man)
    frozen = {C.rel(p): C.sha256_file(p) for p in (C.ITEMS_FILE, C.SPLIT_FILE, C.CRITICS_FILE, C.REQUESTS_FILE,
                                                    C.GRID_FILE, C.ORDER_FILE, C.CONFIG_PATH)}
    C.write_json(C.FROZEN_HASHES, {"generated": C.now(), "files": frozen})
    print(json.dumps({k: man[k] for k in ("n_physical_requests", "physical_by_variant_family", "physical_by_split",
                                          "n_logical_cells", "logical_by_policy", "execution_order",
                                          "frozen_files")}, indent=2))
    print("prompt audit ALL_PASS:", audit["ALL_PASS"], "| violations:", len(audit["violations"]),
          "| natural question occurrences:", len(audit["natural_question_occurrences"]))
