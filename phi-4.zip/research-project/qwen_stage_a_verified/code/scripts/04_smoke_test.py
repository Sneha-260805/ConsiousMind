"""5-request smoke test (one request per prompt kind first: L0, V, LOC@true, LOC@false, ATTN@...).

    python scripts/04_smoke_test.py --solver mock                         # local, TEST ONLY, no model
    python scripts/04_smoke_test.py --solver qwen \
        --output-root /kaggle/working/stage_a_runs                        # Kaggle GPU: 5 real requests + canary
Writes a SEPARATE run directory (smoke_<solver>); smoke rows are never reused by the full run.
For the real solver it also runs the 2+2 canary and a determinism probe (the first smoke prompt generated a second
time; diagnostics only). It prints integrity information and a GO / NO-GO gate (pilot criteria): all requests
completed, 0 transport failures, every response numerically parsed, none hit max_new_tokens, no visible thinking,
prompts byte-identical to the frozen grid. GO is a recommendation; the full run still needs researcher approval.
"""
import argparse
import json
from pathlib import Path

import _bootstrap  # noqa: F401
from src import common as C
from src import runner as R
from src.scorer import score_run
from src.solver_loader import canary, make_solver

class _MustNotBeCalled:
    name = "resume-check"

    def generate(self, prompt):
        raise RuntimeError("RESUME CHECK FAILED: a completed request was about to be regenerated")


def verify_resume(run_dir, by_key, order, keys, cfg):
    """Persistence / resume check on a finished run, with no model: every planned key must be skipped."""
    import zipfile
    man = C.read_json(run_dir / "run_manifest.json")
    before = (run_dir / "raw_outputs.jsonl").read_bytes()
    stats = R.execute(run_dir, by_key, order, keys, _MustNotBeCalled(), man, cfg["runner"], log=lambda *_: None)
    after = (run_dir / "raw_outputs.jsonl").read_bytes()
    rows = [json.loads(l) for l in after.decode("utf-8").splitlines() if l.strip()]
    state = C.read_json(run_dir / "state.json")
    final = run_dir / "checkpoints" / "checkpoint_FINAL.zip"
    with zipfile.ZipFile(final) as z:
        ck_raw = z.read("raw_outputs.jsonl")
    res = {"checked": C.now(), "generated_on_resume": stats["generated"],
           "raw_file_unchanged_by_resume": before == after,
           "rows_on_disk": len(rows), "planned": len(keys),
           "unique_request_keys": len({r["request_key"] for r in rows}) == len(rows),
           "keys_equal_plan": sorted(r["request_key"] for r in rows) == sorted(keys),
           "every_row_fsynced_single_attempt": all(r["attempt_count"] >= 1 for r in rows),
           "state_json_completed": state["completed"],
           "final_checkpoint_equals_raw_file": ck_raw == after,
           "lock_released": not (run_dir / "run.lock").exists()}
    res["PASS"] = (res["generated_on_resume"] == 0 and res["raw_file_unchanged_by_resume"]
                   and res["rows_on_disk"] == res["planned"] == res["state_json_completed"]
                   and res["unique_request_keys"] and res["keys_equal_plan"]
                   and res["final_checkpoint_equals_raw_file"] and res["lock_released"])
    C.write_json(run_dir / "diagnostics" / "resume_check.json", res)
    print(json.dumps(res, indent=2))
    if not res["PASS"]:
        raise SystemExit("RESUME CHECK FAILED")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--solver", required=True, choices=["mock", "qwen"])
    ap.add_argument("--output-root", default=None)
    ap.add_argument("--run-id", default=None)
    ap.add_argument("--force-unlock", action="store_true")
    ap.add_argument("--verify-resume", action="store_true",
                    help="no model: re-enter the finished smoke run with a solver that fails if called")
    a = ap.parse_args()

    cfg = C.load_config()
    by_key, order, frozen = R.load_frozen_inputs()
    n = cfg["runner"]["smoke_requests"]
    keys = R.plan_keys(order, by_key, "smoke", n)
    root = Path(a.output_root) if a.output_root else (C.TEST_RUNS_ROOT if a.solver == "mock" else C.RUNS_ROOT)
    run_dir = root / (a.run_id or f"smoke_{a.solver}")
    if a.verify_resume:
        verify_resume(run_dir, by_key, order, keys, cfg)
        raise SystemExit(0)
    solver, backend_name, test_only, solver_cfg, solver_sha = make_solver(a.solver, cfg, list(by_key.values()))
    manifest = R.run_manifest(run_dir.name, "smoke", test_only, backend_name, cfg, solver_cfg, solver_sha, frozen, keys)
    diag_dir = run_dir / "diagnostics"
    if a.solver == "qwen":
        C.write_json(diag_dir / "model_load.json", {"recorded": C.now(), "effective_settings":
                                                     solver.effective_settings(), "versions": solver.versions(),
                                                     "provenance": solver.provenance,
                                                     "frozen_solver_config": solver_cfg,
                                                     "frozen_solver_config_sha256": solver_sha})
        can = canary(solver)
        C.write_json(diag_dir / "canary.json", can)
        print("canary:", can["checks"])
        if not can["passed"]:
            raise SystemExit("STOP: canary failed; no experimental prompt was sent")
    stats = R.execute(run_dir, by_key, order, keys, solver, manifest, cfg["runner"], force_unlock=a.force_unlock)
    diag, scored = score_run(run_dir)
    raw = {r["request_key"]: r for r in C.read_jsonl(run_dir / "raw_outputs.jsonl")}
    det = C.read_json(diag_dir / "determinism_probe.json") if (diag_dir / "determinism_probe.json").exists() else None
    if a.solver == "qwen" and keys and det is None:
        again = solver.generate(by_key[keys[0]]["prompt"])
        det = {"DIAGNOSTIC_ONLY": True, "request_key": keys[0],
               "identical_text": again.text == raw[keys[0]]["raw_response"],
               "first": raw[keys[0]]["raw_response"], "second": again.text}
        C.write_json(diag_dir / "determinism_probe.json", det)
    gate = {
        f"completed_{len(keys)}_of_{len(keys)}": diag["completed"] == len(keys),
        "transport_failures_0": diag["transport_failure_records"] == 0,
        "numeric_parse_all": diag["numeric_parse_status"].get("ok", 0) == len(keys),
        "hit_max_new_tokens_0": not diag["truncated_at_max_new_tokens"],
        "no_visible_thinking": not diag["visible_think_tags"],
        "prompts_byte_identical_to_frozen": all(raw[k]["prompt"] == by_key[k]["prompt"] for k in raw),
    }
    if a.solver == "qwen":
        gate["canary_passed"] = C.read_json(diag_dir / "canary.json")["passed"]
        gate["determinism_probe_identical"] = bool(det and det["identical_text"])
    decision = "GO (pending researcher approval; the full run is NOT launched)" if all(gate.values()) else "NO-GO"
    if test_only:
        decision = "TEST ONLY (mock solver): pipeline check passed" if gate[f"completed_{len(keys)}_of_{len(keys)}"] \
            and gate["prompts_byte_identical_to_frozen"] else "TEST ONLY: pipeline check FAILED"
    C.write_json(run_dir / "smoke_gate.json", {"gate": gate, "decision": decision, "TEST_ONLY": test_only})
    print(json.dumps({"run_dir": str(run_dir), "smoke_requests": keys, "stats": stats, "gate": gate,
                      "decision": decision}, indent=2))
    print("\nInspect the raw responses:", run_dir / "raw_outputs.jsonl")
    for k in keys:
        s = next(x for x in scored if x["request_key"] == k)
        print(f"  {k}: parse={s['numeric_parse_status']} answer={s['numeric_parsed_answer']} "
              f"truncated={s['truncated']} tokens={s['new_tokens']}")
