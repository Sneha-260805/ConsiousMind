"""Run the frozen Stage-A request grid through one solver. Crash-safe; rerunning the same command resumes.

    python scripts/05_run_inference.py --solver mock --run-id mock_full              # local, TEST ONLY
    python scripts/05_run_inference.py --solver qwen --run-id stage_a_qwen3_4b \
        --output-root /kaggle/working/stage_a_runs                                   # Kaggle GPU only
Options:
    --split stage_a_tune|stage_a_eval   run only one split (default: the whole grid)
    --resume-from PATH                  seed a fresh run dir with rows from an earlier session's run dir / ZIP
    --max-requests N                    stop after N planned requests (debugging only)
    --force-unlock                      remove a stale run.lock left by a killed process
After the pass the completed rows are parsed and scored (integrity diagnostics only; no policy comparison).
Mock runs can only write under outputs/test_runs/ and are labelled TEST ONLY.
"""
import argparse
import json
from pathlib import Path

import _bootstrap  # noqa: F401
from src import common as C
from src import runner as R
from src.scorer import score_run
from src.solver_loader import make_solver

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--solver", required=True, choices=["mock", "qwen"])
    ap.add_argument("--run-id", required=True)
    ap.add_argument("--output-root", default=None)
    ap.add_argument("--split", choices=["stage_a_tune", "stage_a_eval"], default=None)
    ap.add_argument("--resume-from", default=None)
    ap.add_argument("--max-requests", type=int, default=None)
    ap.add_argument("--force-unlock", action="store_true")
    a = ap.parse_args()

    cfg = C.load_config()
    by_key, order, frozen = R.load_frozen_inputs()
    keys = R.plan_keys(order, by_key, "full", None, a.split)
    mode = "full" if a.split is None else f"split:{a.split}"
    if a.solver == "mock":
        root = Path(a.output_root) if a.output_root else C.TEST_RUNS_ROOT
        if C.RUNS_ROOT in root.resolve().parents or root.resolve() == C.RUNS_ROOT.resolve():
            raise SystemExit("STOP: mock runs may not write under outputs/runs/ (real results only)")
    else:
        root = Path(a.output_root) if a.output_root else C.RUNS_ROOT
    run_dir = root / a.run_id
    solver, backend_name, test_only, solver_cfg, solver_sha = make_solver(a.solver, cfg, list(by_key.values()))
    manifest = R.run_manifest(a.run_id, mode, test_only, backend_name, cfg, solver_cfg, solver_sha, frozen, keys)
    if a.resume_from:
        n, note = R.import_previous(run_dir, a.resume_from, manifest, by_key)
        print(f"imported {n} completed rows from {a.resume_from} {note or ''}")
    stats = R.execute(run_dir, by_key, order, keys, solver, manifest, cfg["runner"], force_unlock=a.force_unlock,
                      limit=a.max_requests)
    diag, _ = score_run(run_dir)
    print(json.dumps({"run_dir": str(run_dir), "stats": stats,
                      "integrity": {k: diag[k] for k in ("TEST_ONLY", "planned", "completed", "duplicate_keys",
                                                         "transport_failure_records", "numeric_parse_status",
                                                         "truncated_at_max_new_tokens", "visible_think_tags")}},
                     indent=2))
