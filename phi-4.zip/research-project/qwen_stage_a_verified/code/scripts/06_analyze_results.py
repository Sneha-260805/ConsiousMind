"""Stage-A analysis, in two SEPARATE phases (tune first; eval only after thresholds are frozen).

    python scripts/06_analyze_results.py --phase tune --run-dir <run_dir>   # stage_a_tune only -> thresholds_frozen.json
    python scripts/06_analyze_results.py --phase eval --run-dir <run_dir>   # stage_a_eval only, frozen thresholds
    python scripts/06_analyze_results.py --phase eval                       # no run yet: 'NO REAL MODEL RESULTS YET'
Outputs: outputs/analysis/<run_id>/  (threshold_sweep.csv, threshold_pareto.csv, thresholds_frozen.json[.sha256],
stage_a_summary.csv, policy_metrics.csv, paired_comparisons.csv, critic_calibration.csv, routing_summary.csv,
stratified_metrics.csv, eval_report.json, figures/). Every CSV row carries a data_status column.
Never re-run the tune phase with different settings after looking at eval results.
"""
import argparse
import json
from pathlib import Path

import _bootstrap  # noqa: F401
from src import analysis as A
from src import common as C
from src import figures

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--phase", required=True, choices=["tune", "eval"])
    ap.add_argument("--run-dir", default=None)
    ap.add_argument("--out-dir", default=None)
    a = ap.parse_args()
    cfg = C.load_config()
    label = Path(a.run_dir).name if a.run_dir else "no_model_results"
    out = Path(a.out_dir) if a.out_dir else C.OUTPUTS / "analysis" / label
    ctx = A.Context(cfg, a.phase, a.run_dir)
    banner = f"DATA STATUS: {ctx.status}"
    print("=" * len(banner) + "\n" + banner + "\n" + "=" * len(banner))
    if not ctx.has_results:
        A.write_csv(out / "critic_calibration.csv", A.critic_calibration(ctx), ctx.status)
        A.write_csv(out / "stage_a_summary.csv", [{"regime": r, "outcome_label": A.STATUS_NONE} for r in ctx.regimes],
                    ctx.status)
        (out / "REPORT_STATUS.txt").write_text(A.STATUS_NONE + "\nOnly the simulated-critic calibration (which needs "
                                               "no model) is reported.\n", encoding="utf-8")
        print(A.STATUS_NONE, "-> wrote", out)
        raise SystemExit(0)
    if a.phase == "tune":
        body = A.run_tune(ctx, out)
        print(json.dumps({k: body[k] for k in ("global_status", "selected_global", "selected_per_regime_sensitivity",
                                               "threshold_version")}, indent=2, default=str))
        print("frozen thresholds:", out / "thresholds_frozen.json")
    else:
        report, pm, cmp_, routes = A.run_eval(ctx, out)
        try:                                     # figures never block the (already written) CSV results
            figs = figures.make_all(out, ctx.status, pm, cmp_, routes, A.critic_calibration(ctx), ctx.regimes)
        except Exception as e:
            figs = {"figures": [], "note": f"figure generation failed ({type(e).__name__}: {e}); CSVs are complete"}
        print(json.dumps({"global_status": report["global_status"], "selected": report["selected"],
                          "threshold_version": report["threshold_version"],
                          "summary": [{k: r[k] for k in ("regime", "n_items", "outcome_label")}
                                      for r in report["summary"]], "figures": figs}, indent=2, default=str))
    (out / "REPORT_STATUS.txt").write_text(ctx.status + "\n", encoding="utf-8")
