"""Package a Stage-A run into ONE verified archive and print its SHA-256.

    python scripts/07_package_results.py --run-dir <run_dir> [--analysis-dir <dir>] [--out <file.zip>]
    python scripts/07_package_results.py --verify <file.zip>
Archive contents: run/ (raw_outputs, scored_outputs, run_manifest = exact model revision + input hashes, state,
transport failures, run log, diagnostics, smoke gate, checkpoint log), frozen/ (items, split, critics, physical
requests with every prompt and prompt SHA-256, logical grid, execution order, manifests, FROZEN_HASHES), config/
(stage_a.json + the frozen solver config), code/ (src + scripts), analysis/ (if given: thresholds, CSVs, figures),
environment.json, ARCHIVE_INDEX.json (SHA-256 of every member). The archive is written atomically and verified.
"""
import argparse
import importlib.metadata as md
import json
import os
import platform
import sys
import zipfile
from pathlib import Path

import _bootstrap  # noqa: F401
from src import common as C
from src import frozen_pilot as fp
from src.persistence import atomic_zip


def environment():
    pk = {}
    for n in ("torch", "transformers", "accelerate", "safetensors", "tokenizers", "huggingface_hub", "matplotlib",
              "numpy"):
        try:
            pk[n] = md.version(n)
        except md.PackageNotFoundError:
            pk[n] = None
    return {"recorded": C.now(), "python": sys.version, "platform": platform.platform(), "packages": pk,
            "kaggle": {k: v for k, v in os.environ.items() if k.startswith("KAGGLE_") and "TOKEN" not in k
                       and "KEY" not in k and "SECRET" not in k}}


def collect(run_dir, analysis_dir):
    cfg = C.load_config()
    members = []

    def add_tree(base, prefix, skip=()):
        for p in sorted(Path(base).rglob("*")):
            if p.is_file() and not any(s in p.name for s in skip):
                members.append((f"{prefix}/{p.relative_to(base).as_posix()}", p.read_bytes()))
    add_tree(run_dir, "run", skip=(".zip", ".tmp", "run.lock"))
    ck = Path(run_dir) / "checkpoints" / "checkpoint_log.txt"
    if ck.exists() and not any(a == "run/checkpoints/checkpoint_log.txt" for a, _ in members):
        members.append(("run/checkpoints/checkpoint_log.txt", ck.read_bytes()))
    for p in sorted(C.DATA_GEN.glob("*")) + sorted(C.DATA_MAN.glob("*")):
        if p.is_file():
            members.append((f"frozen/{p.parent.name}/{p.name}", p.read_bytes()))
    members.append(("config/stage_a.json", C.CONFIG_PATH.read_bytes()))
    sp = fp.path(cfg["solver"]["frozen_config"], cfg)
    members.append(("config/solver_frozen_qwen3_4b_kaggle.json", sp.read_bytes()))
    for sub in ("src", "scripts", "tests"):
        add_tree(C.STAGE_ROOT / sub, f"code/{sub}", skip=(".pyc",))
    for doc in ("README.md", "STAGE_A_PLAN.md", "RUNBOOK.md"):
        if (C.STAGE_ROOT / doc).exists():
            members.append((f"code/{doc}", (C.STAGE_ROOT / doc).read_bytes()))
    if analysis_dir:
        add_tree(analysis_dir, "analysis")
    members.append(("environment.json", json.dumps(environment(), indent=2).encode()))
    return members


def verify(path):
    path = Path(path)
    checks = {"exists": path.exists()}
    if checks["exists"]:
        with zipfile.ZipFile(path) as z:
            checks["crc_ok"] = z.testzip() is None
            idx = json.loads(z.read("ARCHIVE_INDEX.json"))
            checks["member_hashes_match"] = all(C.sha256_bytes(z.read(a)) == h for a, h in idx["members_sha256"].items())
            raw = [json.loads(l) for l in z.read("run/raw_outputs.jsonl").decode("utf-8").splitlines() if l.strip()]
            keys = [r["request_key"] for r in raw]
            checks["raw_rows_unique"] = len(keys) == len(set(keys))
            man = json.loads(z.read("run/run_manifest.json"))
            checks["raw_rows_equal_planned"] = len(keys) == man["n_planned"]
            checks["model_revision_recorded"] = bool(man.get("model_revision"))
            checks["frozen_hashes_present"] = "frozen/manifests/FROZEN_HASHES.json" in z.namelist()
            label = "TEST ONLY" if man["test_only"] else "REAL MODEL RUN"
    else:
        label = None
    sha = C.sha256_file(path) if checks["exists"] else None
    return {"archive": str(path), "sha256": sha, "bytes": path.stat().st_size if checks["exists"] else 0,
            "label": label, "checks": checks, "verified": all(checks.values())}


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--run-dir")
    ap.add_argument("--analysis-dir", default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--verify", default=None)
    a = ap.parse_args()
    if a.verify:
        res = verify(a.verify)
        print(json.dumps(res, indent=2))
        sys.exit(0 if res["verified"] else 1)
    if not a.run_dir:
        ap.error("--run-dir is required (or --verify)")
    run_dir = Path(a.run_dir)
    man = C.read_json(run_dir / "run_manifest.json")
    tag = "TEST_ONLY_" if man["test_only"] else ""
    out = Path(a.out) if a.out else run_dir.parent / f"{tag}{man['run_id']}_FINAL.zip"
    members = collect(run_dir, a.analysis_dir)
    index = {"created": C.now(), "run_id": man["run_id"], "test_only": man["test_only"],
             "model": man["model"], "model_revision": man["model_revision"], "n_members": len(members),
             "dataset_validation_status": C.DATASET_VALIDATION_STATUS,
             "members_sha256": {arc: C.sha256_bytes(b) for arc, b in members}}
    members.append(("ARCHIVE_INDEX.json", json.dumps(index, indent=2).encode()))
    atomic_zip(out, members)
    res = verify(out)
    Path(str(out) + ".sha256.txt").write_text(f"{res['sha256']}  {out.name}\n{res['bytes']} bytes\n", encoding="utf-8")
    print(json.dumps(res, indent=2))
    print("\nFINAL ARCHIVE:", out, "\nSHA-256:", res["sha256"])
    sys.exit(0 if res["verified"] else 1)
