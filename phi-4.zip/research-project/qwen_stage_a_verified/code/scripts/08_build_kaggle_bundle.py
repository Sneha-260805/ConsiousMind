"""Build the Kaggle upload bundle and notebook (nothing is run).

    python scripts/08_build_kaggle_bundle.py
Writes kaggle/stage_a_bundle.zip (upload as a Kaggle Dataset) and kaggle/stage_a_run.ipynb (import as a notebook).
The bundle contains this Stage-A folder (code, configs, frozen data; no outputs) and, under pilot_frozen/, byte-identical
copies of the four frozen pilot files Stage A needs on the GPU (parse_answers.py, backends.py, kaggle_runner.py,
configs/qwen3_4b_kaggle.json). manifest.json records the SHA-256 of every file; the notebook verifies all of them.
Refuses to build unless the local test suite has passed on the current code (tests/LAST_PASS.json).
"""
import json
import sys
import zipfile
from pathlib import Path

import _bootstrap  # noqa: F401
from src import common as C
from src import frozen_pilot as fp

BUNDLE_ID = "stage-a-reliability-gating-bundle"
BUNDLE_VERSION = 1
KAGGLE_DIR = C.STAGE_ROOT / "kaggle"
PILOT_FILES = ["scripts/parse_answers.py", "scripts/backends.py", "scripts/kaggle_runner.py",
               "configs/qwen3_4b_kaggle.json"]
STAGE_PARTS = ["src", "scripts", "configs", "data/generated", "data/manifests", "tests"]
RUN_ID = "stage_a_qwen3_4b"


def cell(src, kind="code"):
    c = {"cell_type": kind, "metadata": {}, "source": src.strip("\n").splitlines(keepends=True)}
    if kind == "code":
        c.update(execution_count=None, outputs=[])
    return c


NOTEBOOK_CELLS = [
    ("markdown", f"""
# Stage A: reliability-gated diagnostic feedback (simulated critics), Qwen3-4B

**Run with: File -> Save Version -> Save & Run All (Commit).** Do not rely on an open browser tab.
Settings before saving: Accelerator **GPU T4 x2** · Internet **On** · Add Input -> Dataset **{BUNDLE_ID}** (v{BUNDLE_VERSION}).

Frozen solver protocol (unchanged from the pilot): Qwen/Qwen3-4B @ 3101254bbe4169895668a0e7653c3fd1f313576e · FP16 · cuda:0 ·
greedy (temperature 0, do_sample False, num_beams 1) · enable_thinking False · max_new_tokens 768 · batch size 1 ·
stateless single user message, no system message, no history.

Set `MODE` in the first code cell: `"smoke"` (5 requests + canary + determinism probe) or `"full"` (the frozen grid).
Outputs (kept as the saved version's Output): `/kaggle/working/stage_a_runs/` -> run directory, `checkpoints/`,
and the final archive `*_FINAL.zip` + `.sha256.txt`.
"""),
    ("code", f"""
# CELL 1 - parameters (edit before Save Version)
MODE = "smoke"            # "smoke" first; then "full" after the smoke gate says GO and the researcher approves
RUN_ID = "{RUN_ID}"
RESUME_FROM = None        # e.g. "/kaggle/input/<previous-version-output>/stage_a_runs/{RUN_ID}/checkpoints/checkpoint_0080.zip"
RUN_ANALYSIS = True       # tune phase (freezes thresholds) THEN eval phase, then the final archive
"""),
    ("code", f"""
# CELL 2 - locate + verify the bundle, stage it in /kaggle/working (every file hash checked)
import hashlib, json, os, shutil, subprocess, sys
from pathlib import Path
hits = [m.parent for m in Path('/kaggle/input').rglob('manifest.json')
        if json.loads(m.read_text()).get('bundle_id') == '{BUNDLE_ID}']
assert len(hits) == 1, f'STOP: attach exactly one {BUNDLE_ID} dataset (found {{hits}})'
SRC = hits[0]
MAN = json.loads((SRC / 'manifest.json').read_text())
assert MAN['bundle_version'] == {BUNDLE_VERSION}, 'STOP: wrong bundle version'
WORK = Path('/kaggle/working/stage_a_bundle')
if WORK.exists():
    shutil.rmtree(WORK)
shutil.copytree(SRC, WORK)
bad = [r for r, h in MAN['files'].items() if hashlib.sha256((WORK / r).read_bytes()).hexdigest() != h]
assert not bad, f'STOP: hash mismatch {{bad}}'
STAGE = WORK / 'stage_a'
os.environ['STAGE_A_PILOT_ROOT'] = str(WORK / 'pilot_frozen')
OUT = Path('/kaggle/working/stage_a_runs'); OUT.mkdir(parents=True, exist_ok=True)
print('bundle verified:', len(MAN['files']), 'files | code fingerprint', MAN['code_fingerprint'][:16])
def run(*args):
    print('$ python', *args, flush=True)
    r = subprocess.run([sys.executable, *args], cwd=STAGE, env={{**os.environ, 'PYTHONIOENCODING': 'utf-8'}})
    if r.returncode != 0:
        raise RuntimeError(f'STOP: {{args[0]}} exited with {{r.returncode}} (all files written so far are kept)')
"""),
    ("code", """
# CELL 3 - GPU check (Tesla T4, FP16 kernel) + pinned transformers/accelerate (frozen pilot helpers)
sys.path.insert(0, str(WORK / 'pilot_frozen' / 'scripts'))
import kaggle_runner as kr
GPU = kr.gpu_check()
assert 'T4' in GPU['device_name'], 'STOP: the frozen protocol uses a Kaggle Tesla T4'
VERSIONS = kr.ensure_packages()
"""),
    ("code", """
# CELL 4 - local test suite on the GPU machine (no model); must pass before any request is sent
run('-m', 'unittest', 'discover', '-s', 'tests', '-t', '.')
"""),
    ("code", """
# CELL 5 - smoke test (MODE='smoke') or full run (MODE='full'); crash-safe, fsync per request, checkpoints every 10
if MODE == 'smoke':
    run('scripts/04_smoke_test.py', '--solver', 'qwen', '--output-root', str(OUT))
    import platform, torch
    (OUT / 'smoke_qwen' / 'diagnostics' / 'environment.json').write_text(json.dumps({
        'gpu': GPU, 'package_versions': VERSIONS, 'python': sys.version, 'platform': platform.platform(),
        'torch_cuda': torch.version.cuda, 'cudnn': torch.backends.cudnn.version(),
        'kaggle_kernel_run_type': os.environ.get('KAGGLE_KERNEL_RUN_TYPE'),
        'kaggle_docker_image': os.environ.get('KAGGLE_DOCKER_IMAGE'),
        'cublas_workspace_config': os.environ.get('CUBLAS_WORKSPACE_CONFIG'),
        'bundle_version': MAN['bundle_version'], 'bundle_code_fingerprint': MAN['code_fingerprint']}, indent=2, default=str))
    run('scripts/04_smoke_test.py', '--solver', 'qwen', '--output-root', str(OUT), '--verify-resume')   # no model
elif MODE == 'full':
    args = ['scripts/05_run_inference.py', '--solver', 'qwen', '--run-id', RUN_ID, '--output-root', str(OUT)]
    if RESUME_FROM:
        args += ['--resume-from', RESUME_FROM]
    run(*args)
else:
    raise ValueError(MODE)
"""),
    ("code", """
# CELL 6 - analysis: TUNE phase (freezes thresholds on stage_a_tune) THEN EVAL phase (stage_a_eval only)
if MODE == 'full' and RUN_ANALYSIS:
    rd = str(OUT / RUN_ID)
    ad = str(OUT / 'analysis' / RUN_ID)
    run('scripts/06_analyze_results.py', '--phase', 'tune', '--run-dir', rd, '--out-dir', ad)
    run('scripts/06_analyze_results.py', '--phase', 'eval', '--run-dir', rd, '--out-dir', ad)
"""),
    ("code", """
# CELL 7 - final archive (verified) + SHA-256
if MODE == 'full':
    rd = OUT / RUN_ID
    args = ['scripts/07_package_results.py', '--run-dir', str(rd)]
    if RUN_ANALYSIS:
        args += ['--analysis-dir', str(OUT / 'analysis' / RUN_ID)]
    run(*args)
    print(open(next(OUT.glob('*_FINAL.zip.sha256.txt'))).read())
else:
    import zipfile
    src = OUT / 'smoke_qwen'
    dest = Path('/kaggle/working/stage_a_smoke_qwen_RESULTS.zip')
    with zipfile.ZipFile(dest, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in sorted(src.rglob('*')):
            if f.is_file() and f.name != 'run.lock':
                z.write(f, f'smoke_qwen/{f.relative_to(src).as_posix()}')
        z.writestr('bundle_manifest.json', json.dumps(MAN, indent=2))
    with zipfile.ZipFile(dest) as z:
        assert z.testzip() is None, 'STOP: results zip is corrupt'
    sha = hashlib.sha256(dest.read_bytes()).hexdigest()
    Path(str(dest) + '.sha256.txt').write_text(f'{sha}  {dest.name}\\n')
    print(open(src / 'smoke_gate.json').read())
    print('SMOKE RESULTS ZIP:', dest, '| SHA-256:', sha)
    print('Download it from the Output tab (or the saved version Output) and give it to Claude for the report.')
"""),
]


def build():
    lp = C.STAGE_ROOT / "tests" / "LAST_PASS.json"
    fpnt = C.code_fingerprint()
    if not lp.exists() or C.read_json(lp).get("code_fingerprint") != fpnt:
        raise SystemExit("STOP: run the local test suite first (python -m unittest discover -s tests -t .); the bundle "
                         "is only built from code that has passed all local tests")
    cfg = C.load_config()
    files = {}
    for part in STAGE_PARTS:
        for p in sorted((C.STAGE_ROOT / part).rglob("*")):
            if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc":
                files[f"stage_a/{p.relative_to(C.STAGE_ROOT).as_posix()}"] = p.read_bytes()
    for doc in ("README.md", "STAGE_A_PLAN.md", "RUNBOOK.md"):
        if (C.STAGE_ROOT / doc).exists():
            files[f"stage_a/{doc}"] = (C.STAGE_ROOT / doc).read_bytes()
    for relp in PILOT_FILES:
        files[f"pilot_frozen/{relp}"] = fp.path(relp, cfg).read_bytes()
    manifest = {"bundle_id": BUNDLE_ID, "bundle_version": BUNDLE_VERSION, "created": C.now(),
                "code_fingerprint": fpnt, "files": {k: C.sha256_bytes(v) for k, v in sorted(files.items())}}
    KAGGLE_DIR.mkdir(parents=True, exist_ok=True)
    zpath = KAGGLE_DIR / "stage_a_bundle.zip"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for k, v in sorted(files.items()):
            z.writestr(k, v)
        z.writestr("manifest.json", json.dumps(manifest, indent=2))
    nb = {"cells": [cell(src, kind) for kind, src in NOTEBOOK_CELLS],
          "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
                       "language_info": {"name": "python"}},
          "nbformat": 4, "nbformat_minor": 5}
    npath = KAGGLE_DIR / "stage_a_run.ipynb"
    npath.write_text(json.dumps(nb, indent=1), encoding="utf-8")
    info = {"bundle": str(zpath), "bundle_sha256": C.sha256_file(zpath), "files": len(files),
            "notebook": str(npath), "notebook_sha256": C.sha256_file(npath), "code_fingerprint": fpnt}
    C.write_json(KAGGLE_DIR / "BUNDLE_INFO.json", info)
    return info


if __name__ == "__main__":
    print(json.dumps(build(), indent=2))
    sys.exit(0)
