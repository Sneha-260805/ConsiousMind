"""Export the M3 candidates judged ONLY by Claude (review rounds 1-2 of Stage-A construction) into a BLINDED human
review packet. Claude's verdicts are NOT human validation; this packet is for a human reviewer.

    python scripts/09_export_manual_review.py
Writes review/:
  manual_review_blinded.md        one block per candidate, seeded random order, neutral IDs (R01..), no Claude
                                  verdict, no retained/excluded status, no GSM8K index
  manual_review_form.csv          one row per candidate for the human verdicts
  UNBLINDING_KEY_do_not_open_before_review.json   ID -> source problem, slip, Claude verdicts, current status
The 69 candidates are reconstructed exactly by replaying selection with the verdict tables as they stood before
each review round (round 1: no Stage-A verdicts; round 2: round-1 verdicts only). Nothing frozen is modified.
"""
import csv
import random
from types import SimpleNamespace

import _bootstrap  # noqa: F401
from src import common as C
from src import review_verdicts as rv
from src.dataset_builder import enumerate_pool, select
from src.m3_adapter import Pipeline

REVIEW_DIR = C.STAGE_ROOT / "review"
ROUND2_SEMANTIC = {("train", 3692, 1, 47), ("train", 1066, 1, 71), ("train", 7385, 1, 152)}
BLIND_SEED = 6203


def tables(gold=None, site=None, sem=None):
    return SimpleNamespace(GOLD_TEXT_CHECK=gold or {}, SITE_REJECT=site or {}, SEMANTIC_CHECK=sem or {},
                           REVIEWER=rv.REVIEWER)


def replay(cfg, verdicts):
    P = Pipeline(cfg, verdicts)
    pool = enumerate_pool(P, cfg)
    return P, pool, select(P, cfg, pool)["pending"]


def claude_verdicts(P, split, idx, calc_id, wrong):
    gold = P.gold_verdict(split, idx)
    site, site_src = P.site_verdict(split, idx, calc_id)
    sem = P.semantic_verdict(split, idx, calc_id, wrong)
    decision = ("REJECT" if (gold and not gold[0]) or site or (sem and not sem["pass"]) else
                "ACCEPT" if gold and sem and sem["pass"] else "INCOMPLETE")
    return {"gold_text": None if gold is None else {"pass": gold[0], "reason": gold[1], "by": gold[2]},
            "slip_site": None if site is None else {"rejected": True, "reason": site, "by": site_src},
            "semantic": sem, "claude_overall": decision}


def main():
    cfg = C.load_config()
    r1_tables = tables()
    r2_tables = tables(rv.GOLD_TEXT_CHECK, rv.SITE_REJECT,
                       {k: v for k, v in rv.SEMANTIC_CHECK.items() if k not in ROUND2_SEMANTIC})
    P1, pool, pend1 = replay(cfg, r1_tables)
    _, _, pend2 = replay(cfg, r2_tables)
    cands = [(1, x) for x in pend1] + [(2, x) for x in pend2]
    keys = [(k[0], k[1], cor["calc_id"], P1.s2.num_out(cor["corrupted_result"])) for _, (k, cor, *_rest) in cands]
    assert len(cands) == 69 and len(set(keys)) == 69, (len(cands), len(set(keys)))
    P = Pipeline(cfg)                               # current verdicts (for the sealed key only)
    for (split, idx, calc, wrong) in keys:          # every candidate was judged by Claude in round 1 or 2
        v = claude_verdicts(P, split, idx, calc, wrong)
        assert v["claude_overall"] != "INCOMPLETE", (split, idx, calc, wrong)
    items = C.read_json(C.ITEMS_FILE)["items"]
    retained = {(it["source_split"], it["source_index"], it["calc_id"], it["corrupted_result"]): it["item_id"]
                for it in items}

    order = list(range(len(cands)))
    random.Random(BLIND_SEED).shuffle(order)
    md = ["# Stage A: blinded manual review of M3 candidates (human review)", "",
          "Each block shows a GSM8K problem, its reference solution, and ONE injected arithmetic slip (M3: same "
          "operands, operator and meaning; only the computed result is replaced by a nearby wrong value; later steps "
          "are recomputed from it). All automatic structural checks have already passed.", "",
          "Please judge each candidate independently and fill `manual_review_form.csv`:", "",
          "- **Q1 reference OK**: question and reference solution are well-formed (no typos, grammar errors, "
          "fragments, label/unit slips) and the reference reasoning is correct.",
          "- **Q2 real calculation**: the slip step needs genuine calculation (not a recalled fact, times table, "
          "doubling/halving, round-number or carry-free mental arithmetic).",
          "- **Q3 plausible slip, no cue**: the wrong value is a believable slip, keeps the story possible, and leaves "
          "no surface cue (e.g. ungrammatical text, a suspiciously round value).",
          "- **Decision**: ACCEPT only if Q1, Q2 and Q3 are all yes.", "",
          f"Candidates: {len(cands)}. Order is randomised (seed {BLIND_SEED}); some problems appear twice with "
          "different slips. Do not open the unblinding key until all verdicts are entered.", ""]
    form = []
    key_doc = {"WARNING": "Do not open before the blinded review is complete.", "blind_seed": BLIND_SEED,
               "note": "claude_* fields are Claude (coding assistant) judgements, NOT human validation",
               "candidates": {}}
    for n, i in enumerate(order, 1):
        rnd, (k, cor, sem, gold, rec, g) = cands[i]
        split, idx = k
        rid = f"R{n:02d}"
        calc = g["calcs"][cor["calc_id"]]
        t = cor["error_step"]
        gold_steps = [P1.student_text(l) for l in g["lines"]]
        cor_steps = [P1.student_text(l) for l in cor["corrupted_lines"]]
        md += [f"## {rid}", "", f"**Question.** {rec['question']}", "", "**Reference solution**", ""]
        md += [f"{j}. {s}" for j, s in enumerate(gold_steps, 1)]
        md += ["", f"**Slip at Step {t}:** `{calc['ann_expr']}` = {P1.s2.num_out(cor['correct_result'])} "
                   f"→ written as **{P1.s2.num_out(cor['corrupted_result'])}**", "", "**Solution with the slip** "
               "(changed steps marked *)", ""]
        md += [f"{j}.{'*' if a != b else ''} {b}" for j, (a, b) in enumerate(zip(gold_steps, cor_steps), 1)]
        md += ["", f"Final answer {P1.s2.num_out(g['final'])} → {P1.s2.num_out(cor['corrupted_final'])}", ""]
        form.append({"review_id": rid, "q1_reference_ok_Y_N": "", "q2_real_calculation_Y_N": "",
                     "q3_plausible_no_cue_Y_N": "", "decision_ACCEPT_REJECT": "", "reviewer": "", "notes": ""})
        wrong = P1.s2.num_out(cor["corrupted_result"])
        key_doc["candidates"][rid] = {
            "source_problem_id": f"gsm8k:{split}:{idx}", "calc_id": cor["calc_id"], "error_step": t,
            "expression": calc["ann_expr"], "correct_result": P1.s2.num_out(cor["correct_result"]),
            "corrupted_result": wrong, "claude_review_round": rnd,
            "claude_verdicts": claude_verdicts(P, split, idx, cor["calc_id"], wrong),
            "currently_retained_as": retained.get((split, idx, cor["calc_id"], wrong)),
            "human_validated": False}
    REVIEW_DIR.mkdir(parents=True, exist_ok=True)
    (REVIEW_DIR / "manual_review_blinded.md").write_text("\n".join(md) + "\n", encoding="utf-8", newline="\n")
    with open(REVIEW_DIR / "manual_review_form.csv", "w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(form[0]))
        w.writeheader()
        w.writerows(form)
    C.write_json(REVIEW_DIR / "UNBLINDING_KEY_do_not_open_before_review.json", key_doc)
    from collections import Counter
    summ = {"candidates": len(cands), "round1": len(pend1), "round2": len(pend2),
            "claude_overall": dict(Counter(v["claude_verdicts"]["claude_overall"]
                                           for v in key_doc["candidates"].values())),
            "currently_retained": sum(bool(v["currently_retained_as"]) for v in key_doc["candidates"].values()),
            "error_step": dict(sorted(Counter(v["error_step"] for v in key_doc["candidates"].values()).items())),
            "distinct_problems": len({v["source_problem_id"] for v in key_doc["candidates"].values()})}
    C.write_json(REVIEW_DIR / "manual_review_summary.json", summ)
    print(summ)


if __name__ == "__main__":
    main()
