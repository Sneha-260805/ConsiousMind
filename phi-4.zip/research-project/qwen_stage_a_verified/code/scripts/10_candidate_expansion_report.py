"""Candidate-expansion report (no frozen file is modified; GSM8K test split is NOT used).

    python scripts/10_candidate_expansion_report.py
Writes review/candidate_expansion_report.md + .json, and a blinded review packet for the later-step candidates that
are still unreviewed (review/expansion_candidates_blinded.md + form + sealed key).

Sections
  A  pool accounting of the 228 fresh train problems with automatically valid M3 options
  B  exclusion breakdown of the problems where every candidate slip was rejected
  C  inventory of EVERY automatically valid option (not only the ones the selection loop visited), by true error
     step and status, under the existing generator and rules
  D  later-step-first dry run with the existing verdicts (one corruption per problem): achievable error positions
  E  what-if outside the existing generator (extra slip deltas; same validity/realism rules) - information only,
     needs researcher approval, nothing is selected from it
"""
import csv
import json
import random
from collections import Counter, defaultdict

import _bootstrap  # noqa: F401
from src import common as C
from src.dataset_builder import enumerate_pool, select
from src.m3_adapter import Pipeline

REVIEW_DIR = C.STAGE_ROOT / "review"
BLIND_SEED = 7411


def option_status(P, key, cor, gold):
    split, idx = key
    wrong = P.s2.num_out(cor["corrupted_result"])
    if gold is not None and not gold[0]:
        return "REJECT_GOLD_TEXT", gold[2]
    site, src = P.site_verdict(split, idx, cor["calc_id"])
    if site:
        return "REJECT_SITE", src
    sem = P.semantic_verdict(split, idx, cor["calc_id"], wrong)
    if sem is not None and not sem["pass"]:
        return "REJECT_SEMANTIC", sem["reviewer"]
    if sem is None or gold is None:
        return "UNREVIEWED", None
    return "PASS_ALL_RECORDED_VERDICTS", sem["reviewer"]


def src_kind(src):
    if src is None:
        return "none"
    return "pilot-era Claude table" if src.startswith("pilot") else "Stage-A Claude table"


def false_step_ok(P, key, cor, checks, pool):
    split, idx = key
    it = P.build_item("tmp", split, idx, pool["records"][key], pool["graphs"][key], cor, checks,
                      {"pass": True, "reason": "", "reviewer": ""}, (True, "", ""), 0)
    return bool(P.valid_false_steps(it))


def hist(c):
    return dict(sorted(Counter(c).items()))


FAMILIES = [  # approximate keyword grouping of the recorded (Claude) reasons, for overview only
    ("round / rounding-looking value", ("lands on a round", "reads as rounding", "round result", "odd result")),
    ("doubling / halving", ("doubling", "halving", "1/2 of")),
    ("times table / recalled multiple or division", ("times table", "times-table", "recalled", "reduces to")),
    ("simple fraction or percentage", ("% of", "/3 of", "/4 of", "/5 of", "/9 of", "/8 of", "mental fraction",
                                       "mental percentage", "x 0.", "x 1.", "x 3.5", "x 4.5", "x 9.5")),
    ("round addends / complements to 10", ("round", "complete", "units sum")),
    ("small-number or carry-free mental sum/subtraction", ("small", "carry-free", "no borrow", "mental sum",
                                                           "mental subtraction")),
    ("surface cue in corrupted text", ("ungrammatical", "surface cue")),
    ("story made impossible", ("impossible",)),
]


def family(reason):
    r = reason.lower()
    for name, keys in FAMILIES:
        if any(k in r for k in keys):
            return name
    return "other mental product"


def main():
    cfg = C.load_config()
    P = Pipeline(cfg)
    pool = enumerate_pool(P, cfg)
    cur = select(P, cfg, pool)
    items = C.read_json(C.ITEMS_FILE)["items"]
    retained_key = {(it["source_split"], it["source_index"]): it for it in items}
    rep = {"generated": C.now(), "source_splits": cfg["dataset"]["source_splits"],
           "note": "All reviewer verdicts referred to here are Claude (coding assistant) judgements, either recorded "
                   "during the pilot or during Stage-A construction. None is human validation."}

    # ---------------- A. accounting
    excl = Counter(e["reason"] for e in cur["excluded"])
    gold_fail = [e for e in cur["excluded"] if e["reason"] == "GOLD_TEXT_REVIEWER_FAIL"]
    rep["A_pool_accounting"] = {
        "fresh_problems_with_automatically_valid_options": len(pool["options"]),
        "retained": len(cur["selected"]),
        "exclusions": dict(excl),
        "gold_text_rejections_by_source": dict(Counter(src_kind(e["reviewer"]) for e in gold_fail)),
        "pilot_problems_removed_first": len(pool["overlap_removed"]),
        "retained_true_error_step": hist(it["true_error_step"] for it in items),
    }

    # ---------------- B. the all-rejected problems
    allrej = [e for e in cur["excluded"] if e["reason"] == "ALL_OPTIONS_REJECTED_BY_REVIEWER_OR_FALSE_STEP"]
    rows_b, pattern, sources, steps_b = [], Counter(), Counter(), Counter()
    for e in allrej:
        split, idx = e["source_problem_id"].split(":")[1], int(e["source_problem_id"].split(":")[2])
        log = cur["option_log"][(split, idx)]
        kinds = sorted({x["status"] for x in log})
        pattern[" + ".join(kinds)] += 1
        sources[" + ".join(sorted({src_kind(x["source"]) for x in log}))] += 1
        sites = sorted({(x["calc_id"], x["error_step"]) for x in log})
        for _, st in sites:
            steps_b[st] += 1
        fams = sorted({family(x.get("reason", "")) for x in log})
        rows_b.append({"source_problem_id": e["source_problem_id"], "n_options": len(log), "families": fams,
                       "sites": sorted({f"Step {x['error_step']}: {x.get('reason', '')}" for x in log}),
                       "n_distinct_sites": len(sites), "error_steps": sorted({st for _, st in sites}),
                       "statuses": dict(Counter(x["status"] for x in log)),
                       "verdict_sources": sorted({src_kind(x["source"]) for x in log}),
                       "reasons": sorted({x.get("reason", "") for x in log})[:4]})
    rep["B_all_options_rejected"] = {
        "n_problems": len(allrej),
        "reason_family_counts (a problem can have several)": dict(Counter(f for r in rows_b for f in r["families"])),
        "capped_options": sum(e.get("capped", 0) for e in allrej),
        "rejection_pattern": dict(pattern),
        "verdict_source_pattern": dict(sources),
        "distinct_rejected_slip_sites_by_true_error_step": hist(steps_b.elements()),
        "problems_with_a_rejected_site_at_step_3_or_later": sum(any(s >= 3 for s in r["error_steps"]) for r in rows_b),
        "problem_detail": rows_b,
    }

    # ---------------- C. full option inventory
    inv, by_problem = [], defaultdict(list)
    for key, opts in pool["options"].items():
        gold = P.gold_verdict(*key)
        for cor, checks in opts:
            st, src = option_status(P, key, cor, gold)
            fs = false_step_ok(P, key, cor, checks, pool) if st in ("PASS_ALL_RECORDED_VERDICTS", "UNREVIEWED") else None
            if fs is False:
                st = "NO_VALID_FALSE_STEP"
            rec = {"problem": key, "calc_id": cor["calc_id"], "error_step": cor["error_step"],
                   "wrong": P.s2.num_out(cor["corrupted_result"]), "status": st, "source": src_kind(src),
                   "cor": cor, "checks": checks}
            inv.append(rec)
            by_problem[key].append(rec)
    rep["C_option_inventory"] = {
        "options_total": len(inv),
        "options_by_status": dict(Counter(r["status"] for r in inv)),
        "options_by_status_and_true_error_step": {s: hist(r["error_step"] for r in inv if r["status"] == s)
                                                  for s in sorted({r["status"] for r in inv})},
        "problems_with_at_least_one_option_passing_all_recorded_verdicts": sum(
            any(r["status"] == "PASS_ALL_RECORDED_VERDICTS" for r in v) for v in by_problem.values()),
        "problems_with_unreviewed_options": sum(any(r["status"] == "UNREVIEWED" for r in v)
                                                for v in by_problem.values()),
        "problems_with_unreviewed_options_that_are_not_retained": sum(
            any(r["status"] == "UNREVIEWED" for r in v) and k not in retained_key for k, v in by_problem.items()),
        "max_true_error_step_available_per_problem (passing or unreviewed, gold not rejected)": hist(
            max(r["error_step"] for r in v if r["status"] in ("PASS_ALL_RECORDED_VERDICTS", "UNREVIEWED"))
            for v in by_problem.values()
            if any(r["status"] in ("PASS_ALL_RECORDED_VERDICTS", "UNREVIEWED") for r in v)),
    }

    excl_reason = {}
    for e in cur["excluded"]:
        sp = e["source_problem_id"].split(":")
        excl_reason[(sp[1], int(sp[2]))] = e["reason"]
    rep["C_option_inventory"]["latest_step_among_options_of_excluded_problems_by_exclusion_reason"] = {
        reason: hist(max(r["error_step"] for r in by_problem[k]) for k in by_problem if excl_reason.get(k) == reason)
        for reason in sorted({v for k, v in excl_reason.items() if k in by_problem})}

    # ---------------- D. later-step-first dry run (current verdicts only; one corruption per problem)
    dry = select(P, cfg, pool, preference="later_step_first", pending_policy="skip")
    dry_steps = hist(cor["error_step"] for _, cor, *_ in dry["selected"])
    # later-step options still unreviewed in the retained problems (they could move an item to a later step)
    later = []
    for key, it in retained_key.items():
        for r in by_problem[key]:
            if r["status"] == "UNREVIEWED" and r["error_step"] > it["true_error_step"]:
                later.append((key, it, r))
    rep["D_later_step_first_dry_run"] = {
        "rule": "same pilot selection loop, options sorted by LATER true error step first; options without a "
                "recorded verdict are skipped (not assumed valid)",
        "selected_problems": len(dry["selected"]),
        "true_error_step_distribution": dry_steps,
        "frozen_pool_true_error_step_distribution": rep["A_pool_accounting"]["retained_true_error_step"],
        "unreviewed_later_step_options_in_retained_problems": len(later),
        "retained_problems_with_such_an_option": len({k for k, _, _ in later}),
        "best_case_step_distribution_if_all_those_pass_human_review": hist(
            max([it["true_error_step"]] + [r["error_step"] for k, _, r in later if k == key])
            for key, it in retained_key.items()),
    }

    # ---------------- E. what-if: extended slip deltas (OUTSIDE the existing generator)
    m3 = P.m3

    def extra_deltas(c):
        v = c["value"]
        out = [100, -100]
        if v.denominator == 1:
            s = str(abs(int(v)))
            for i in range(len(s) - 1):
                t = s[:i] + s[i + 1] + s[i] + s[i + 2:]
                if t[0] != "0" and t != s:
                    out.append(int(t) - int(v))
        return [d for d in out if d not in m3.DELTAS]

    what_if, rej = defaultdict(list), Counter()
    gold_failed = {tuple([e["source_problem_id"].split(":")[1], int(e["source_problem_id"].split(":")[2])])
                   for e in gold_fail}
    for split in cfg["dataset"]["source_splits"]:
        recs = P.load_split(split)
        for idx, rec in enumerate(recs):
            key = (split, idx)
            if key in gold_failed or any(o["source_problem_id"] == f"gsm8k:{split}:{idx}" for o in pool["overlap_removed"]):
                continue
            g, _ = P.s2.build_graph(rec)
            if g is None:
                continue
            opts, nf, _ = P.automatic_options(rec, g, rej, deltas=extra_deltas)
            if nf or not opts:
                continue
            for cor, _ in opts:
                if P.site_reject(split, idx, cor["calc_id"]):
                    continue
                what_if[key].append(cor["error_step"])
    new_problems = [k for k in what_if if k not in pool["options"]]
    rep["E_what_if_extended_deltas_NOT_APPROVED"] = {
        "status": "INFORMATION ONLY - changes the pilot generator's slip set {+-1, +-2, +-10}; requires approval; "
                  "nothing was selected from it",
        "extra_slips": "+-100 (hundreds-digit slip) and adjacent-digit transpositions (e.g. 168 -> 186), every "
                       "other validity, realism and wording rule unchanged; known slip-site rejections applied; "
                       "problems with rejected gold text excluded",
        "problems_gaining_options": len(what_if),
        "of_which_new_problems_not_in_current_pool": len(new_problems),
        "new_problems_by_latest_available_error_step": hist(max(what_if[k]) for k in new_problems),
        "still_needed": "gold-text, slip-site and semantic review (human) for every one of them",
    }

    # ---------------- outputs
    REVIEW_DIR.mkdir(parents=True, exist_ok=True)
    C.write_json(REVIEW_DIR / "candidate_expansion_report.json", rep)
    write_blinded_later(P, pool, later)
    (REVIEW_DIR / "candidate_expansion_report.md").write_text(markdown(rep), encoding="utf-8", newline="\n")
    print(json.dumps({k: {kk: vv for kk, vv in v.items() if kk not in ("problems",)} if isinstance(v, dict) else v
                      for k, v in rep.items()}, indent=1, default=str))


def write_blinded_later(P, pool, later):
    if not later:
        (REVIEW_DIR / "expansion_candidates_blinded.md").write_text(
            "# Later-step slip candidates\n\nNONE. Under the existing generator {+-1, +-2, +-10} and rules, no retained "
            "problem has an automatically valid slip at a later step than its current one, so there is nothing to "
            "review here. See candidate_expansion_report.md sections C-E for where later-step supply exists.\n",
            encoding="utf-8", newline="\n")
        return
    order = list(range(len(later)))
    random.Random(BLIND_SEED).shuffle(order)
    md = ["# Stage A: blinded review of LATER-STEP slip candidates (human review)", "",
          "Alternative slips at a later step for problems already in the pool. Same questions as the main packet "
          "(Q1 reference OK, Q2 real calculation, Q3 plausible slip with no cue; ACCEPT only if all yes). "
          "No candidate below has been judged by anyone yet.", ""]
    form, key = [], {"WARNING": "Do not open before the blinded review is complete.", "candidates": {}}
    for n, i in enumerate(order, 1):
        k, it, r = later[i]
        cor, g, rec = r["cor"], pool["graphs"][k], pool["records"][k]
        rid = f"L{n:02d}"
        gs = [P.student_text(l) for l in g["lines"]]
        cs = [P.student_text(l) for l in cor["corrupted_lines"]]
        md += [f"## {rid}", "", f"**Question.** {rec['question']}", "", "**Reference solution**", ""]
        md += [f"{j}. {s}" for j, s in enumerate(gs, 1)]
        md += ["", f"**Slip at Step {cor['error_step']}:** `{g['calcs'][cor['calc_id']]['ann_expr']}` = "
                   f"{P.s2.num_out(cor['correct_result'])} → written as **{r['wrong']}**", "",
               "**Solution with the slip** (changed steps marked *)", ""]
        md += [f"{j}.{'*' if a != b else ''} {b}" for j, (a, b) in enumerate(zip(gs, cs), 1)]
        md += ["", f"Final answer {P.s2.num_out(g['final'])} → {P.s2.num_out(cor['corrupted_final'])}", ""]
        form.append({"review_id": rid, "q1_reference_ok_Y_N": "", "q2_real_calculation_Y_N": "",
                     "q3_plausible_no_cue_Y_N": "", "decision_ACCEPT_REJECT": "", "reviewer": "", "notes": ""})
        key["candidates"][rid] = {"source_problem_id": f"gsm8k:{k[0]}:{k[1]}", "calc_id": r["calc_id"],
                                  "error_step": r["error_step"], "corrupted_result": r["wrong"],
                                  "currently_retained_item": it["item_id"],
                                  "currently_retained_error_step": it["true_error_step"], "human_validated": False}
    (REVIEW_DIR / "expansion_candidates_blinded.md").write_text("\n".join(md) + "\n", encoding="utf-8", newline="\n")
    if form:
        with open(REVIEW_DIR / "expansion_candidates_form.csv", "w", encoding="utf-8", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(form[0]))
            w.writeheader()
            w.writerows(form)
    C.write_json(REVIEW_DIR / "EXPANSION_UNBLINDING_KEY_do_not_open_before_review.json", key)


def markdown(rep):
    A, B, Cc, D, E = (rep[k] for k in ("A_pool_accounting", "B_all_options_rejected", "C_option_inventory",
                                       "D_later_step_first_dry_run", "E_what_if_extended_deltas_NOT_APPROVED"))
    j = lambda o: "`" + json.dumps(o) + "`"  # noqa: E731
    out = ["# Stage A: candidate-expansion report", "", f"Generated {rep['generated']}. Source: GSM8K "
           f"{', '.join(rep['source_splits'])} only (test split not used). Frozen dataset unchanged.", "",
           f"> {rep['note']}", "",
           "## A. Pool accounting", "",
           f"- Fresh problems with an automatically valid M3 option: **{A['fresh_problems_with_automatically_valid_options']}**"
           f" (the 40 pilot problems were removed first).",
           f"- Retained: **{A['retained']}**; exclusions: {j(A['exclusions'])}.",
           f"- Gold-text rejections by source: {j(A['gold_text_rejections_by_source'])}.",
           f"- Retained true-error step: {j(A['retained_true_error_step'])}.", "",
           "## B. The problems where every candidate slip was rejected", "",
           f"- Problems: **{B['n_problems']}**; options removed by diversity caps: {B['capped_options']} "
           "(every option of these problems was examined).",
           f"- Rejection pattern: {j(B['rejection_pattern'])}.",
           f"- Verdict source: {j(B['verdict_source_pattern'])}.",
           f"- Distinct rejected slip sites by true-error step: {j(B['distinct_rejected_slip_sites_by_true_error_step'])}.",
           f"- Problems that had a (rejected) slip site at Step >= 3: {B['problems_with_a_rejected_site_at_step_3_or_later']}.",
           f"- Reason families (keyword grouping; a problem can have several): "
           f"{j(B['reason_family_counts (a problem can have several)'])}.", "",
           "| problem | steps of rejected sites | rejected sites (recorded reason) | verdict source |",
           "|---|---|---|---|"] + [
           f"| {r['source_problem_id']} | {', '.join(map(str, r['error_steps']))} | "
           f"{'; '.join(x.replace('|', '/') for x in r['sites'])} | {', '.join(r['verdict_sources'])} |"
           for r in B["problem_detail"]] + ["",
           "## C. Every automatically valid option, existing generator and rules", "",
           f"- Options: {Cc['options_total']}; by status: {j(Cc['options_by_status'])}.",
           f"- By status and true-error step: {j(Cc['options_by_status_and_true_error_step'])}.",
           f"- Problems with an option passing all recorded verdicts: "
           f"{Cc['problems_with_at_least_one_option_passing_all_recorded_verdicts']}.",
           f"- Problems with unreviewed options: {Cc['problems_with_unreviewed_options']} "
           f"(not already retained: {Cc['problems_with_unreviewed_options_that_are_not_retained']}).",
           f"- Latest error step available per usable problem: "
           f"{j(Cc['max_true_error_step_available_per_problem (passing or unreviewed, gold not rejected)'])}.",
           f"- Latest step among the options of EXCLUDED problems, by exclusion reason (= what a human could recover "
           f"by overturning a Claude rejection): "
           f"{j(Cc['latest_step_among_options_of_excluded_problems_by_exclusion_reason'])}.", "",
           "## D. Later-step-first dry run (one corruption per problem)", "",
           f"- Rule: {D['rule']}.",
           f"- Selected problems: {D['selected_problems']}; true-error step {j(D['true_error_step_distribution'])} "
           f"(frozen pool: {j(D['frozen_pool_true_error_step_distribution'])}).",
           f"- Unreviewed later-step options in retained problems: {D['unreviewed_later_step_options_in_retained_problems']}"
           f" across {D['retained_problems_with_such_an_option']} problems -> `expansion_candidates_blinded.md` "
           "for human review.",
           f"- Best case if all of them pass human review: {j(D['best_case_step_distribution_if_all_those_pass_human_review'])}.",
           "", "## E. What-if outside the existing generator (NOT approved, information only)", "",
           f"- {E['status']}.", f"- Extra slips: {E['extra_slips']}.",
           f"- Problems gaining options: {E['problems_gaining_options']}; new problems not in the current pool: "
           f"**{E['of_which_new_problems_not_in_current_pool']}**; their latest available error step: "
           f"{j(E['new_problems_by_latest_available_error_step'])}.",
           f"- Still needed: {E['still_needed']}.", ""]
    return "\n".join(out)


if __name__ == "__main__":
    main()
