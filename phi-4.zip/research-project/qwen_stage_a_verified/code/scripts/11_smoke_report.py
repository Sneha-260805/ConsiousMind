"""Build the smoke-test report from the downloaded Kaggle results (no model; read-only on the frozen files).

    python scripts/11_smoke_report.py <stage_a_smoke_qwen_RESULTS.zip | smoke run directory>
Independently re-checks (against the LOCAL frozen files, not the Kaggle-side gate): prompt bytes and SHA-256, run
identity, model revision, decoding settings, parsing (frozen parser), truncation, think tags, canary, determinism
probe, persistence/resume check. Writes outputs/smoke_report/smoke_report.md and prints it.
"""
import json
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

import _bootstrap  # noqa: F401
from src import common as C
from src import runner as R
from src.scorer import score_raw_row

PIN = "3101254bbe4169895668a0e7653c3fd1f313576e"


def load(src):
    src = Path(src)
    if src.is_dir():
        return src, None
    tmp = Path(tempfile.mkdtemp())
    with zipfile.ZipFile(src) as z:
        bad = z.testzip()
        if bad:
            raise SystemExit(f"STOP: corrupt member {bad} in {src}")
        z.extractall(tmp)
    run = next(p.parent for p in tmp.rglob("run_manifest.json"))
    return run, tmp


def j(path):
    return C.read_json(path) if path.exists() else None


def main(src):
    run, tmp = load(src)
    by_key, order, frozen = R.load_frozen_inputs()
    man = C.read_json(run / "run_manifest.json")
    raw = C.read_jsonl(run / "raw_outputs.jsonl")
    d = run / "diagnostics"
    ml, env, can, det, res = (j(d / f) for f in ("model_load.json", "environment.json", "canary.json",
                                                    "determinism_probe.json", "resume_check.json"))
    gate = j(run / "smoke_gate.json")
    planned = R.smoke_selection(order, by_key, C.load_config()["runner"]["smoke_requests"])
    eff = (ml or {}).get("effective_settings", {})
    checks = {
        "prompts_byte_identical_to_local_frozen_grid": all(r["prompt"] == by_key[r["request_key"]]["prompt"] for r in raw),
        "prompt_sha256_match": all(C.sha256_text(r["prompt"]) == r["prompt_sha256"] == by_key[r["request_key"]]["prompt_sha256"]
                                   for r in raw),
        "requests_file_sha256_match": man["requests_sha256"] == frozen[C.rel(C.REQUESTS_FILE)],
        "execution_order_sha256_match": man["execution_order_sha256"] == frozen[C.rel(C.ORDER_FILE)],
        "items_and_critics_sha256_match": (man["items_sha256"] == frozen[C.rel(C.ITEMS_FILE)]
                                           and man["critics_sha256"] == frozen[C.rel(C.CRITICS_FILE)]),
        "stage_a_config_sha256_match": man["stage_a_config_sha256"] == frozen[C.rel(C.CONFIG_PATH)],
        "solver_config_is_frozen_pilot_config": man["solver_config_sha256"] == C.load_config()["solver"]["frozen_config_sha256"],
        "smoke_keys_equal_planned": sorted(r["request_key"] for r in raw) == sorted(planned) and len(raw) == len(planned),
        "not_test_only": man["test_only"] is False,
        "model_revision_hub_verified": eff.get("hub_resolved_revision") == PIN == man.get("model_revision"),
        "fp16_cuda0": "float16" in str(eff.get("dtype")) and eff.get("device") == "cuda:0",
        "greedy_non_thinking_768": (eff.get("decoding") == "greedy (do_sample=False, num_beams=1)"
                                    and eff.get("enable_thinking") is False and eff.get("max_new_tokens") == 768),
    }
    scored = [score_raw_row(r) for r in sorted(raw, key=lambda r: r["run_index"])]
    lines = ["# Stage-A real-model smoke test report", "",
             f"Source: `{src}`. Report built {C.now()} against the local frozen files.", "",
             f"Dataset status: {C.DATASET_VALIDATION_STATUS}.", "",
             "## 1. Model / revision actually loaded", ""]
    if ml:
        lines += [f"- model: {eff.get('model')} | requested revision {eff.get('requested_revision')} | Hub-resolved "
                  f"{eff.get('hub_resolved_revision')} | transformers commit hash {eff.get('transformers_commit_hash')}",
                  f"- snapshot: {eff.get('snapshot_path')}",
                  f"- dtype {eff.get('dtype')} | device {eff.get('device')} | {eff.get('decoding')} | enable_thinking "
                  f"{eff.get('enable_thinking')} | max_new_tokens {eff.get('max_new_tokens')} | system prompt "
                  f"{eff.get('system_prompt')}",
                  f"- chat-template check: {json.dumps(eff.get('chat_template_check'))}"]
    else:
        lines.append("- model_load.json NOT PRESENT (mock / incomplete run)")
    lines += ["", "## 2. GPU / runtime environment", ""]
    if env:
        g = env.get("gpu", {})
        lines += [f"- GPU {g.get('device_name')} x{g.get('device_count')} | VRAM {g.get('vram_gb')} GB | capability "
                  f"{g.get('capability')} | FP16 kernel ok {g.get('fp16_kernel_ok')}",
                  f"- torch {g.get('torch')} (CUDA {env.get('torch_cuda')}, cuDNN {env.get('cudnn')}) | packages "
                  f"{json.dumps(env.get('package_versions'))}",
                  f"- Python {env.get('python', '').split()[0]} | {env.get('platform')} | run type "
                  f"{env.get('kaggle_kernel_run_type')} | CUBLAS_WORKSPACE_CONFIG {env.get('cublas_workspace_config')}",
                  f"- bundle v{env.get('bundle_version')} code fingerprint {str(env.get('bundle_code_fingerprint'))[:16]}"]
    else:
        lines.append("- environment.json NOT PRESENT")
    lines += ["", "## 3-6. Raw outputs, parsed outputs, format compliance, truncation", ""]
    for r, s in zip(sorted(raw, key=lambda r: r["run_index"]), scored):
        meta = r["model_metadata"]["response"] or {}
        lines += [f"### {r['request_key']}", "",
                  f"- variant {r['variant']} (pointed step role: {r['pointed_step_role']}) | gold {r['gold_answer']} | "
                  f"corrupted {r['corrupted_answer']}",
                  f"- parsed: numeric `{s['numeric_parsed_answer']}` ({s['numeric_parse_status']}, "
                  f"{s['numeric_parse_source']}) -> outcome **{s['outcome']}** | strict format compliant "
                  f"{s['strict_format_compliant']}",
                  f"- finish_reason {meta.get('finish_reason')} | new tokens {meta.get('new_tokens')} | prompt tokens "
                  f"{meta.get('prompt_tokens')} | truncated {s['truncated']} | think tag {meta.get('think_tag_in_output')}"
                  f" | latency {r['latency_seconds']} s | attempts {r['attempt_count']}", "",
                  "```text", r["raw_response"], "```", ""]
    lines += ["## 7. Canary and determinism", "",
              f"- canary: {json.dumps(can['checks']) if can else 'NOT PRESENT'} | response {can['response']!r}"
              if can else "- canary: NOT PRESENT",
              f"- determinism probe ({det['request_key']}): identical text = **{det['identical_text']}**"
              if det else "- determinism probe: NOT PRESENT", "",
              "## 8. Persistence / resume", "",
              f"- {json.dumps(res)}" if res else "- resume_check.json NOT PRESENT", "",
              "## 9. Prompt / hash checks (re-done locally)", ""]
    lines += [f"- {'PASS' if v else 'FAIL'}  {k}" for k, v in checks.items()]
    lines += ["", "## Kaggle-side smoke gate", "", f"- {json.dumps(gate)}" if gate else "- NOT PRESENT"]
    go = (all(checks.values()) and gate and all(gate["gate"].values()) and can and can["passed"]
          and det and det["identical_text"] and res and res["PASS"])
    lines += ["", "## 10. Safe to launch the full 168-request pilot?", "",
              ("**All smoke criteria met** (completed 5/5, 0 transport failures, 5/5 parsed, 0 truncations, no visible "
               "thinking, prompts and hashes identical, canary passed, determinism probe identical, resume check passed). "
               "Recommendation: GO, subject to the researcher's approval."
               if go else "**NOT YET**: at least one criterion above failed or is missing; see the FAIL / NOT PRESENT "
                          "lines. Do not launch the full run.")]
    out = C.OUTPUTS / "smoke_report"
    out.mkdir(parents=True, exist_ok=True)
    (out / "smoke_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))
    if tmp:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit(__doc__)
    main(sys.argv[1])
