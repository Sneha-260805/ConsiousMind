"""Stage A: controlled feasibility test of reliability-gated diagnostic feedback (simulated critics)."""
