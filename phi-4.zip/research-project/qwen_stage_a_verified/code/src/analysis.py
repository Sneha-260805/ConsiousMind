"""Stage-A analysis. Two phases, run separately and in this order.

CRITIC REALIZATIONS
  primary ("multi")  every policy is averaged over many independent simulated-critic realizations per reliability
                     regime (configs/stage_a.json -> multi_realization). Tune uses only 'tune'-namespace seeds on
                     stage_a_tune; eval uses only 'eval'-namespace seeds on stage_a_eval. A realization only decides
                     which of each item's 6 existing prompts a policy would send (L0, V, LOC/ATTN at the true or the
                     false step), so it needs NO additional model call.
  secondary ("frozen") the single frozen realization (data/generated/simulated_critics.json); binary outcomes, so the
                     exact McNemar test and the four paired cells are reported here.

PHASE tune  (stage_a_tune ONLY; eval rows are discarded before anything is computed)
    threshold sweep over (tau_low, tau_high), per regime and averaged over regimes; Pareto frontier; pre-declared rule:
        maximise gated repair  s.t.  repair >= V repair  AND  misdirected <= ALWAYS_LOCATION misdirected
        tie-break: lower misdirected, lower share of specific-location feedback, then (tau_low, tau_high) ascending
    The PRIMARY policy uses ONE global pair (regime-averaged, realization-averaged tune metrics); per-regime pairs are
    a sensitivity analysis only. -> thresholds_frozen.json (+ .sha256), written once; a differing re-computation STOPS.
    Nothing feasible -> "NO FEASIBLE GATING OPERATING POINT FOUND ON TUNE SET" (no winner is forced).
PHASE eval  (stage_a_eval ONLY; requires the frozen thresholds and verifies their hash)
    per regime (never pooled): policy metrics, paired comparisons, routing, stratification by critic correctness and
    confidence bin, constant-confidence controls, pre-declared outcome label.

Rates pool all (realization, item) cells, i.e. they equal the mean over realizations of each realization's rate.
Paired CIs bootstrap ITEMS (on each item's realization-averaged outcome); critic-draw variability is reported
separately as the 2.5-97.5% range across realizations. Missing responses are reported, never scored as wrong.
"""
import csv
import math
import random
import statistics
from collections import Counter
from pathlib import Path

from . import common as C
from . import feedback_policies as fpol
from .simulated_critic import draw_realization, index as critic_index, realization_seed

STATUS_NONE = "NO REAL MODEL RESULTS YET"
STATUS_MOCK = "NO REAL MODEL RESULTS YET - TEST ONLY MOCK SOLVER (pipeline check, not evidence)"
STATUS_REAL = "REAL MODEL RESULTS - Stage-A feasibility (exploratory, not confirmatory)"
NO_FEASIBLE = "NO FEASIBLE GATING OPERATING POINT FOUND ON TUNE SET"
SPLITS = {"tune": "stage_a_tune", "eval": "stage_a_eval"}
METRICS = ["repair", "corrupted_retention", "misdirected", "parse_failure"]


# ================================================================ context
class Context:
    def __init__(self, cfg, phase, run_dir=None, mode="multi", n_realizations=None):
        self.cfg, self.phase = cfg, phase
        self.split = SPLITS[phase]
        items_doc = C.read_json(C.ITEMS_FILE)
        self.split_doc = C.read_json(C.SPLIT_FILE)
        self.critics = C.read_json(C.CRITICS_FILE)
        self.cidx = critic_index(self.critics)
        self.items = {it["item_id"]: it for it in items_doc["items"]
                      if self.split_doc["assignment"][it["item_id"]] == self.split}
        self.item_ids = sorted(self.items)
        self.reliabilities = {f"r{r:.2f}": r for r in self.critics["target_reliabilities"]}
        self.regimes = list(self.reliabilities)
        self.outcomes, self.run_manifest, self.status = {}, None, STATUS_NONE
        self.scored_sha256 = None
        if run_dir is not None:
            from .scorer import score_run
            run_dir = Path(run_dir)
            self.run_manifest = C.read_json(run_dir / "run_manifest.json")
            _, scored = score_run(run_dir)
            # ONLY this phase's split is kept: the other split's rows are discarded before anything is computed
            kept = [s for s in scored if s["split"] == self.split]
            self.outcomes = {(s["item_id"], s["variant"]): s for s in kept}
            self.scored_sha256 = C.sha256_text("\n".join(
                f"{s['request_key']}|{s['outcome']}" for s in sorted(kept, key=lambda x: x["request_key"])))
            self.status = STATUS_MOCK if self.run_manifest["test_only"] else STATUS_REAL
        self.has_results = bool(self.outcomes)
        self.set_mode(mode, n_realizations)

    def set_mode(self, mode, n_realizations=None):
        self.mode = mode
        if mode == "frozen":
            self.realizations = {reg: [{i: self.cidx[(reg, i)] for i in self.item_ids}] for reg in self.regimes}
            self.realization_info = {"mode": "frozen", "n_realizations": 1,
                                     "source": C.rel(C.CRITICS_FILE)}
            return self
        mr = self.cfg["multi_realization"]
        k = n_realizations or mr[f"n_realizations_{self.phase}"]
        conc = self.cfg["simulated_critic"]["concentration"]
        items = [self.items[i] for i in self.item_ids]
        self.realizations = {reg: [draw_realization(items, r, conc, realization_seed(self.cfg, self.phase, reg, j))
                                   for j in range(k)] for reg, r in self.reliabilities.items()}
        self.realization_info = {"mode": "multi", "phase_seed_namespace": self.phase, "n_realizations": k,
                                 "seed_format": realization_seed(self.cfg, self.phase, "<regime>", 0).replace(
                                     "k00000", "k<index>")}
        return self

    def companion(self, mode, n_realizations=None):
        """Same data and outcomes, different critic-realization mode (no re-scoring)."""
        other = object.__new__(Context)
        other.__dict__.update(self.__dict__)
        return other.set_mode(mode, n_realizations)

    def cell(self, policy, item_id, regime, k=0, tau=None, p_field="p"):
        assert item_id in self.items, "attempt to read an item outside this phase's split"
        rec = self.realizations[regime][k][item_id]
        route, variant = fpol.route(policy, self.items[item_id], rec, tau, p_field)
        return route, self.outcomes.get((item_id, variant)), rec


# ================================================================ metrics
def rates(scored_rows):
    rows = [r for r in scored_rows if r is not None]
    n, missing = len(rows), sum(r is None for r in scored_rows)
    out = {"n": n, "n_missing": missing}
    for m in METRICS:
        out[m] = round(sum(r[m] for r in rows) / n, 6) if n else None
    out["strict_format_compliant"] = round(sum(r["strict_format_compliant"] for r in rows) / n, 6) if n else None
    out["truncated"] = round(sum(r["truncated"] for r in rows) / n, 6) if n else None
    return out


def _percentile(sorted_vals, q):
    if not sorted_vals:
        return None
    pos = (len(sorted_vals) - 1) * q
    lo, hi = math.floor(pos), math.ceil(pos)
    return sorted_vals[lo] + (sorted_vals[hi] - sorted_vals[lo]) * (pos - lo)


def policy_metrics(ctx, policy, regime, tau=None, p_field="p", items=None, rec_filter=None):
    items = items if items is not None else ctx.item_ids
    reals = ctx.realizations[regime]
    cells, routes, per_real = [], Counter(), {m: [] for m in ("repair", "misdirected")}
    for k in range(len(reals)):
        rows = []
        for i in items:
            route, s, rec = ctx.cell(policy, i, regime, k, tau, p_field)
            if rec_filter is not None and not rec_filter(rec):
                continue
            routes[route] += 1
            cells.append(s)
            rows.append(s)
        done = [s for s in rows if s is not None]
        for m in per_real:
            if done:
                per_real[m].append(sum(s[m] for s in done) / len(done))
    out = rates(cells)
    out["n_items"] = len(items)
    out["n_realizations"] = len(reals)
    total = sum(routes.values())
    for r in fpol.ROUTES:
        out[f"share_{r}"] = round(routes.get(r, 0) / total, 6) if total else None
    if len(reals) > 1:
        for m, vals in per_real.items():
            v = sorted(vals)
            out[f"{m}_realization_sd"] = round(statistics.pstdev(v), 6) if v else None
            out[f"{m}_realization_p025"] = round(_percentile(v, 0.025), 6) if v else None
            out[f"{m}_realization_p975"] = round(_percentile(v, 0.975), 6) if v else None
    return out


# ================================================================ statistics
def mcnemar_exact(b, c):
    """Two-sided exact McNemar (binomial test on the discordant pairs, p = 0.5)."""
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    return min(1.0, 2 * sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n)


def paired_bootstrap(a, b, n_resamples, seed):
    """95% percentile CI of mean(a) - mean(b), resampling ITEMS (pairs) with replacement."""
    n = len(a)
    if n == 0:
        return None, None
    rng = random.Random(seed)
    diffs = []
    for _ in range(n_resamples):
        idx = [rng.randrange(n) for _ in range(n)]
        diffs.append(sum(a[i] - b[i] for i in idx) / n)
    diffs.sort()
    return _percentile(diffs, 0.025), _percentile(diffs, 0.975)


def paired_comparison(ctx, regime, pol_a, pol_b, metric, tau_a=None, tau_b=None, p_a="p", p_b="p",
                      label_a=None, label_b=None):
    """A and B are evaluated on the SAME items and the SAME critic realization k (paired twice)."""
    K = len(ctx.realizations[regime])
    a_item, b_item, per_real = [], [], []
    sums = {i: [0, 0, 0] for i in ctx.item_ids}
    real_diff = [[0.0, 0] for _ in range(K)]
    for k in range(K):
        for i in ctx.item_ids:
            _, sa, _ = ctx.cell(pol_a, i, regime, k, tau_a, p_a)
            _, sb, _ = ctx.cell(pol_b, i, regime, k, tau_b, p_b)
            if sa is None or sb is None:
                continue
            sums[i][0] += sa[metric]
            sums[i][1] += sb[metric]
            sums[i][2] += 1
            real_diff[k][0] += sa[metric] - sb[metric]
            real_diff[k][1] += 1
    for i in ctx.item_ids:
        if sums[i][2]:
            a_item.append(sums[i][0] / sums[i][2])
            b_item.append(sums[i][1] / sums[i][2])
    per_real = sorted(d / n for d, n in real_diff if n)
    n = len(a_item)
    an = ctx.cfg["analysis"]
    la, lb = label_a or pol_a, label_b or pol_b
    seed = f"{an['bootstrap_seed']}|{ctx.phase}|{ctx.mode}|{regime}|{la}|{lb}|{metric}"
    lo, hi = paired_bootstrap(a_item, b_item, an["bootstrap_resamples"], seed)
    row = {"regime": regime, "critic_realizations": ctx.mode, "n_realizations": K,
           "comparison": f"{la} vs {lb}", "policy_a": la, "policy_b": lb, "metric": metric,
           "n_paired_items": n, "rate_a": round(sum(a_item) / n, 6) if n else None,
           "rate_b": round(sum(b_item) / n, 6) if n else None,
           "difference_a_minus_b": round((sum(a_item) - sum(b_item)) / n, 6) if n else None,
           "ci95_low_item_bootstrap": None if lo is None else round(lo, 6),
           "ci95_high_item_bootstrap": None if hi is None else round(hi, 6),
           "bootstrap_resamples": an["bootstrap_resamples"], "bootstrap_seed": seed}
    if K == 1:                                   # binary outcomes: four paired cells + exact McNemar
        a_bin, b_bin = [int(round(x)) for x in a_item], [int(round(x)) for x in b_item]
        both = sum(x and y for x, y in zip(a_bin, b_bin))
        a_only = sum(x and not y for x, y in zip(a_bin, b_bin))
        b_only = sum(y and not x for x, y in zip(a_bin, b_bin))
        row.update(cell_both=both, cell_a_only=a_only, cell_b_only=b_only, cell_neither=n - both - a_only - b_only,
                   mcnemar_exact_p=round(mcnemar_exact(a_only, b_only), 6))
    else:
        row.update(realization_diff_p025=round(_percentile(per_real, 0.025), 6) if per_real else None,
                   realization_diff_p975=round(_percentile(per_real, 0.975), 6) if per_real else None,
                   share_realizations_a_gt_b=round(sum(d > 0 for d in per_real) / len(per_real), 6) if per_real else None,
                   share_realizations_a_lt_b=round(sum(d < 0 for d in per_real) / len(per_real), 6) if per_real else None,
                   mcnemar_exact_p="n/a (outcomes averaged over critic realizations; see *_frozen_realization.csv)")
    return row


# ================================================================ PHASE tune
def threshold_pairs(cfg):
    ts = cfg["threshold_sweep"]
    return [(tl, th) for tl in ts["tau_low"] for th in ts["tau_high"] if tl < th]


def _feasible(g, v_repair, a_mis):
    eps = 1e-12
    return (g["repair"] is not None and v_repair is not None and a_mis is not None
            and g["repair"] >= v_repair - eps and g["misdirected"] <= a_mis + eps)


def _select(rows):
    feas = [r for r in rows if r["feasible"]]
    if not feas:
        return None
    feas.sort(key=lambda r: (-r["gated_repair"], r["gated_misdirected"], r["share_location"], r["tau_low"],
                             r["tau_high"]))
    return feas[0]


def pareto(rows):
    out = []
    for r in rows:
        if r["gated_repair"] is None:
            continue
        dominated = any(o["gated_repair"] is not None and o["gated_repair"] >= r["gated_repair"]
                        and o["gated_misdirected"] <= r["gated_misdirected"]
                        and (o["gated_repair"] > r["gated_repair"] or o["gated_misdirected"] < r["gated_misdirected"])
                        for o in rows)
        if not dominated:
            out.append(r)
    return sorted(out, key=lambda r: (r["gated_misdirected"], -r["gated_repair"], r["tau_low"], r["tau_high"]))


def threshold_sweep(ctx):
    pairs = threshold_pairs(ctx.cfg)
    per_regime, base = {}, {}
    for reg in ctx.regimes:
        v, a = policy_metrics(ctx, "V", reg), policy_metrics(ctx, "ALWAYS_LOCATION", reg)
        base[reg] = {"V": v, "ALWAYS_LOCATION": a}
        rows = []
        for tl, th in pairs:
            g = policy_metrics(ctx, "RELIABILITY_GATED", reg, (tl, th))
            rows.append({"scope": reg, "critic_realizations": ctx.mode, "n_realizations": g["n_realizations"],
                         "tau_low": tl, "tau_high": th, "gated_repair": g["repair"],
                         "gated_misdirected": g["misdirected"], "gated_corrupted_retention": g["corrupted_retention"],
                         "gated_parse_failure": g["parse_failure"], "share_verify": g["share_verify"],
                         "share_attention": g["share_attention"], "share_location": g["share_location"],
                         "gated_repair_realization_sd": g.get("repair_realization_sd"),
                         "n_items": g["n_items"], "n_missing": g["n_missing"], "V_repair": v["repair"],
                         "ALWAYS_LOCATION_repair": a["repair"], "ALWAYS_LOCATION_misdirected": a["misdirected"],
                         "feasible": _feasible(g, v["repair"], a["misdirected"])})
        per_regime[reg] = rows
    mean_rows = []
    for k, (tl, th) in enumerate(pairs):
        rs = [per_regime[reg][k] for reg in ctx.regimes]

        def avg(f):
            vals = [r[f] for r in rs]
            return None if any(x is None for x in vals) else round(sum(vals) / len(vals), 6)
        row = {"scope": "mean_over_regimes", "critic_realizations": ctx.mode, "n_realizations": rs[0]["n_realizations"],
               "tau_low": tl, "tau_high": th}
        for f in ("gated_repair", "gated_misdirected", "gated_corrupted_retention", "gated_parse_failure",
                  "share_verify", "share_attention", "share_location", "V_repair", "ALWAYS_LOCATION_repair",
                  "ALWAYS_LOCATION_misdirected"):
            row[f] = avg(f)
        row["n_items"], row["n_missing"] = rs[0]["n_items"], sum(r["n_missing"] for r in rs)
        row["feasible"] = _feasible({"repair": row["gated_repair"], "misdirected": row["gated_misdirected"]},
                                    row["V_repair"], row["ALWAYS_LOCATION_misdirected"])
        mean_rows.append(row)
    return per_regime, mean_rows, base


def _sweep_files(ctx, out_dir, suffix):
    per_regime, mean_rows, base = threshold_sweep(ctx)
    write_csv(out_dir / f"threshold_sweep{suffix}.csv", mean_rows + [r for reg in ctx.regimes for r in per_regime[reg]],
              ctx.status)
    par = [{**r, "pareto_scope": r["scope"]} for r in pareto(mean_rows)]
    for reg in ctx.regimes:
        par += [{**r, "pareto_scope": reg} for r in pareto(per_regime[reg])]
    write_csv(out_dir / f"threshold_pareto{suffix}.csv", par, ctx.status)
    return per_regime, mean_rows, base


def run_tune(ctx, out_dir):
    """ctx: primary (multi-realization) tune context. The frozen-realization sweep is written as a secondary file."""
    out_dir = Path(out_dir)
    per_regime, mean_rows, base = _sweep_files(ctx, out_dir, "")
    fz = ctx.companion("frozen")
    fz_reg, fz_mean, _ = _sweep_files(fz, out_dir, "_frozen_realization")

    g_sel = _select(mean_rows) if ctx.has_results else None
    reg_sel = {reg: _select(per_regime[reg]) if ctx.has_results else None for reg in ctx.regimes}
    fz_sel = _select(fz_mean) if ctx.has_results else None
    tl_th = (g_sel["tau_low"], g_sel["tau_high"]) if g_sel else None
    tune_at_sel = {}
    if tl_th:
        for reg in ctx.regimes:
            g = policy_metrics(ctx, "RELIABILITY_GATED", reg, tl_th)
            tune_at_sel[reg] = {"gated": g, "V": base[reg]["V"], "ALWAYS_LOCATION": base[reg]["ALWAYS_LOCATION"]}
    body = {
        "artifact": "stage_a_frozen_thresholds",
        "data_status": ctx.status,
        "dataset_validation_status": C.DATASET_VALIDATION_STATUS,
        "primary_policy": "RELIABILITY_GATED with ONE global threshold pair (per-regime pairs = sensitivity only)",
        "selection_scope_primary": ctx.cfg["threshold_sweep"]["selection_scope"],
        "selection_rule": ctx.cfg["threshold_sweep"]["selection_rule"],
        "critic_realizations_used_for_selection": ctx.realization_info,
        "candidate_pairs": [list(p) for p in threshold_pairs(ctx.cfg)],
        "selected_global": ({"tau_low": g_sel["tau_low"], "tau_high": g_sel["tau_high"],
                             "tune_mean_over_regimes": g_sel} if g_sel else None),
        "global_status": ("SELECTED" if g_sel else (NO_FEASIBLE if ctx.has_results else STATUS_NONE)),
        "selected_per_regime_sensitivity": {reg: ({"tau_low": s["tau_low"], "tau_high": s["tau_high"]} if s
                                                  else NO_FEASIBLE if ctx.has_results else STATUS_NONE)
                                            for reg, s in reg_sel.items()},
        "frozen_single_realization_selection_INFO_ONLY": (
            {"tau_low": fz_sel["tau_low"], "tau_high": fz_sel["tau_high"]} if fz_sel else NO_FEASIBLE),
        "tune_metrics_at_selected_global": tune_at_sel,
        "tune_split": ctx.split, "tune_items": ctx.item_ids,
        "tune_scored_rows_sha256": ctx.scored_sha256,
        "run_identity": {k: (ctx.run_manifest or {}).get(k) for k in ("run_id", "backend", "test_only",
                                                                      "requests_sha256", "execution_order_sha256",
                                                                      "model_revision")},
        "inputs_sha256": {C.rel(p): C.sha256_file(p) for p in (C.ITEMS_FILE, C.SPLIT_FILE, C.CRITICS_FILE,
                                                                C.CONFIG_PATH)},
    }
    body["threshold_version"] = (f"{ctx.cfg['threshold_sweep']['threshold_version_prefix']}:"
                                 f"{C.sha256_text(repr(sorted((k, str(v)) for k, v in body.items())))[:12]}")
    path = out_dir / "thresholds_frozen.json"
    if ctx.has_results:
        if path.exists():
            old = C.read_json(path)
            if {k: v for k, v in old.items() if k != "frozen_at"} != body:
                raise SystemExit("STOP: thresholds_frozen.json already exists and the tune re-computation differs. "
                                 "Frozen thresholds are never replaced silently.")
        else:
            C.write_json(path, {**body, "frozen_at": C.now()})
            (out_dir / "thresholds_frozen.json.sha256").write_text(C.sha256_file(path) + "\n", encoding="utf-8")
    routing_rows = []
    if tl_th:
        for reg in ctx.regimes:
            routing_rows += routing_summary(ctx, reg, tl_th, "selected_global")
    write_csv(out_dir / "routing_summary_tune.csv", routing_rows, ctx.status)
    write_csv(out_dir / "critic_calibration_tune.csv", critic_calibration(ctx) + critic_calibration(fz), ctx.status)
    return body


# ================================================================ PHASE eval
def load_frozen_thresholds(out_dir):
    path = Path(out_dir) / "thresholds_frozen.json"
    side = Path(out_dir) / "thresholds_frozen.json.sha256"
    if not path.exists() or not side.exists():
        raise SystemExit("STOP: no frozen thresholds. Run the tune phase first (06_analyze_results.py --phase tune).")
    sha = C.sha256_file(path)
    if sha != side.read_text(encoding="utf-8").strip():
        raise SystemExit("STOP: thresholds_frozen.json does not match its recorded SHA-256")
    return C.read_json(path), sha


def routing_summary(ctx, regime, tau, label, p_field="p"):
    rows = []
    cells = [ctx.cell("RELIABILITY_GATED", i, regime, k, tau, p_field)
             for k in range(len(ctx.realizations[regime])) for i in ctx.item_ids]
    total = len(cells)
    for r in fpol.ROUTES:
        sel = [(s, rec) for rr, s, rec in cells if rr == r]
        m = rates([s for s, _ in sel])
        rows.append({"split": ctx.split, "regime": regime, "critic_realizations": ctx.mode,
                     "n_realizations": len(ctx.realizations[regime]), "gate": label, "tau_low": tau[0],
                     "tau_high": tau[1], "route": r, "n_cells": len(sel),
                     "share": round(len(sel) / total, 6) if total else None,
                     "critic_correct_share_in_route": round(sum(rec["critic_correct"] for _, rec in sel) / len(sel), 6)
                     if sel else None, "repair": m["repair"], "misdirected": m["misdirected"]})
    return rows


def critic_calibration(ctx):
    bins = ctx.cfg["analysis"]["confidence_bins"]
    rows = []
    for reg in ctx.regimes:
        recs = [real[i] for real in ctx.realizations[reg] for i in ctx.item_ids]
        base = {"regime": reg, "split": ctx.split, "critic_realizations": ctx.mode,
                "n_realizations": len(ctx.realizations[reg])}

        def row(label, b):
            return {**base, "bin": label, "n_cells": len(b),
                    "mean_p": round(sum(x["p"] for x in b) / len(b), 6) if b else None,
                    "realized_accuracy": round(sum(x["critic_correct"] for x in b) / len(b), 6) if b else None}
        rows.append(row("all", recs))
        for lo, hi in zip(bins[:-1], bins[1:]):
            rows.append(row(f"[{lo:.2f},{min(hi, 1):.2f})", [x for x in recs if lo <= x["p"] < hi]))
    return rows


def label_outcome(ev, tune, delta):
    """Pre-declared descriptive labels (STAGE_A_PLAN.md). ev/tune: metric dicts for one regime."""
    if ev is None:
        return NO_FEASIBLE
    dv = ev["G"]["repair"] - ev["V"]["repair"]
    dmis = ev["A"]["misdirected"] - ev["G"]["misdirected"]
    dv_tune = tune["gated"]["repair"] - tune["V"]["repair"] if tune else None
    if dv >= delta and ev["G"]["misdirected"] < ev["A"]["misdirected"] and dv_tune is not None and dv_tune >= delta:
        return "STRONG FEASIBILITY SIGNAL"
    if dv > -delta and dmis >= delta:
        return "PROMISING / MIXED"
    return "NO SUPPORT"


def _eval_tables(ctx, thr, tau):
    delta = ctx.cfg["analysis"]["interpretation_min_effect"]
    pm_rows, cmp_rows, route_rows, strat_rows, summary_rows = [], [], [], [], []
    for reg in ctx.regimes:
        pols = [("L0", None, "p"), ("V", None, "p"), ("ALWAYS_LOCATION", None, "p"), ("ORACLE_LOCATION", None, "p")]
        if tau:
            pols += [("RELIABILITY_GATED", tau, "p"),
                     ("RELIABILITY_GATED[control_permuted_p]", tau, "control_p_permuted"),
                     ("RELIABILITY_GATED[control_constant_p]", tau, "control_p_constant")]
            rs = thr["selected_per_regime_sensitivity"][reg]
            if isinstance(rs, dict):
                pols.append(("RELIABILITY_GATED[per_regime_thresholds_SENSITIVITY]", (rs["tau_low"], rs["tau_high"]),
                             "p"))
        ms = {}
        for name, t, pf in pols:
            m = policy_metrics(ctx, name.split("[")[0], reg, t, pf)
            ms[name] = m
            pm_rows.append({"split": ctx.split, "regime": reg, "critic_realizations": ctx.mode, "policy": name,
                            "tau_low": t[0] if t else None, "tau_high": t[1] if t else None, **m})
        comps = [("V", "L0", "repair", None, None, "p", "p", None, None)]
        if tau:
            comps = [("RELIABILITY_GATED", "V", "repair", tau, None, "p", "p", None, None),
                     ("RELIABILITY_GATED", "ALWAYS_LOCATION", "repair", tau, None, "p", "p", None, None),
                     ("RELIABILITY_GATED", "ALWAYS_LOCATION", "misdirected", tau, None, "p", "p", None, None),
                     ("RELIABILITY_GATED", "V", "misdirected", tau, None, "p", "p", None, None),
                     ("ORACLE_LOCATION", "RELIABILITY_GATED", "repair", None, tau, "p", "p", None, None),
                     ("V", "L0", "repair", None, None, "p", "p", None, None),
                     ("RELIABILITY_GATED", "RELIABILITY_GATED", "repair", tau, tau, "p", "control_p_permuted",
                      "RELIABILITY_GATED", "RELIABILITY_GATED[control_permuted_p]")]
        for a, b, metric, ta, tb, pa, pb_, la, lb in comps:
            cmp_rows.append({"split": ctx.split, **paired_comparison(ctx, reg, a, b, metric, ta, tb, pa, pb_, la, lb)})
        if tau:
            route_rows += routing_summary(ctx, reg, tau, "selected_global")
            bins = ctx.cfg["analysis"]["confidence_bins"]
            for name in ("V", "ALWAYS_LOCATION", "RELIABILITY_GATED"):
                t = tau if name == "RELIABILITY_GATED" else None
                strata = [(f"critic_correct={cc}", (lambda rec, cc=cc: rec["critic_correct"] is cc)) for cc in (True, False)]
                strata += [(f"p in [{lo:.2f},{min(hi, 1):.2f})", (lambda rec, lo=lo, hi=hi: lo <= rec["p"] < hi))
                           for lo, hi in zip(bins[:-1], bins[1:])]
                for label, f in strata:
                    m = policy_metrics(ctx, name, reg, t, "p", rec_filter=f)
                    if m["n"] or m["n_missing"]:
                        strat_rows.append({"split": ctx.split, "regime": reg, "critic_realizations": ctx.mode,
                                           "policy": name, "stratum": label, **m})
        ev = {"G": ms["RELIABILITY_GATED"], "V": ms["V"], "A": ms["ALWAYS_LOCATION"]} if tau else None
        label = (label_outcome(ev, thr["tune_metrics_at_selected_global"].get(reg), delta)
                 if ctx.has_results else ctx.status)
        cal = critic_calibration(ctx)
        acc = next(r["realized_accuracy"] for r in cal if r["regime"] == reg and r["bin"] == "all")
        summary_rows.append({
            "regime": reg, "split": ctx.split, "critic_realizations": ctx.mode,
            "n_realizations": len(ctx.realizations[reg]), "n_items": len(ctx.item_ids),
            "one_item_equals_pp": round(100 / len(ctx.item_ids), 2) if ctx.item_ids else None,
            "realized_critic_accuracy": acc,
            "tau_low": tau[0] if tau else None, "tau_high": tau[1] if tau else None,
            "threshold_version": thr["threshold_version"],
            **{f"repair_{k}": ms[k]["repair"] for k in ms},
            **{f"misdirected_{k}": ms[k]["misdirected"] for k in ("V", "ALWAYS_LOCATION", "RELIABILITY_GATED")
               if k in ms},
            "gated_minus_V_repair": (round(ms["RELIABILITY_GATED"]["repair"] - ms["V"]["repair"], 6)
                                     if tau and ctx.has_results else None),
            "always_minus_gated_misdirected": (round(ms["ALWAYS_LOCATION"]["misdirected"]
                                                     - ms["RELIABILITY_GATED"]["misdirected"], 6)
                                               if tau and ctx.has_results else None),
            "outcome_label": (label if ctx.mode == "multi" else "secondary analysis (labels use the primary "
                              "multi-realization results)") if (tau or not ctx.has_results) else NO_FEASIBLE,
        })
    return pm_rows, cmp_rows, route_rows, strat_rows, summary_rows


def run_eval(ctx, out_dir):
    """ctx: primary (multi-realization) eval context; the frozen realization is written as *_frozen_realization."""
    out_dir = Path(out_dir)
    thr, thr_sha = load_frozen_thresholds(out_dir)
    if ctx.run_manifest and thr["run_identity"]["requests_sha256"] != ctx.run_manifest["requests_sha256"]:
        raise SystemExit("STOP: frozen thresholds were selected on a different run / request grid")
    tau = (thr["selected_global"]["tau_low"], thr["selected_global"]["tau_high"]) if thr["selected_global"] else None
    pm, cmp_, routes, strat, summ = _eval_tables(ctx, thr, tau)
    fz = ctx.companion("frozen")
    fpm, fcmp, froutes, fstrat, fsumm = _eval_tables(fz, thr, tau)
    for name, rows, frows in (("policy_metrics", pm, fpm), ("paired_comparisons", cmp_, fcmp),
                              ("routing_summary", routes, froutes), ("stratified_metrics", strat, fstrat),
                              ("stage_a_summary", summ, fsumm)):
        write_csv(out_dir / f"{name}.csv", rows, ctx.status)
        write_csv(out_dir / f"{name}_frozen_realization.csv", frows, ctx.status)
    write_csv(out_dir / "critic_calibration.csv", critic_calibration(ctx) + critic_calibration(fz), ctx.status)
    report = {"data_status": ctx.status, "dataset_validation_status": C.DATASET_VALIDATION_STATUS,
              "thresholds_frozen_sha256": thr_sha, "threshold_version":
              thr["threshold_version"], "global_status": thr["global_status"], "selected": tau,
              "primary_critic_realizations": ctx.realization_info, "eval_items": ctx.item_ids, "summary": summ,
              "secondary_frozen_realization_summary": fsumm}
    C.write_json(out_dir / "eval_report.json", report)
    return report, pm, cmp_, routes


# ================================================================ output helpers
def write_csv(path, rows, status):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = [{"data_status": status, **r} for r in rows] or [{"data_status": status, "note": "no rows"}]
    fields = []
    for r in rows:
        for k in r:
            if k not in fields:
                fields.append(k)
    with open(path, "w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
