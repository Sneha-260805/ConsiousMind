"""Shared Stage-A helpers: paths, config, SHA-256, deterministic JSON. Standard library only."""
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path

STAGE_ROOT = Path(__file__).resolve().parent.parent          # experiments/stage_a_reliability_gating
REPO_ROOT = STAGE_ROOT.parent.parent                          # ConsiousMind
CONFIG_PATH = STAGE_ROOT / "configs" / "stage_a.json"

DATA_GEN = STAGE_ROOT / "data" / "generated"
DATA_MAN = STAGE_ROOT / "data" / "manifests"
OUTPUTS = STAGE_ROOT / "outputs"
RUNS_ROOT = OUTPUTS / "runs"             # real model runs only
TEST_RUNS_ROOT = OUTPUTS / "test_runs"   # mock / smoke-mock runs only (TEST ONLY)

# frozen Stage-A artifacts (written once by scripts 01-03, then only read)
ITEMS_FILE = DATA_GEN / "stage_a_items.json"
SPLIT_FILE = DATA_GEN / "stage_a_split.json"
CRITICS_FILE = DATA_GEN / "simulated_critics.json"
REQUESTS_FILE = DATA_GEN / "requests_physical.jsonl"
GRID_FILE = DATA_GEN / "request_grid_logical.jsonl"
ORDER_FILE = DATA_GEN / "execution_order.json"
REVIEW_FILE = DATA_GEN / "stage_a_items_review.txt"
DATASET_MANIFEST = DATA_MAN / "dataset_manifest.json"
CRITIC_MANIFEST = DATA_MAN / "critic_manifest.json"
REQUEST_MANIFEST = DATA_MAN / "request_manifest.json"
FROZEN_HASHES = DATA_MAN / "FROZEN_HASHES.json"


DATASET_VALIDATION_STATUS = ("PROVISIONAL: items accepted for Stage-A PILOT use only on the basis of automated checks "
                             "and Claude (coding assistant) review; NOT human-validated")


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def load_config(path=CONFIG_PATH):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()


def sha256_text(text):
    return sha256_bytes(text.encode("utf-8"))


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def dumps(obj):
    """Deterministic JSON text (sorted keys are NOT used, so field order stays readable; callers build
    dicts in a fixed order). Always ends with a newline."""
    return json.dumps(obj, indent=2, ensure_ascii=False) + "\n"


def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(dumps(obj), encoding="utf-8", newline="\n")
    return sha256_file(path)


def write_jsonl(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        for r in rows:
            fh.write(json.dumps(r, ensure_ascii=False) + "\n")
    return sha256_file(path)


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def read_jsonl(path):
    return [json.loads(l) for l in Path(path).read_text(encoding="utf-8").splitlines() if l.strip()]


def write_frozen(path, writer, obj, rebuild=False):
    """Write a frozen artifact once. If it already exists, the rebuilt content must be byte-identical
    (determinism check); a different result stops the script instead of silently overwriting."""
    path = Path(path)
    if path.exists():
        old = path.read_bytes()
        tmp = path.with_name(path.name + ".rebuild_check")
        writer(tmp, obj)
        new = tmp.read_bytes()
        tmp.unlink()
        if old != new:
            if not rebuild:
                raise SystemExit(f"STOP: {path.name} already exists and the rebuild differs. Frozen artifacts are "
                                 "never overwritten silently. Investigate, or pass --rebuild deliberately.")
            writer(path, obj)
            return sha256_file(path), "REBUILT (content changed)"
        return sha256_file(path), "unchanged (rebuild is byte-identical)"
    writer(path, obj)
    return sha256_file(path), "written"


def rel(path):
    try:
        return Path(path).resolve().relative_to(STAGE_ROOT).as_posix()
    except ValueError:
        return str(path)


def env_flag(name):
    return os.environ.get(name, "").strip().lower() in ("1", "true", "yes")


def code_fingerprint():
    """SHA-256 over every Stage-A code/config file (used to tie a passing test run to the exact code bundled)."""
    files = sorted(p for part in ("src", "scripts", "configs", "tests") for p in (STAGE_ROOT / part).rglob("*")
                   if p.is_file() and p.suffix in (".py", ".json") and p.name != "LAST_PASS.json")
    return sha256_text("\n".join(f"{p.relative_to(STAGE_ROOT).as_posix()}:{sha256_file(p)}" for p in files))
