"""INTERFACE PLACEHOLDER for Stage B (real critic + confidence calibration). NOT implemented in Stage A.

Stage A uses simulated critics only (simulated_critic.py), so a failure of the gating idea cannot be confused with a
failure of a real critic. Stage B will provide an object with the same output contract as one simulated-critic
record, so feedback_policies.route() and the analysis can consume it unchanged:

    predict(item) -> {"predicted_step": int (1..n_steps), "p": float in [0, 1] (calibrated probability that
                      predicted_step is the true first error)}

Requirements already implied by Stage A (to be honoured in Stage B): predictions are generated once per item and
frozen before any solver request; the same prediction is reused by every policy; p must be calibrated on data
disjoint from the evaluation items.
"""


class CriticInterface:
    """Contract only. Stage A never instantiates a real critic."""

    def predict(self, item):
        raise NotImplementedError("Stage B: real critic not implemented in Stage A (simulated critics only)")


class RealCriticPlaceholder(CriticInterface):
    def __init__(self, *_, **__):
        raise NotImplementedError("Stage B placeholder: building a real critic is out of scope for Stage A")
