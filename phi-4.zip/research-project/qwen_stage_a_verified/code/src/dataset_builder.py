"""Build the fresh Stage-A GSM8K M3 item set and its tune/eval split.

Order of operations (deterministic, fixed seeds from configs/stage_a.json):
  1. Identify the previous pilot's 40 problems by ORIGINAL problem identity (GSM8K split + index) and by
     normalised question text. If the identities cannot be read reliably, STOP (no guessing).
  2. Enumerate every automatically valid M3 corruption with the pilot's unchanged pipeline, excluding pilot problems.
  3. Select one corruption per problem with the pilot's selection loop (seeded order, direction/magnitude targets,
     diversity caps) and the pilot's reviewer gates (gold-text reading, slip-site realism, semantic plausibility).
     A corruption is only selectable if its item has at least one valid false step.
  4. Assign false steps with the pilot's histogram-matching method; every assignment must pass the pilot's
     false-step validity checks.
  5. Split by original problem into stage_a_tune / stage_a_eval, stratified by true error step.
If a reviewer verdict is missing, nothing frozen is written: the pending items are listed for review instead.
"""
import random
import re
from collections import Counter

from . import common as C
from . import frozen_pilot as fp
from .m3_adapter import Pipeline, count

PENDING_FILE = C.OUTPUTS / "dataset_build" / "pending_review.txt"
BUILD_LOG = C.OUTPUTS / "dataset_build" / "build_stats.json"


def norm_question(q):
    return re.sub(r"\s+", " ", q).strip().lower()


# ---------------------------------------------------------------- previous pilot identities
def previous_pilot_identities(cfg):
    """Return {(split, index)}, {normalised question} for the earlier 40-item pilot. STOP if unreliable."""
    data = C.read_json(fp.path(cfg["pilot_link"]["previous_pilot_items"], cfg))
    items = data.get("items") if isinstance(data, dict) else None
    if not items:
        raise SystemExit("STOP: previous pilot file has no 'items'; cannot guarantee a non-overlapping Stage-A set")
    ids, questions = set(), set()
    for it in items:
        src, idx = it.get("source"), it.get("source_index")
        m = re.fullmatch(r"gsm8k/(train|test)\.jsonl", str(src))
        if not m or not isinstance(idx, int):
            raise SystemExit(f"STOP: pilot item {it.get('id')} has no reliable source identity ({src!r}, {idx!r}); "
                             "cannot guarantee a non-overlapping Stage-A set")
        ids.add((m.group(1), idx))
        questions.add(norm_question(it["question"]))
    if len(items) != 40 or len(ids) != 40:
        raise SystemExit(f"STOP: expected 40 distinct pilot problems, found {len(items)} items / {len(ids)} identities")
    return ids, questions, [it["id"] for it in items]


# ---------------------------------------------------------------- split
def make_split(items, cfg):
    sc = cfg["dataset"]["split"]
    rng = random.Random(sc["seed"])
    groups = {}
    for it in sorted(items, key=lambda x: x["source_problem_id"]):
        groups.setdefault(it[sc["stratify_by"]], []).append(it["source_problem_id"])
    seq = []
    for key in sorted(groups):
        g = groups[key]
        rng.shuffle(g)
        seq += g
    first = "stage_a_tune" if rng.random() < 0.5 else "stage_a_eval"
    second = "stage_a_eval" if first == "stage_a_tune" else "stage_a_tune"
    by_problem = {pid: (first if n % 2 == 0 else second) for n, pid in enumerate(seq)}
    assign = {it["item_id"]: by_problem[it["source_problem_id"]] for it in items}
    tune = sorted(i for i, s in assign.items() if s == "stage_a_tune")
    ev = sorted(i for i, s in assign.items() if s == "stage_a_eval")
    return {
        "split_version": "stage_a_split_v1",
        "unit": sc["unit"],
        "seed": sc["seed"],
        "stratified_by": sc["stratify_by"],
        "method": "items grouped by stratum (sorted), each group shuffled with the seed, groups concatenated in "
                  "stratum order, then assigned alternately to the two splits starting from a seeded coin flip",
        "note": "stage_a_eval is a held-out FEASIBILITY evaluation set, not the final confirmatory test set",
        "counts": {"stage_a_tune": len(tune), "stage_a_eval": len(ev)},
        "stratum_counts": {s: dict(sorted(Counter(str(next(it[sc["stratify_by"]] for it in items if it["item_id"] == i))
                                                  for i in ids).items()))
                           for s, ids in (("stage_a_tune", tune), ("stage_a_eval", ev))},
        "assignment": dict(sorted(assign.items())),
        "problems": {s: sorted(next(it["source_problem_id"] for it in items if it["item_id"] == i) for i in ids)
                     for s, ids in (("stage_a_tune", tune), ("stage_a_eval", ev))},
    }


# ---------------------------------------------------------------- pool + selection
def enumerate_pool(P, cfg):
    """Every fresh problem with automatically valid M3 options (pilot pipeline, pilot problems removed first)."""
    s2, dc = P.s2, cfg["dataset"]
    pilot_ids, pilot_q, _ = previous_pilot_identities(cfg)
    pool = {"examined": Counter(), "eligible": Counter(), "rej": Counter(), "excluded": [], "overlap_removed": [],
            "options": {}, "records": {}, "graphs": {}}
    for split in dc["source_splits"]:
        for idx, rec in enumerate(P.load_split(split)):
            pool["examined"][split] += 1
            g, _ = s2.build_graph(rec)
            if g is None:
                continue
            pool["eligible"][split] += 1
            key = (split, idx)
            if key in pilot_ids or norm_question(rec["question"]) in pilot_q:
                pool["overlap_removed"].append({"source_problem_id": f"gsm8k:{split}:{idx}",
                                                "reason": "OVERLAP_PREVIOUS_PILOT" if key in pilot_ids
                                                else "DUPLICATE_QUESTION_OF_PILOT_ITEM"})
                continue
            opts, n_flagged, flags = P.automatic_options(rec, g, pool["rej"])
            if n_flagged:
                pool["excluded"].append({"source_problem_id": f"gsm8k:{split}:{idx}",
                                         "reason": "GOLD_TEXT_AUTOMATIC_FLAG", "detail": flags})
                continue
            if opts:
                pool["options"][key], pool["records"][key], pool["graphs"][key] = opts, rec, g
    return pool


def select(P, cfg, pool, preference="pilot_order", pending_policy="stop"):
    """The pilot selection loop. preference='pilot_order' reproduces the frozen build exactly;
    'later_step_first' tries options with a later true error step first (dry runs only).
    pending_policy='stop' halts a problem at its first unreviewed option (frozen build); 'skip' records it and
    moves on to the next option (dry runs: what is achievable with the verdicts that exist)."""
    s2, dc = P.s2, cfg["dataset"]
    caps = dc["selection_caps"]
    mag_caps = {int(k): v for k, v in caps["magnitude_caps"].items()}
    options, records, graphs = pool["options"], pool["records"], pool["graphs"]
    excluded = list(pool["excluded"])
    rng = random.Random(dc["selection_seed"])
    order = sorted(options)
    rng.shuffle(order)
    target = {}
    for pos, key in enumerate(order):
        x = rng.random()
        target[key] = ("over" if pos % 2 == 0 else "under", 1 if x < 0.5 else 2 if x < 0.85 else 10)

    direction, magnitude, operator, estep = Counter(), Counter(), Counter(), Counter()
    selected, pending, reviewer_rejections, option_log, skipped_unreviewed = [], [], [], {}, []
    seen_q = set()
    for key in order:
        split, idx = key
        pid = f"gsm8k:{split}:{idx}"
        log = option_log.setdefault(key, [])
        if len(selected) >= dc["target_items"]:
            excluded.append({"source_problem_id": pid, "reason": "NOT_REACHED_TARGET_ALREADY_MET"})
            continue
        g, rec = graphs[key], records[key]
        if norm_question(rec["question"]) in seen_q:
            excluded.append({"source_problem_id": pid, "reason": "DUPLICATE_QUESTION_WITHIN_STAGE_A"})
            continue
        gold = P.gold_verdict(split, idx)
        if gold is not None and not gold[0]:
            excluded.append({"source_problem_id": pid, "reason": "GOLD_TEXT_REVIEWER_FAIL", "detail": gold[1],
                             "reviewer": gold[2]})
            continue
        want_dir, want_mag = target[key]
        opts, capped = [], 0
        for cor, checks in options[key]:
            d = "over" if cor["delta"] > 0 else "under"
            fam = P.op_family(g["calcs"][cor["calc_id"]]["ops"])
            sb, mag = min(cor["error_step"], 5), abs(cor["delta"])
            if direction[d] >= caps["max_per_direction"] or magnitude[mag] >= mag_caps[mag] \
                    or operator[fam] >= caps["operator_cap"] or estep[sb] >= caps["error_step_cap"]:
                capped += 1
                continue
            base = (d != want_dir, mag != want_mag, mag, cor["calc_id"])
            sort_key = ((-cor["error_step"],) + base) if preference == "later_step_first" else base
            opts.append((sort_key, cor, checks, d, fam, sb, mag))
        opts.sort(key=lambda o: o[0])
        outcome, notes = None, []
        for _, cor, checks, d, fam, sb, mag in opts:
            wrong = s2.num_out(cor["corrupted_result"])
            entry = {"calc_id": cor["calc_id"], "error_step": cor["error_step"], "wrong": wrong}
            site, site_src = P.site_verdict(split, idx, cor["calc_id"])
            if site:
                notes.append(f"calc_{cor['calc_id']}->{wrong}: site rejected ({site})")
                reviewer_rejections.append({"key": [split, idx, cor["calc_id"], wrong], "reason": "site: " + site})
                log.append({**entry, "status": "SITE_REJECT", "source": site_src, "reason": site})
                continue
            sem = P.semantic_verdict(split, idx, cor["calc_id"], wrong)
            if sem is not None and not sem["pass"]:
                notes.append(f"calc_{cor['calc_id']}->{wrong}: semantic fail ({sem['reason']})")
                reviewer_rejections.append({"key": [split, idx, cor["calc_id"], wrong], "reason": sem["reason"]})
                log.append({**entry, "status": "SEMANTIC_FAIL", "source": sem["reviewer"], "reason": sem["reason"]})
                continue
            if sem is None or gold is None:
                log.append({**entry, "status": "UNREVIEWED", "source": None,
                            "needs": [x for x, v in (("semantic", sem), ("gold_text", gold)) if v is None]})
                if pending_policy == "skip":
                    skipped_unreviewed.append((key, cor, checks))
                    continue
                pending.append((key, cor, sem, gold, rec, g))
                outcome = "PENDING_REVIEW"
                break
            it = P.build_item("tmp", split, idx, rec, g, cor, checks, sem, gold, dc["selection_seed"])
            if not P.valid_false_steps(it):
                notes.append(f"calc_{cor['calc_id']}->{wrong}: no valid false step before Step {cor['error_step']}")
                log.append({**entry, "status": "NO_VALID_FALSE_STEP", "source": "automatic"})
                continue
            log.append({**entry, "status": "SELECTED", "source": sem["reviewer"]})
            selected.append((key, cor, checks, sem, gold))
            seen_q.add(norm_question(rec["question"]))
            direction[d] += 1
            magnitude[mag] += 1
            operator[fam] += 1
            estep[sb] += 1
            outcome = "SELECTED"
            break
        if outcome is None:
            reason = ("ALL_OPTIONS_CAPPED" if not opts and capped else
                      "NO_VALID_FALSE_STEP" if notes and all("no valid false step" in n for n in notes) else
                      "ALL_OPTIONS_REJECTED_BY_REVIEWER_OR_FALSE_STEP" if notes else
                      "ONLY_UNREVIEWED_OPTIONS")
            excluded.append({"source_problem_id": pid, "reason": reason, "detail": notes, "capped": capped})
        elif outcome == "PENDING_REVIEW":
            excluded.append({"source_problem_id": pid, "reason": "PENDING_REVIEW"})
    return {"selected": selected, "pending": pending, "excluded": excluded,
            "reviewer_rejections": reviewer_rejections, "option_log": option_log,
            "skipped_unreviewed": skipped_unreviewed, "order": order}


# ---------------------------------------------------------------- build
def build(cfg, rebuild=False):
    P = Pipeline(cfg)
    dc = cfg["dataset"]
    pilot_ids, pilot_q, _ = previous_pilot_identities(cfg)
    pool = enumerate_pool(P, cfg)
    sel = select(P, cfg, pool)
    records, graphs = pool["records"], pool["graphs"]
    selected, pending, excluded = sel["selected"], sel["pending"], sel["excluded"]
    reviewer_rejections, overlap_removed = sel["reviewer_rejections"], pool["overlap_removed"]
    stats = {
        "generated": C.now(),
        "selection_seed": dc["selection_seed"],
        "source_splits": dc["source_splits"],
        "source_problems_examined": dict(pool["examined"]),
        "structurally_eligible_problems": dict(pool["eligible"]),
        "pilot_problems_removed_before_candidate_generation": len(overlap_removed),
        "fresh_problems_with_an_automatically_valid_m3_corruption": len(pool["options"]),
        "automatic_option_rejections": count(pool["rej"]),
        "pending_reviewer_checks": len(pending),
        "selected": len(selected),
    }
    if pending:
        write_pending(P, pending)
        C.write_json(BUILD_LOG, {**stats, "status": "PENDING_REVIEW",
                                 "exclusions": count(e["reason"] for e in excluded)})
        return {"status": "PENDING_REVIEW", "pending": len(pending), "selected_so_far": len(selected),
                "pending_file": str(PENDING_FILE), "stats": stats}

    # ---------------- items
    items = []
    for n, (key, cor, checks, sem, gold) in enumerate(selected, 1):
        split, idx = key
        items.append(P.build_item(f"sa_{n:03d}", split, idx, records[key], graphs[key], cor, checks, sem, gold,
                                  dc["selection_seed"]))
    for it in items:
        it["valid_false_step_candidates"] = P.valid_false_steps(it)
    assignment, assign_info = P.assign_false_steps(items) if items else ({}, {})
    for it in items:
        f = assignment[it["item_id"]]
        chk = P.false_step_checks(it, f)
        if not chk["ALL_PASS"]:
            raise SystemExit(f"STOP: histogram-matched false step {f} for {it['item_id']} fails validity: {chk}")
        it["valid_false_step"] = f
        it["false_step_checks"] = chk
        it["dependency"]["false_step_feeds_true_error_step"] = chk["feeds_true_error_step_directly"]

    audit = audit_items(P, items, pilot_ids, pilot_q)
    if not audit["ALL_PASS"]:
        raise SystemExit(f"STOP: item audit failed: { {k: v for k, v in audit.items() if v is not True} }")

    split_doc = make_split(items, cfg)
    for it in items:
        it["stage_a_split"] = split_doc["assignment"][it["item_id"]]

    items_doc = {
        "dataset": "stage_a_gsm8k_m3",
        "dataset_version": "stage_a_items_v1",
        "n_items": len(items),
        "target_items": dc["target_items"],
        "error_type": "M3",
        "selection_seed": dc["selection_seed"],
        "student_facing_fields": ["question", "corrupted_steps", "corrupted_trace"],
        "note": "Fresh items: zero overlap with the 40-item pilot by original GSM8K problem identity. NOT the final "
                "paper test set.",
        "false_step_assignment": assign_info,
        "items": items,
    }
    items_sha, items_status = C.write_frozen(C.ITEMS_FILE, C.write_json, items_doc, rebuild)
    split_doc["items_file_sha256"] = items_sha
    split_sha, split_status = C.write_frozen(C.SPLIT_FILE, C.write_json, split_doc, rebuild)
    C.REVIEW_FILE.write_text(review_text(items), encoding="utf-8", newline="\n")
    if PENDING_FILE.exists():
        PENDING_FILE.unlink()

    manifest = {
        "manifest_version": "stage_a_dataset_manifest_v1",
        "generated": C.now(),
        "status": "COMPLETE" if len(items) >= dc["target_items"] else
                  f"SHORT OF TARGET: {len(items)} valid fresh items (target {dc['target_items']}); "
                  "validation was NOT relaxed",
        "candidates": stats,
        "exclusions_reason_counts": count(e["reason"] for e in excluded),
        "exclusions": excluded,
        "pilot_overlap_removed": overlap_removed,
        "reviewer_rejections_met_during_selection": reviewer_rejections,
        "retained_items": len(items),
        "retained_distributions": {
            "true_error_step": dict(sorted(Counter(it["true_error_step"] for it in items).items())),
            "valid_false_step": dict(sorted(Counter(it["valid_false_step"] for it in items).items())),
            "n_steps": dict(sorted(Counter(it["n_steps"] for it in items).items())),
            "operator_family": count(it["operator_family"] for it in items),
            "error_direction": count(it["error_direction"] for it in items),
            "absolute_error": count(it["absolute_error"] for it in items),
        },
        "overlap_audit": audit["overlap"],
        "item_audit": {k: v for k, v in audit.items() if k != "overlap"},
        "frozen_files": {
            C.rel(C.ITEMS_FILE): {"sha256": items_sha, "status": items_status},
            C.rel(C.SPLIT_FILE): {"sha256": split_sha, "status": split_status},
        },
        "split_counts": split_doc["counts"],
        "pilot_link_files_sha256": cfg["pilot_link"]["files_sha256"],
    }
    C.write_json(C.DATASET_MANIFEST, manifest)
    C.write_json(BUILD_LOG, {**stats, "status": manifest["status"]})
    return {"status": manifest["status"], "items": len(items), "items_sha256": items_sha, "split_sha256": split_sha,
            "split_counts": split_doc["counts"], "stats": stats,
            "exclusions": manifest["exclusions_reason_counts"], "overlap": audit["overlap"]}


# ---------------------------------------------------------------- audits
def audit_items(P, items, pilot_ids, pilot_q):
    ids = [it["item_id"] for it in items]
    pids = [(it["source_split"], it["source_index"]) for it in items]
    qs = [norm_question(it["question"]) for it in items]
    overlap_ids = sorted(f"gsm8k:{s}:{i}" for s, i in set(pids) & pilot_ids)
    overlap_q = sorted(it["item_id"] for it in items if norm_question(it["question"]) in pilot_q)
    leaks = []
    for it in items:
        for term, snip in P.leak_hits([it["question"]] + it["corrupted_steps"] + it["correct_steps"]):
            leaks.append((it["item_id"], term, snip))
        for a, b in zip(it["internal"]["corrupted_steps_annotated"], it["corrupted_steps"]):
            if P.student_text(a) != b:
                leaks.append((it["item_id"], "non-annotation edit", b[:60]))
    a = {
        "unique_item_ids": len(ids) == len(set(ids)),
        "unique_source_problems": len(pids) == len(set(pids)),
        "unique_questions": len(qs) == len(set(qs)),
        "all_m3_validation_pass": all(it["validation"]["automatic_m3_validation"]["ALL_PASS"] for it in items),
        "all_semantic_pass": all(it["validation"]["semantic_plausibility"]["pass"] for it in items),
        "all_gold_text_pass": all(it["validation"]["gold_text_check"]["pass"] for it in items),
        "no_result_revealed_by_wording": not any(it["validation"]["result_revealed_by_wording"]["revealed"]
                                                 for it in items),
        "corrupted_answer_differs_from_gold": all(it["corrupted_answer"] != it["gold_answer"] for it in items),
        "true_step_valid": all(2 <= it["true_error_step"] <= it["n_steps"] for it in items),
        "false_step_valid": all(it["false_step_checks"]["ALL_PASS"] for it in items),
        "no_leakage_in_student_text": not leaks,
        "overlap": {
            "method": "original GSM8K problem identity (split, index) AND normalised question text",
            "previous_pilot_items": 40,
            "overlap_by_problem_identity": overlap_ids,
            "overlap_by_question_text": overlap_q,
            "zero_overlap": not overlap_ids and not overlap_q,
        },
    }
    a["leak_details"] = leaks
    a["ALL_PASS"] = all(v for k, v in a.items() if k not in ("overlap", "leak_details")) and a["overlap"]["zero_overlap"]
    return a


# ---------------------------------------------------------------- review texts
def write_pending(P, pending):
    s2 = P.s2
    out = [f"{len(pending)} item(s) need a reviewer verdict (gold text and/or semantic).",
           "Record verdicts in src/review_verdicts.py, then rerun scripts/01_build_dataset.py.", ""]
    for key, cor, sem, gold, rec, g in pending:
        split, idx = key
        out.append("-" * 78)
        out.append(f"KEY ({split!r}, {idx}, {cor['calc_id']}, {s2.num_out(cor['corrupted_result'])})  step "
                   f"{cor['error_step']}  [{'semantic done' if sem else 'NEEDS semantic'}; "
                   f"{'gold done' if gold else 'NEEDS gold-text'}]")
        out.append(f"  {g['calcs'][cor['calc_id']]['ann_expr']} = {s2.num_out(cor['correct_result'])} -> "
                   f"{s2.num_out(cor['corrupted_result'])}")
        out.append("Q: " + rec["question"])
        for n, (gl, cl) in enumerate(zip(g["lines"], cor["corrupted_lines"]), 1):
            out.append(f"  {n}. {P.student_text(gl)}" + (f"\n  {n}*{P.student_text(cl)}" if gl != cl else ""))
        out.append(f"  final {s2.num_out(g['final'])} -> {s2.num_out(cor['corrupted_final'])}")
    PENDING_FILE.parent.mkdir(parents=True, exist_ok=True)
    PENDING_FILE.write_text("\n".join(out) + "\n", encoding="utf-8", newline="\n")


def review_text(items):
    out = ["STAGE-A M3 ITEMS: REVIEW FILE",
           "Error and false-step markers appear ONLY in this file. Traces are exactly the student-facing text.", ""]
    for it in items:
        chain = it["dependency"]["dependency_chain"]
        roles = {c["step_id"]: c["role"] for c in chain if c["role"] != "unaffected"}
        k = next(c for c in chain if c["role"] == "INJECTED_M3_ERROR")
        out += ["=" * 78, f"ITEM ID: {it['item_id']}   SOURCE: {it['source_problem_id']}   SPLIT: {it['stage_a_split']}",
                f"QUESTION: {it['question']}", "", "GOLD TRACE:"]
        out += [f"  Step {n}: {t}" for n, t in enumerate(it["correct_steps"], 1)]
        out += ["", "CORRUPTED TRACE:"]
        for n, t in enumerate(it["corrupted_steps"], 1):
            mark = {"INJECTED_M3_ERROR": "   >>> TRUE FIRST ERROR <<<", "propagated": "   [recomputed]"}.get(roles.get(n), "")
            if n == it["valid_false_step"]:
                mark += "   [simulated-critic FALSE step]"
            out.append(f"  Step {n}: {t}{mark}")
        out += ["", f"  error step {it['true_error_step']}: {k['gold_expression']} = {k['gold_result']} -> "
                    f"{k['corrupted_claimed_result']}  ({it['error_direction']}, |delta| {it['absolute_error']})",
                f"  false step {it['valid_false_step']} (valid candidates {it['valid_false_step_candidates']}; "
                f"feeds error step directly: {it['false_step_checks']['feeds_true_error_step_directly']})",
                f"  GOLD {it['gold_answer']}   CORRUPTED {it['corrupted_answer']}",
                f"  semantic: {it['validation']['semantic_plausibility']['reason']}",
                f"  gold text: {it['validation']['gold_text_check']['reason']} "
                f"[{it['validation']['gold_text_check']['reviewer']}]", ""]
    return "\n".join(out) + "\n"
