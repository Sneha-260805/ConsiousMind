"""Feedback policies and their routing to PHYSICAL prompt variants.

Feedback wording. VERIFY / LOCATE / ORACLE are byte-identical to the pilot (build_conditions.py); the equality is
asserted when requests are built and in the tests.
    L0                      (no feedback paragraph)
    V                       VERIFY
    ALWAYS_LOCATION         VERIFY + "\n" + LOCATE(predicted_step)
    ORACLE_LOCATION         VERIFY + "\n" + LOCATE(true_error_step)      non-deployable upper reference
    RELIABILITY_GATED       p >= tau_high           -> VERIFY + LOCATE(predicted_step)       route 'location'
                            tau_low <= p < tau_high -> VERIFY + ATTEND(predicted_step)       route 'attention'
                            p < tau_low             -> VERIFY                                route 'verify'
    GENERIC_REFLECTION      GENERIC                                     optional
    ANSWER_GIVEN_REFERENCE  ORACLE(gold_answer)                         optional; NOT oracle location

Physical variants (one model request each per item): L0, V, LOC@k, ATTN@k, GENERIC, ANSWER. Because the simulated
critic, when wrong, always points at the item's valid_false_step, every policy x regime x threshold pair maps onto
LOC@{true,false}, ATTN@{true,false}, V or L0 of the same item; no policy needs its own inference.
"""
VERIFY = "The final answer in the proposed solution is wrong."
LOCATE = "The first mistake is in Step {k}."
ATTEND = "Pay special attention to Step {k}."
ORACLE = "The correct final answer is {a}."
GENERIC = "Review the proposed solution carefully before giving your final answer."

CORE_POLICIES = ["L0", "V", "ALWAYS_LOCATION", "RELIABILITY_GATED", "ORACLE_LOCATION"]
OPTIONAL_POLICIES = ["GENERIC_REFLECTION", "ANSWER_GIVEN_REFERENCE"]
ROUTES = ["verify", "attention", "location"]


def gate_route(p, tau_low, tau_high):
    if not tau_low < tau_high:
        raise ValueError(f"tau_low {tau_low} must be < tau_high {tau_high}")
    if p >= tau_high:
        return "location"
    if p >= tau_low:
        return "attention"
    return "verify"


def variant_for(route, step=None):
    return {"none": "L0", "verify": "V", "location": f"LOC@{step}", "attention": f"ATTN@{step}",
            "generic": "GENERIC", "answer": "ANSWER"}[route]


def route(policy, item, critic=None, tau=None, p_field="p"):
    """-> (route, physical_variant). `critic` is the frozen simulated-critic record for (regime, item)."""
    if policy == "L0":
        return "none", "L0"
    if policy == "V":
        return "verify", "V"
    if policy == "ALWAYS_LOCATION":
        return "location", variant_for("location", critic["predicted_step"])
    if policy == "ORACLE_LOCATION":
        return "location", variant_for("location", item["true_error_step"])
    if policy == "RELIABILITY_GATED":
        r = gate_route(critic[p_field], *tau)
        return r, variant_for(r, critic["predicted_step"] if r != "verify" else None)
    if policy == "GENERIC_REFLECTION":
        return "generic", "GENERIC"
    if policy == "ANSWER_GIVEN_REFERENCE":
        return "answer", "ANSWER"
    raise ValueError(policy)


def feedback_text(variant, item):
    """Feedback paragraph for a physical variant (None = no paragraph)."""
    if variant == "L0":
        return None
    if variant == "V":
        return VERIFY
    if variant.startswith("LOC@"):
        return VERIFY + "\n" + LOCATE.format(k=int(variant[4:]))
    if variant.startswith("ATTN@"):
        return VERIFY + "\n" + ATTEND.format(k=int(variant[5:]))
    if variant == "GENERIC":
        return GENERIC
    if variant == "ANSWER":
        return ORACLE.format(a=item["gold_answer"])
    raise ValueError(variant)


def variants_for_item(item, optional=()):
    t, f = item["true_error_step"], item["valid_false_step"]
    v = ["L0", "V", f"LOC@{t}", f"LOC@{f}", f"ATTN@{t}", f"ATTN@{f}"]
    if "GENERIC_REFLECTION" in optional:
        v.append("GENERIC")
    if "ANSWER_GIVEN_REFERENCE" in optional:
        v.append("ANSWER")
    return v


def variant_family(variant):
    return variant.split("@")[0]


def pointed_step(variant):
    return int(variant.split("@")[1]) if "@" in variant else None
