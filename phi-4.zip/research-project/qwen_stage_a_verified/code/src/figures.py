"""Stage-A figures (plain matplotlib). matplotlib is optional: if it is not installed (this laptop), figures are
skipped with a note and the CSVs remain the record. Every figure carries the data-status banner, so a mock or empty
analysis can never be mistaken for evidence."""
from pathlib import Path

POLICY_ORDER = ["L0", "V", "ALWAYS_LOCATION", "RELIABILITY_GATED", "ORACLE_LOCATION"]


def _plt():
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        return plt
    except ImportError:
        return None


def _x(regimes):
    return [float(r[1:]) for r in regimes]


def _banner(ax, status):
    ax.set_title(status, fontsize=7, color="#a00" if "NO REAL" in status else "#333", loc="left")


def make_all(out_dir, status, pm_rows, cmp_rows, route_rows, calib_rows, regimes):
    plt = _plt()
    out_dir = Path(out_dir) / "figures"
    if plt is None:
        return {"figures": [], "note": "matplotlib not installed; figures skipped (CSV outputs are complete)"}
    out_dir.mkdir(parents=True, exist_ok=True)
    made = []
    x = _x(regimes)

    def series(metric, policy):
        d = {r["regime"]: r[metric] for r in pm_rows if r["policy"] == policy}
        return [d.get(reg) for reg in regimes]

    for metric, fname, ylabel in (("repair", "fig1_repair_vs_reliability.png", "repair rate"),
                                  ("misdirected", "fig2_misdirected_vs_reliability.png", "misdirected-repair rate")):
        fig, ax = plt.subplots(figsize=(6, 4))
        for pol in POLICY_ORDER:
            ys = series(metric, pol)
            if any(v is not None for v in ys):
                ax.plot(x, [v if v is not None else float("nan") for v in ys], marker="o", label=pol)
        ax.set_xlabel("target critic reliability")
        ax.set_ylabel(ylabel)
        ax.set_ylim(-0.02, 1.02)
        ax.set_xticks(x)
        ax.legend(fontsize=7)
        _banner(ax, status)
        fig.tight_layout()
        fig.savefig(out_dir / fname, dpi=150)
        plt.close(fig)
        made.append(fname)

    fig, ax = plt.subplots(figsize=(6, 4.5))
    for pol in POLICY_ORDER:
        pts = [(r["misdirected"], r["repair"], r["regime"]) for r in pm_rows
               if r["policy"] == pol and r["repair"] is not None]
        if pts:
            ax.plot([p[0] for p in pts], [p[1] for p in pts], marker="o", linestyle=":", label=pol)
            for mx, ry, reg in pts:
                ax.annotate(reg[1:], (mx, ry), fontsize=6)
    ax.set_xlabel("misdirected-repair rate (lower is better)")
    ax.set_ylabel("repair rate (higher is better)")
    ax.legend(fontsize=7)
    _banner(ax, status)
    fig.tight_layout()
    fig.savefig(out_dir / "fig3_repair_vs_misdirection_tradeoff.png", dpi=150)
    plt.close(fig)
    made.append("fig3_repair_vs_misdirection_tradeoff.png")

    fig, ax = plt.subplots(figsize=(6, 4))
    bottom = [0.0] * len(regimes)
    for route in ("verify", "attention", "location"):
        d = {r["regime"]: r["share"] or 0 for r in route_rows if r["route"] == route}
        h = [d.get(reg, 0) for reg in regimes]
        ax.bar([str(v) for v in x], h, bottom=bottom, label=route)
        bottom = [b + v for b, v in zip(bottom, h)]
    ax.set_xlabel("target critic reliability")
    ax.set_ylabel("share of gated feedback")
    ax.legend(fontsize=7)
    _banner(ax, status)
    fig.tight_layout()
    fig.savefig(out_dir / "fig4_gating_route_composition.png", dpi=150)
    plt.close(fig)
    made.append("fig4_gating_route_composition.png")

    fig, ax = plt.subplots(figsize=(5, 5))
    ax.plot([0, 1], [0, 1], color="#999", linewidth=1)
    for reg in regimes:
        pts = [(r["mean_p"], r["realized_accuracy"], r["n_cells"]) for r in calib_rows
               if r["regime"] == reg and r["critic_realizations"] == "multi" and r["bin"] != "all" and r["n_cells"]]
        if pts:
            tot = sum(p[2] for p in pts)
            ax.scatter([p[0] for p in pts], [p[1] for p in pts], s=[10 + 400 * p[2] / tot for p in pts],
                       label=reg, alpha=.7)
    ax.set_xlabel("mean confidence p in bin")
    ax.set_ylabel("realized critic accuracy")
    ax.legend(fontsize=7)
    ax.set_title("simulated critic calibration, pooled over realizations (no model needed)", fontsize=8)
    fig.tight_layout()
    fig.savefig(out_dir / "fig5_critic_calibration.png", dpi=150)
    plt.close(fig)
    made.append("fig5_critic_calibration.png")

    comps = [r for r in cmp_rows if r["metric"] == "repair" and r["difference_a_minus_b"] is not None
             and "control" not in r["comparison"]]
    if comps:
        names = sorted({r["comparison"] for r in comps})
        fig, ax = plt.subplots(figsize=(7, 4))
        width = 0.8 / max(1, len(names))
        for k, name in enumerate(names):
            rs = {r["regime"]: r for r in comps if r["comparison"] == name}
            xs = [i + k * width for i in range(len(regimes))]
            ys = [rs[reg]["difference_a_minus_b"] if reg in rs else float("nan") for reg in regimes]
            lo = [ys[i] - rs[reg]["ci95_low_item_bootstrap"] if reg in rs else 0 for i, reg in enumerate(regimes)]
            hi = [rs[reg]["ci95_high_item_bootstrap"] - ys[i] if reg in rs else 0 for i, reg in enumerate(regimes)]
            ax.errorbar(xs, ys, yerr=[lo, hi], fmt="o", capsize=3, label=name)
        ax.axhline(0, color="#999", linewidth=1)
        ax.set_xticks([i + 0.4 - width / 2 for i in range(len(regimes))])
        ax.set_xticklabels(regimes)
        ax.set_ylabel("repair-rate difference (A - B), 95% paired bootstrap CI")
        ax.legend(fontsize=6)
        _banner(ax, status)
        fig.tight_layout()
        fig.savefig(out_dir / "fig6_effect_sizes.png", dpi=150)
        plt.close(fig)
        made.append("fig6_effect_sizes.png")
    return {"figures": made, "note": None}
