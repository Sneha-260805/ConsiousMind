"""Read-only, hash-verified access to the frozen pilot code and data.

Stage A reuses the pilot's validated M3 pipeline, prompt template, answer parser and model backend instead of
re-implementing them. Every pilot file is checked against the SHA-256 recorded in configs/stage_a.json BEFORE it
is imported or read, so a silent change in the pilot would stop Stage A. Bytecode writing is disabled while
importing, so no __pycache__ file is ever created inside the pilot folder.

Locations:
  local   <repo>/information_placebo_pilot            (default)
  Kaggle  <bundle>/pilot_frozen                         (set STAGE_A_PILOT_ROOT, done by the Kaggle notebook)
"""
import importlib
import os
import sys
from pathlib import Path

from .common import REPO_ROOT, load_config, sha256_file


class PilotLinkError(RuntimeError):
    pass


def pilot_root(cfg=None):
    env = os.environ.get("STAGE_A_PILOT_ROOT")
    if env:
        return Path(env)
    cfg = cfg or load_config()
    return REPO_ROOT / cfg["pilot_link"]["pilot_root_relative_to_repo"]


def verify(relpath, cfg=None):
    cfg = cfg or load_config()
    root = pilot_root(cfg)
    expected = cfg["pilot_link"]["files_sha256"].get(relpath)
    if expected is None:
        raise PilotLinkError(f"{relpath} is not a registered frozen pilot file")
    p = root / relpath
    if not p.exists():
        raise PilotLinkError(f"frozen pilot file missing: {p}")
    got = sha256_file(p)
    if got != expected:
        raise PilotLinkError(f"frozen pilot file changed: {relpath} sha256 {got} != recorded {expected}")
    return p


def path(relpath, cfg=None):
    """Verified path of a frozen pilot data/config file (read-only use)."""
    return verify(relpath, cfg)


_SCRIPT_DEPS = {
    "build_m1_candidates": [],
    "build_m3_candidates": ["build_m1_candidates"],
    "build_m3_pilot40": ["build_m1_candidates", "build_m3_candidates"],
    "build_conditions": [],
    "parse_answers": [],
    "backends": [],
    "kaggle_runner": [],
}


def module(name, cfg=None):
    """Import a frozen pilot script as a module after verifying it (and its pilot imports)."""
    cfg = cfg or load_config()
    for dep in _SCRIPT_DEPS[name] + [name]:
        verify(f"scripts/{dep}.py", cfg)
    scripts = str(pilot_root(cfg) / "scripts")
    if scripts not in sys.path:
        sys.path.insert(0, scripts)
    old = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        return importlib.import_module(name)
    finally:
        sys.dont_write_bytecode = old
