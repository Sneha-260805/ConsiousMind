"""Adapter around the frozen, validated pilot M3 pipeline (imported read-only via frozen_pilot).

Reused UNCHANGED from the pilot:
  build_m1_candidates  parsing, strict eligibility filter, dependency graph, exact arithmetic, span rewriting
  build_m3_candidates  make_m3 (corruption + propagation), elementary_fact / digit_pattern_problem (realism),
                       result_revealed (wording check), validate_m3 (M3 validator), build_record (dependency chain)
  build_m3_pilot40     column_trivial / odd_product_parity (pilot realism rules), gold_text_flags (automatic gold-text
                       gate), student_text (annotation removal), leak_hits, recorded reviewer verdicts
  build_conditions     false_step_checks (false-step validity), assign_false_steps (histogram-matched false steps)

New here: split-aware verdict lookup (pilot verdict tables are keyed by GSM8K *train* index only), Stage-A reviewer
verdicts (review_verdicts.py), and a Stage-A record layout. No validation rule is relaxed.
"""
import json
from collections import Counter

from . import frozen_pilot as fp
from . import review_verdicts as rv


class Pipeline:
    def __init__(self, cfg, verdicts=None):
        self.cfg = cfg
        self.rv = verdicts or rv          # Stage-A verdict tables (replaceable to replay earlier review rounds)
        self.s2 = fp.module("build_m1_candidates", cfg)
        self.m3 = fp.module("build_m3_candidates", cfg)
        self.p40 = fp.module("build_m3_pilot40", cfg)
        self.bc = fp.module("build_conditions", cfg)
        self.pilot_semantic = dict(self.m3.REVIEWER_SEMANTIC_CHECK)
        self.pilot_semantic.update(self.p40.PILOT_SEMANTIC_CHECK)

    # ------------------------------------------------------------ source data
    def load_split(self, split):
        rel = {"train": "data/raw/train.jsonl", "test": "data/raw/test.jsonl"}[split]
        p = fp.path(rel, self.cfg)
        return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]

    # ------------------------------------------------------------ verdicts (split-aware)
    def gold_verdict(self, split, idx):
        """(pass, reason, reviewer) or None if never reviewed."""
        if (split, idx) in self.rv.GOLD_TEXT_CHECK:
            ok, why = self.rv.GOLD_TEXT_CHECK[(split, idx)]
            return ok, why, rv.REVIEWER
        if split == "train" and idx in self.p40.GOLD_TEXT_CHECK:
            ok, why = self.p40.GOLD_TEXT_CHECK[idx]
            return ok, why, "pilot (build_m3_pilot40.GOLD_TEXT_CHECK)"
        return None

    def site_verdict(self, split, idx, calc_id):
        """(reason, source) if the calculation site is rejected, else (None, None)."""
        if (split, idx, calc_id) in self.rv.SITE_REJECT:
            return self.rv.SITE_REJECT[(split, idx, calc_id)], rv.REVIEWER
        if split == "train" and (idx, calc_id) in self.p40.SITE_REJECT:
            return self.p40.SITE_REJECT[(idx, calc_id)], "pilot (build_m3_pilot40.SITE_REJECT)"
        return None, None

    def site_reject(self, split, idx, calc_id):
        return self.site_verdict(split, idx, calc_id)[0]

    def semantic_verdict(self, split, idx, calc_id, wrong):
        """{'pass','reason','reviewer'} or None."""
        key = (split, idx, calc_id, wrong)
        if key in self.rv.SEMANTIC_CHECK:
            ok, why = self.rv.SEMANTIC_CHECK[key]
            return {"pass": ok, "reason": why, "reviewer": rv.REVIEWER}
        if split == "train" and (idx, calc_id, wrong) in self.pilot_semantic:
            v = self.pilot_semantic[(idx, calc_id, wrong)]
            return {"pass": v["pass"], "reason": v["reason"], "reviewer": "pilot (recorded verdict)"}
        return None

    # ------------------------------------------------------------ automatic stages (identical to the pilot)
    def automatic_options(self, rec, g, rej, deltas=None):
        """All automatically valid M3 corruptions of one problem, in the pilot's order. Updates `rej`
        (rejection-reason counter). Returns (options, n_options_blocked_by_gold_text_flags, gold_text_flags)."""
        s2, m3, p40 = self.s2, self.m3, self.p40
        flags = p40.gold_text_flags(rec, g)
        out, n_flagged = [], 0
        for c in g["calcs"][:-1]:
            for delta in (m3.DELTAS if deltas is None else deltas(c)):
                cor, why = m3.make_m3(g, c["calc_id"], delta)
                if cor is None:
                    rej["structural: " + why] += 1
                    continue
                calc = g["calcs"][c["calc_id"]]
                dp = m3.elementary_fact(calc) or m3.digit_pattern_problem(calc, cor["corrupted_result"])
                if dp:
                    rej["realism: " + dp.split(" (")[0]] += 1
                    continue
                ct = p40.column_trivial(calc) or p40.odd_product_parity(calc, cor["corrupted_result"])
                if ct:
                    rej["realism (pilot rule): " + ct.split(" (")[0]] += 1
                    continue
                if m3.result_revealed(g, c["calc_id"])[0]:
                    rej["wording reveals result"] += 1
                    continue
                if flags:
                    rej["gold-text flag (automatic)"] += 1
                    n_flagged += 1
                    continue
                checks = m3.validate_m3(rec, g, cor)
                if not checks["ALL_PASS"]:
                    rej["automatic validation failed"] += 1
                    continue
                out.append((cor, checks))
        return out, n_flagged, flags

    def op_family(self, ops):
        return self.p40.op_family(ops)

    # ------------------------------------------------------------ records
    def build_item(self, item_id, split, idx, rec, g, cor, checks, sem, gold, seed):
        s2, m3, p40 = self.s2, self.m3, self.p40
        k = cor["calc_id"]
        base = m3.build_record(idx, rec, g, cor, checks, m3.result_revealed(g, k), sem, item_id)
        r, w = cor["correct_result"], cor["corrupted_result"]
        gold_student = [p40.student_text(l) for l in g["lines"]]
        corr_student = [p40.student_text(l) for l in cor["corrupted_lines"]]
        calc = g["calcs"][k]
        return {
            "item_id": item_id,
            "source_problem_id": f"gsm8k:{split}:{idx}",
            "source_split": split,
            "source_index": idx,
            "question": rec["question"],
            "gold_answer": s2.num_out(g["final"]),
            "correct_steps": gold_student,
            "correct_trace": p40.render_steps(gold_student),
            "corrupted_steps": corr_student,
            "corrupted_trace": p40.render_steps(corr_student),
            "corrupted_answer": s2.num_out(cor["corrupted_final"]),
            "n_steps": len(g["lines"]),
            "true_error_step": cor["error_step"],
            "error_type": "M3",
            "error_subtype": "M3_calculation_slip",
            "calc_id": k,
            "expression": calc["ann_expr"],
            "operator": calc["ops"],
            "operator_family": p40.op_family(calc["ops"]),
            "operands": [s2.num_out(v) for v in calc["leaves"]],
            "correct_result": s2.num_out(r),
            "corrupted_result": s2.num_out(w),
            "delta": s2.num_out(w - r),
            "absolute_error": s2.num_out(abs(w - r)),
            "relative_error": round(float(abs(w - r) / abs(r)), 6),
            "error_direction": "over" if w > r else "under",
            "valid_false_step": None,                 # assigned after selection (histogram-matched)
            "valid_false_step_candidates": None,
            "false_step_checks": None,
            "dependency": {
                "propagated_calc_ids": base["propagated_calc_ids"],
                "dependency_chain": base["dependency_chain"],
                "propagation_explanation": base["propagation_explanation"],
            },
            "validation": {
                "automatic_m3_validation": checks,
                "semantic_plausibility": {"pass": sem["pass"], "reason": sem["reason"], "reviewer": sem["reviewer"]},
                "result_revealed_by_wording": base["result_revealed_by_wording"],
                "gold_text_check": {"pass": gold[0], "reason": gold[1], "reviewer": gold[2], "automatic_flags": []},
                "human_review": {"approved": None, "notes": "human review pending (as for the pilot)"},
            },
            "generation": {
                "pipeline": "pilot M3 pipeline reused unchanged (build_m1_candidates, build_m3_candidates, "
                            "build_m3_pilot40, build_conditions); see configs/stage_a.json pilot_link hashes",
                "selection_seed": seed,
                "delta_applied": cor["delta"],
            },
            "internal": {
                "gold_steps_annotated": g["lines"],
                "corrupted_steps_annotated": cor["corrupted_lines"],
                "gold_answer_text": rec["answer"],
                "corrupted_answer_text": cor["corrupted_answer_text"],
            },
        }

    # ------------------------------------------------------------ false steps
    def _shim(self, it):
        """Pilot-shaped view of a Stage-A item for build_conditions.false_step_checks / assign_false_steps."""
        return {"id": it["item_id"], "error_step": it["true_error_step"],
                "gold_steps_internal": it["internal"]["gold_steps_annotated"],
                "corrupted_steps_internal": it["internal"]["corrupted_steps_annotated"],
                "dependency_chain": it["dependency"]["dependency_chain"],
                "propagated_calc_ids": it["dependency"]["propagated_calc_ids"],
                "corrupted_steps_student": it["corrupted_steps"]}

    def false_step_checks(self, it, f):
        return self.bc.false_step_checks(self._shim(it), f)

    def valid_false_steps(self, it):
        return [f for f in range(1, it["true_error_step"]) if self.false_step_checks(it, f)["ALL_PASS"]]

    def assign_false_steps(self, items):
        """Pilot method: exhaustive histogram matching of false-step positions to true-step positions."""
        return self.bc.assign_false_steps([self._shim(it) for it in items])

    def leak_hits(self, texts):
        return self.p40.leak_hits(texts)

    def student_text(self, line):
        return self.p40.student_text(line)


def count(c):
    return dict(sorted(Counter(c).items(), key=lambda kv: -kv[1]))
