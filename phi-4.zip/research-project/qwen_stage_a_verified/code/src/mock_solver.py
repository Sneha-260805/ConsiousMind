"""TEST ONLY mock solver: no model, deterministic, never used for results.

Implements the same interface as the pilot backends (`generate(prompt) -> result with .text and .metadata`) so the
runner, persistence, parser, scorer and analysis can be exercised end-to-end on a laptop. Every response starts with
a TEST ONLY banner, and every run that uses it is written under outputs/test_runs/ and labelled TEST ONLY.

Behaviour is a fixed function of the prompt hash and the variant (looked up from the frozen request file); the
probabilities below are arbitrary test values, NOT expectations about the real model.
Fault injection for tests: transport_failures {prompt_sha256: n}, crash_after_calls n.
"""
import hashlib
from dataclasses import dataclass, field

from . import frozen_pilot as fp

MOCK_BANNER = "[TEST ONLY - MOCK SOLVER - NOT A MODEL OUTPUT]"
# (repair, corrupted_retention, misdirected); the rest is a malformed response
_PROBS = {"L0": (0.40, 0.45, 0.10), "V": (0.70, 0.10, 0.15), "LOC:true": (0.85, 0.05, 0.05),
          "LOC:false": (0.45, 0.10, 0.40), "ATTN:true": (0.80, 0.05, 0.10), "ATTN:false": (0.60, 0.10, 0.25),
          "GENERIC": (0.50, 0.35, 0.10), "ANSWER": (0.95, 0.0, 0.03)}


class SimulatedCrash(Exception):
    """Imitates the process dying mid-run (resume tests)."""


@dataclass
class MockResult:
    text: str
    metadata: dict = field(default_factory=dict)


class MockSolver:
    name = "mock"

    def __init__(self, requests, transport_failures=None, crash_after_calls=None, max_new_tokens=768):
        self.by_sha = {r["prompt_sha256"]: r for r in requests}
        self.transport_failures = dict(transport_failures or {})
        self.crash_after_calls = crash_after_calls
        self.calls, self.successful_calls = [], 0
        self.max_new_tokens = max_new_tokens
        self.TransportError = fp.module("backends").TransportError

    def generate(self, prompt):
        if not isinstance(prompt, str):
            raise TypeError("solvers accept only the prompt string")
        h = hashlib.sha256(prompt.encode("utf-8")).hexdigest()
        self.calls.append(prompt)
        if self.crash_after_calls is not None and self.successful_calls >= self.crash_after_calls:
            raise SimulatedCrash(f"simulated crash after {self.successful_calls} calls")
        if self.transport_failures.get(h, 0) > 0:
            self.transport_failures[h] -= 1
            raise self.TransportError("simulated transport failure (mock)")
        self.successful_calls += 1
        r = self.by_sha.get(h)
        u = int(h[:8], 16) / 0xFFFFFFFF
        finish = "stop"
        if r is None:
            body = "No request matched this prompt.\nFINAL_ANSWER: 0"
        else:
            fam = r["variant_family"]
            key = f"{fam}:{r['pointed_step_role']}" if fam in ("LOC", "ATTN") else fam
            pr, pc, pm = _PROBS[key]
            gold, corr = r["gold_answer"], r["corrupted_answer"]
            if u < pr:
                body = f"Mock check of the steps.\nFINAL_ANSWER: {gold}"
            elif u < pr + pc:
                body = f"Mock check of the steps.\nFINAL_ANSWER: {corr}"
            elif u < pr + pc + pm:
                body = f"Mock check of the steps.\nFINAL_ANSWER: {gold + 7}"
            elif u < pr + pc + pm + (1 - pr - pc - pm) / 2:
                body = "Mock reasoning that never reaches an answer field ..."
                finish = "length"
            else:
                body = f"Mock answer: {gold} or {corr}\nFINAL_ANSWER: {gold} or {corr}"
        return MockResult(text=f"{MOCK_BANNER}\n{body}",
                          metadata={"mock": True, "prompt_sha256": h, "finish_reason": finish,
                                    "new_tokens": self.max_new_tokens if finish == "length" else 20})

    def effective_settings(self):
        return {"backend": "mock", "TEST_ONLY": True, "note": "no model; deterministic test responses"}
