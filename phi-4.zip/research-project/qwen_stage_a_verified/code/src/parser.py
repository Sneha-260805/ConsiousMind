"""Answer parsing = the FROZEN pilot parser (information_placebo_pilot/scripts/parse_answers.py, version
"2.0 (strict + numeric)"), imported read-only after its SHA-256 is verified. Nothing is re-implemented here, so
Stage A cannot drift from the pilot's parsing contract.

Numeric parser (used for scoring): the LAST `final_answer:` field (case-insensitive) must contain exactly one
standalone number; only if NO such label exists is the final non-empty line inspected (predeclared fallback). The
reasoning body is never searched. Strict parser: diagnostic format compliance only.
"""
from . import frozen_pilot as fp

_PA = None


def _pa():
    global _PA
    if _PA is None:
        _PA = fp.module("parse_answers")
    return _PA


def parser_version():
    return _pa().PARSER_VERSION


def parse(text):
    return _pa().parse_response(text)
