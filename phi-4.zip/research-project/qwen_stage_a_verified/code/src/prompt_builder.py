"""Common solver prompt: the pilot template, reproduced byte-for-byte (verified against the frozen pilot
build_conditions.build_prompt for every Stage-A prompt when requests are built).

    Here is a problem and a proposed step-by-step solution.

    Problem:
    {question}

    Proposed solution:
    Step 1: ...
    Step n: ...

    {feedback paragraph}            <- omitted entirely for L0 (no empty placeholder line)

    Assess the proposed solution carefully and give your best final answer.

    Return the final answer on the last line exactly as:

    FINAL_ANSWER: <answer>

L0 therefore contains no verification wording: no "wrong", "mistake", "error", "correct the" etc. (audited).
"""
from . import feedback_policies as fpol

HEADER = "Here is a problem and a proposed step-by-step solution."
INSTRUCTION = ("Assess the proposed solution carefully and give your best final answer.\n\n"
               "Return the final answer on the last line exactly as:\n\n"
               "FINAL_ANSWER: <answer>")

# audit vocabularies (pilot build_conditions.L0_TERMS / ALWAYS_FORBIDDEN, plus Stage-A labels)
L0_TERMS = ["wrong", "mistake", "error", "incorrect", "corrupt", "gold", "inject", "true step", "false step",
            "find the", "fix the", "correct the", "attention"]
ALWAYS_FORBIDDEN = ["inject", "corrupt", "gold", "m3", "calc_", "calculation_slip", "dependency", "propagat",
                    "validation", "manual_review", "approved", "source_index", "train[", "gsm8k", "<<", ">>",
                    "####", "error_step", "false_step", "true_step", "l_false", "placebo", "m3p_", "sa_0",
                    "critic", "reliab", "confidence", "stage_a", "simulated", "oracle", "gated"]


def render_trace(steps):
    return "\n".join(f"Step {i}: {s}" for i, s in enumerate(steps, 1))


def build_prompt(question, steps, feedback):
    parts = [HEADER, f"Problem:\n{question}", f"Proposed solution:\n{render_trace(steps)}"]
    if feedback is not None:
        parts.append(feedback)
    parts.append(INSTRUCTION)
    return "\n\n".join(parts)


def prompt_for(item, variant):
    return build_prompt(item["question"], item["corrupted_steps"], fpol.feedback_text(variant, item))


def find_terms(text, terms):
    low = text.lower()
    return [t for t in terms if t in low]
