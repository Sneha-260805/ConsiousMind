"""Build the complete request grid BEFORE any inference.

Two levels, both frozen and hashed:
  * PHYSICAL requests (data/generated/requests_physical.jsonl): one per (item, prompt variant). These are the only
    model calls. Key: "{item_id}|{variant}|{solver_tag}|{request_version}".
  * LOGICAL grid (data/generated/request_grid_logical.jsonl): one row per (item, critic regime, critic version,
    policy, threshold version, solver). Each row names the physical request that supplies its response. The gated
    policy's threshold pair is chosen later on stage_a_tune only, so its rows list the three candidate routes
    (verify / attention / location); all three are physical requests in the grid already, so threshold selection
    never triggers new inference and stage_a_eval is never re-run after looking at anything.
Execution order: the physical requests shuffled once with a fixed seed (no variant is systematically first/last).
"""
import difflib
import random
import re
from collections import Counter

from . import common as C
from . import feedback_policies as fpol
from . import prompt_builder as pb
from .simulated_critic import index as critic_index

REQUEST_VERSION = "reqv1"


def physical_key(item_id, variant, solver_tag):
    return f"{item_id}|{variant}|{solver_tag}|{REQUEST_VERSION}"


def build_physical(items, cfg):
    tag = cfg["requests"]["solver_tag"]
    optional = cfg["policies"]["optional_enabled_in_request_grid"]
    rows = []
    for it in sorted(items, key=lambda x: x["item_id"]):
        for v in fpol.variants_for_item(it, optional):
            prompt = pb.prompt_for(it, v)
            ps = fpol.pointed_step(v)
            rows.append({
                "request_key": physical_key(it["item_id"], v, tag),
                "item_id": it["item_id"],
                "split": it["stage_a_split"],
                "source_problem_id": it["source_problem_id"],
                "variant": v,
                "variant_family": fpol.variant_family(v),
                "pointed_step": ps,
                "pointed_step_role": None if ps is None else ("true" if ps == it["true_error_step"] else "false"),
                "true_error_step": it["true_error_step"],
                "valid_false_step": it["valid_false_step"],
                "n_steps": it["n_steps"],
                "gold_answer": it["gold_answer"],
                "corrupted_answer": it["corrupted_answer"],
                "solver_tag": tag,
                "request_version": REQUEST_VERSION,
                "prompt": prompt,
                "prompt_sha256": C.sha256_text(prompt),
            })
    return rows


def build_logical(items, critics_doc, cfg):
    tag = cfg["requests"]["solver_tag"]
    cidx = critic_index(critics_doc)
    ver = critics_doc["critic_version"]
    thr_prefix = cfg["threshold_sweep"]["threshold_version_prefix"]
    rows = []
    policies = cfg["policies"]["core"] + cfg["policies"]["optional_enabled_in_request_grid"]
    for reg_r in critics_doc["target_reliabilities"]:
        reg = f"r{reg_r:.2f}"
        for it in sorted(items, key=lambda x: x["item_id"]):
            cr = cidx[(reg, it["item_id"])]
            for pol in policies:
                base = {"item_id": it["item_id"], "split": it["stage_a_split"], "regime": reg,
                        "critic_version": ver, "policy": pol, "solver_tag": tag}
                if pol == "RELIABILITY_GATED":
                    cand = {r: physical_key(it["item_id"], fpol.variant_for(r, cr["predicted_step"]), tag)
                            for r in fpol.ROUTES}
                    rows.append({**base, "threshold_version": f"{thr_prefix}:selected_on_stage_a_tune",
                                 "logical_key": f"{it['item_id']}|{reg}|{ver}|{pol}|{thr_prefix}|{tag}",
                                 "p": cr["p"], "predicted_step": cr["predicted_step"],
                                 "critic_correct": cr["critic_correct"], "physical_key": None,
                                 "gated_route_candidates": cand})
                else:
                    route, variant = fpol.route(pol, it, cr)
                    rows.append({**base, "threshold_version": None,
                                 "logical_key": f"{it['item_id']}|{reg}|{ver}|{pol}|-|{tag}",
                                 "p": cr["p"], "predicted_step": cr["predicted_step"],
                                 "critic_correct": cr["critic_correct"], "route": route,
                                 "physical_key": physical_key(it["item_id"], variant, tag)})
    return rows


def execution_order(physical, seed):
    keys = sorted(r["request_key"] for r in physical)
    random.Random(seed).shuffle(keys)
    by = {r["request_key"]: r for r in physical}
    order = [{"run_index": i, "request_key": k, "item_id": by[k]["item_id"], "split": by[k]["split"],
              "variant": by[k]["variant"]} for i, k in enumerate(keys)]
    fam = [by[k]["variant_family"] for k in keys]
    return {"seed": seed, "n_requests": len(order),
            "order_sha256": C.sha256_text("\n".join(keys)),
            "first_variant_family": fam[0] if fam else None, "last_variant_family": fam[-1] if fam else None,
            "variant_family_mean_position": {f: round(sum(i for i, x in enumerate(fam) if x == f) /
                                                      max(1, fam.count(f)) / max(1, len(fam) - 1), 4)
                                             for f in sorted(set(fam))},
            "order": order}


# ---------------------------------------------------------------- audits
def audit_prompts(physical, items_by_id, pilot_build_prompt=None, pilot_constants=None):
    v, natural = [], []
    rows_by_item = {}
    for r in physical:
        rows_by_item.setdefault(r["item_id"], {})[r["variant"]] = r
        it = items_by_id[r["item_id"]]
        p, fb = r["prompt"], fpol.feedback_text(r["variant"], it)
        if C.sha256_text(p) != r["prompt_sha256"]:
            v.append((r["request_key"], "prompt sha mismatch"))
        if p != pb.build_prompt(it["question"], it["corrupted_steps"], fb):
            v.append((r["request_key"], "prompt differs from template rebuild"))
        if pilot_build_prompt is not None and p != pilot_build_prompt(it["question"], it["corrupted_steps"], fb):
            v.append((r["request_key"], "prompt differs from the frozen pilot template"))
        rest = p.replace(it["question"], "", 1)
        if fb is not None:
            rest = rest.replace(fb, "", 1)
        for t in pb.find_terms(rest, pb.L0_TERMS + pb.ALWAYS_FORBIDDEN):
            v.append((r["request_key"], f"term '{t}' outside question/feedback"))
        for t in pb.find_terms(it["question"], pb.L0_TERMS + pb.ALWAYS_FORBIDDEN):
            natural.append((r["request_key"], f"term '{t}' occurs naturally in the GSM8K question"))
        if r["variant"] == "L0" and (fb is not None or pb.find_terms(rest, pb.L0_TERMS)):
            v.append((r["request_key"], "L0 leaks verification wording"))
        if fb is not None:
            nums = re.findall(r"\d+(?:\.\d+)?", fb)
            allowed = {str(r["pointed_step"])} if r["pointed_step"] else (
                {str(it["gold_answer"])} if r["variant"] == "ANSWER" else set())
            for n in nums:
                if n not in allowed:
                    v.append((r["request_key"], f"unexpected number {n} in feedback"))
            if r["variant"] != "ANSWER" and str(it["correct_result"]) in nums:
                v.append((r["request_key"], "correct intermediate value in feedback"))
        for k, (g, c) in enumerate(zip(it["correct_steps"], it["corrupted_steps"]), 1):
            if g != c and g in p:
                v.append((r["request_key"], f"gold step {k} text present"))
        for meta in (it["item_id"], it["source_problem_id"], "M3_calculation_slip"):
            if meta.lower() in p.lower():
                v.append((r["request_key"], f"metadata '{meta}' in prompt"))
    matching = matching_audit(rows_by_item, items_by_id)
    constants_ok = None
    if pilot_constants is not None:
        constants_ok = (pilot_constants["VERIFY"] == fpol.VERIFY and pilot_constants["LOCATE"] == fpol.LOCATE
                        and pilot_constants["ORACLE"] == fpol.ORACLE and pilot_constants["HEADER"] == pb.HEADER
                        and pilot_constants["INSTRUCTION"] == pb.INSTRUCTION)
    return {"prompts_checked": len(physical), "violations": v, "natural_question_occurrences": natural,
            "matching": matching, "feedback_constants_identical_to_pilot": constants_ok,
            "ALL_PASS": not v and matching["ALL_PASS"] and constants_ok is not False}


def _differs_only_in_step_number(a, b, sentence_prefix):
    pat = re.escape(sentence_prefix) + r"\d+\."
    masked_a, masked_b = re.sub(pat, "#", a), re.sub(pat, "#", b)
    if masked_a != masked_b or len(re.findall(pat, a)) != 1 or len(re.findall(pat, b)) != 1 or a == b:
        return False
    start = a.index(sentence_prefix) + len(sentence_prefix)
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if tag != "equal" and (i1 < start or not (a[i1:i2].isdigit() or i1 == i2)
                               or not (b[j1:j2].isdigit() or j1 == j2)):
            return False
    return True


def matching_audit(rows_by_item, items_by_id):
    """Prompts of one item differ ONLY in the feedback paragraph, and location/attention prompts that point at
    different steps differ ONLY in the step number."""
    fails = []
    for iid, rows in rows_by_item.items():
        it = items_by_id[iid]
        t, f = it["true_error_step"], it["valid_false_step"]
        P = {k: r["prompt"] for k, r in rows.items()}
        loc_t, loc_f, att_t, att_f = P[f"LOC@{t}"], P[f"LOC@{f}"], P[f"ATTN@{t}"], P[f"ATTN@{f}"]
        checks = {
            "LOC true vs false: only the step number differs": _differs_only_in_step_number(
                loc_t, loc_f, "The first mistake is in Step "),
            "ATTN true vs false: only the step number differs": _differs_only_in_step_number(
                att_t, att_f, "Pay special attention to Step "),
            "V == LOC minus the location sentence": loc_t.replace("\n" + fpol.LOCATE.format(k=t), "", 1) == P["V"],
            "V == ATTN minus the attention sentence": att_t.replace("\n" + fpol.ATTEND.format(k=t), "", 1) == P["V"],
            "LOC and ATTN share everything except that sentence": loc_t.replace(fpol.LOCATE.format(k=t), "#", 1)
                                                                   == att_t.replace(fpol.ATTEND.format(k=t), "#", 1),
            "L0 == V minus the verification paragraph": P["V"].replace("\n\n" + fpol.VERIFY, "", 1) == P["L0"],
        }
        for name, ok in checks.items():
            if not ok:
                fails.append((iid, name))
    return {"items_checked": len(rows_by_item), "failures": fails, "ALL_PASS": not fails}


def summarize(physical, logical):
    keys = {p["request_key"] for p in physical}
    return {
        "n_physical_requests": len(physical),
        "physical_by_variant_family": dict(sorted(Counter(r["variant_family"] for r in physical).items())),
        "physical_by_split": dict(sorted(Counter(r["split"] for r in physical).items())),
        "n_logical_cells": len(logical),
        "logical_by_policy": dict(sorted(Counter(r["policy"] for r in logical).items())),
        "logical_by_regime": dict(sorted(Counter(r["regime"] for r in logical).items())),
        "every_logical_cell_resolves_to_a_physical_request": all(
            (r["physical_key"] in keys) if r["physical_key"] else
            all(k in keys for k in r["gated_route_candidates"].values()) for r in logical),
    }
