"""Stage-A reviewer verdicts for problems/corruptions the pilot never judged.

Same gates and the same standard as the pilot (build_m3_pilot40.GOLD_TEXT_CHECK / SITE_REJECT /
PILOT_SEMANTIC_CHECK): a gold trace must be well-formed, typo-free and correctly reasoned (question included); a slip
site must need real calculation; a corrupted value must not make the story impossible. Verdicts are recorded here so
the build stays deterministic. Keys carry the GSM8K split because pilot tables are keyed by train index only.

Recorded by Claude (coding assistant) during Stage-A construction; human review is still pending, exactly as for the
pilot items.
"""
REVIEWER = "Claude (coding assistant) during Stage-A construction; human review pending"

# (split, source_index) -> (pass, reason)
GOLD_TEXT_CHECK = {
    # ---- review round 1 (2026-10-11)
    ("train", 6550): (False, "gold step 2 has a lower-case fragment after a full stop ('... one headlight. a total of ...')"),
    ("train", 5735): (False, "question mixes tenses ('when the stadium was 3/4 full and if the stadium would have been full')"),
    ("train", 5865): (False, "gold uses the non-standard 'were smelling' / 'which were not smelling' for 'smelled'"),
    ("train", 4520): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 1717): (False, "question grammar error ('They only have few pairs of jeans left')"),
    ("train", 2342): (False, "suspicious gold reasoning: applies the before-the-25th discount although the customer pays on the 25th"),
    ("train", 4887): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 7269): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 2832): (False, "gold step 2 is a verbless fragment ('And pies for 126 * 7 = $882.')"),
    ("train", 5294): (True, "gold sentences well-formed; reasoning correct (13 + 17 + 14 = 44 matches the question)"),
    ("train", 7132): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 1494): (False, "question grammar error ('15 less fish' for 'fewer')"),
    ("train", 6588): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 5036): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 3139): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 3692): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 269): (False, "gold uses the non-standard 'earnt' (cf. train[2016])"),
    ("train", 2610): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 1749): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 2524): (False, "gold step 1 is a run-on sentence opening with a unit-glued number ('50cm3 will make one balloon touch the ceiling so ...')"),
    ("train", 1603): (False, "gold uses 'amount of cookies' for a count noun (cf. 'twice as much potatoes')"),
    ("train", 429): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 1239): (False, "gold calls the new floor 'carpet' (label slip)"),
    ("train", 1937): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 5274): (False, "question typo ('Toms car', missing apostrophe)"),
    ("train", 2103): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 1765): (False, "gold writes 'mama bird' in lower case where the question capitalises 'Mama bird' (cf. train[4501])"),
    ("train", 6867): (False, "gold grammar error ('Jack need $111 - $40'); question 'Each pair of socks cost'"),
    ("train", 5649): (False, "gold steps are unpunctuated run-on sentences ('... than Allison who has 28 so Angela has ...')"),
    ("train", 3982): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 1395): (False, "gold typo 'shopping costs' for 'shipping costs'"),
    ("train", 2923): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 4681): (False, "gold has a mid-sentence capital ('Therefore, It took him') and spacing typos ('640/80= 8')"),
    ("train", 2746): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 3898): (False, "gold formatting typo ('24 x 3= $72', cf. train[4018])"),
    ("train", 5179): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 1546): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 5356): (False, "gold unit inconsistency ('$75 / 7.50' vs '45 / 7.50') and awkward 'The total yards ... is'"),
    ("train", 7014): (False, "gold apostrophe error ('her coworkers last 11 balloons')"),
    ("train", 6076): (False, "question refers to the farmer as 'its' ('adds five new cows to its herd')"),
    ("train", 1712): (False, "question/gold grammar errors ('half a dozen of shirts', 'the shirt will only costs')"),
    ("train", 432): (False, "question grammar error ('how many people have she sold'); gold says 'total sales' but divides the profit"),
    ("train", 7385): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 6008): (False, "gold step 3 labels the weekly total '$3360 a day'; question 'for $5 each' doubles 'each'"),
    ("train", 1605): (False, "gold formatting typo ('5/8* 72')"),
    ("train", 1754): (False, "question uses the non-standard 'How much is left with Emma' (cf. 'remains with')"),
    ("train", 1446): (False, "gold spells 'scarfs' where the question has 'scarves'"),
    ("train", 3996): (False, "question/gold use the malformed phrase 'twenty less the number of slices'"),
    ("train", 6166): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 2505): (False, "question punctuation error ('But, he also bought a book')"),
    ("train", 189): (False, "gold spacing typo ('112/ 7 = 16')"),
    ("train", 781): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 5050): (False, "question grammar error ('if she will buy the tablet in cash')"),
    ("train", 6754): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 6370): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 3268): (True, "gold sentences well-formed; reasoning correct"),
    ("train", 2393): (True, "gold sentences well-formed; reasoning correct"),
}

# (split, source_index, calc_id) -> reason   (calculation sites unrealistic as slip sites)
SITE_REJECT = {
    # ---- review round 1 (2026-10-11)
    ("train", 7269, 1): "14 x 3: mental (cf. 16 x 3)",
    ("train", 7132, 1): "3/5 of 80: mental fraction (cf. 2/5 of 90)",
    ("train", 6588, 1): "21 - 7: small mental subtraction (cf. 21 - 5)",
    ("train", 1749, 1): "750 / 15: reduces to 75 / 15 = 5, mental",
    ("train", 1937, 1): "15 + 8 + 11: small mental sum (cf. 24 + 7)",
    ("train", 2103, 1): "1600 / 80: reduces to 160 / 8, round result",
    ("train", 3982, 1): "240 x 3: reduces to 24 x 3, mental",
    ("train", 2923, 1): "6 x 15: recalled multiple of 15 (cf. 15 x 3)",
    ("train", 5179, 1): "160 x 8: reduces to 16 x 8, mental (cf. 16 x 6)",
    ("train", 3747, 1): "16 x 3: mental (cf. train[4402] 16 x 3)",
    ("train", 6166, 1): "2/9 of 2700: 2700 / 9 = 300, round mental result (cf. pilot verdict on 602)",
    ("train", 781, 1): "3 x 85: mental (cf. 4 x 85)",
    ("train", 6754, 1): "28 + 8: small mental sum (cf. 27 + 4)",
    ("train", 3268, 1): "18 - 5 - 2: small mental subtraction",
}

# (split, source_index, calc_id, corrupted_result) -> (pass, reason)
SEMANTIC_CHECK = {
    # ---- review round 1 (2026-10-11)
    ("train", 2728, 1, 167): (True, "167 instead of 168 cattle (340 - 172, with borrows) is plausible; still fewer than 340"),
    ("train", 4520, 1, 41): (True, "41 instead of 42 pencils (126 / 3) is a plausible division slip (cf. pilot verdict 126 / 3 = 44)"),
    ("train", 4887, 1, 80): (True, "80 instead of 90 stickers (135 - 45, with a borrow) is a tens slip; 2/5 of 80 stays an integer"),
    ("train", 5294, 1, 29): (True, "29 instead of 31 red flowers (17 + 14, with a carry) is plausible; red still exceeds white"),
    ("train", 5149, 1, 118): (True, "118 instead of 119 fish sold (four-term sum with carries) is plausible; 199 remain"),
    ("train", 5036, 1, 15): (True, "15 instead of 14 lollipops (42 - 28, with a borrow) is plausible; 11 for Lou is feasible"),
    ("train", 4402, 2, 98): (True, "98 instead of 96 cookies (32 + 16 + 48, with carries) is a plausible addition slip"),
    ("train", 3139, 1, 16): (True, "16 instead of 17 white beads (51 / 3) is a plausible division slip; still fewer than 51"),
    ("train", 3692, 1, 50): (False, "48 -> 50 lands on a round number and reads as rounding (cf. 20% of 245 = 50)"),
    ("train", 2890, 1, 32): (True, "$32 instead of $42 (126 / 3) is a tens slip in the quotient; $94 left is feasible"),
    ("train", 2610, 1, 25): (True, "25 instead of 23 dozen (276 / 12) is a plausible long-division slip"),
    ("train", 429, 1, 1106): (True, "1106 instead of 1104 books (60% of 1840) is a plausible percentage slip; still fewer than 1840"),
    ("train", 4265, 2, 34): (True, "34 instead of 33 coins (17 + 16, with a carry) is a plausible addition slip"),
    ("train", 1066, 1, 70): (False, "72 -> 70 lands on a round number and reads as rounding (cf. 4% of 475 = 20)"),
    ("train", 2746, 1, 158): (True, "158 instead of 159 pounds (184 - 25, with a borrow) is a plausible subtraction slip"),
    ("train", 1546, 1, 67): (True, "67 instead of 65 minutes (195 / 3) is a plausible division slip (cf. pilot verdict on 66)"),
    ("train", 7385, 1, 160): (False, "162 -> 160 lands on a round number and reads as rounding"),
    ("train", 3841, 1, 122): (True, "$122 instead of $132 (4 x 33, with a carry) is a tens slip (cf. 4 x 23); change stays positive"),
    ("train", 6427, 1, 11): (True, "11 instead of 9 deliberation days (144 / 16) is a plausible division slip (cf. pilot verdict on 10)"),
    ("train", 6370, 1, 6710): (True, "$6710 instead of $6720 (60 x 112) is a tens slip that keeps the trailing 0"),
    ("train", 2393, 1, 225): (True, "225 instead of 215 pounds (450 - 235) is the classic forgotten-borrow slip; Patty stays heavier"),
    # ---- review round 2 (2026-10-11)
    ("train", 3692, 1, 47): (False, "the propagated value 1 makes the corrupted text ungrammatical ('1 students'), a surface cue "
                                    "absent from the gold trace"),
    ("train", 1066, 1, 71): (True, "71 instead of 72 oranges (45 + 27, with a carry) is a plausible addition slip"),
    ("train", 7385, 1, 152): (True, "152 instead of 162 ounces (27 x 6, with a carry) is a tens slip and stays even"),
}
