"""Crash-safe, resumable inference runner (used by scripts/04_smoke_test.py and scripts/05_run_inference.py).

Per request, in the frozen execution order:
  1. the globally unique request key is checked against raw_outputs.jsonl: a completed request is NEVER regenerated
  2. the prompt's SHA-256 is re-checked against the frozen request file
  3. one stateless call: backend.generate(prompt) (no history, no system message, no item metadata)
  4. the response row is appended to raw_outputs.jsonl, flushed and fsync'ed; state.json is updated atomically
  5. every `checkpoint_every` completed rows a checkpoint ZIP is written atomically
Retries: ONLY transport errors (backends.TransportError: timeout / connection / 429 / 5xx) are retried, up to
`transport_retry_attempts`. Wrong, malformed, empty, refused or truncated outputs are observed outcomes: stored once,
never retried. Any other exception (CUDA OOM, crash) stops the run with a runtime_failure record; rerunning the same
command resumes exactly where it stopped.
A run directory is bound to one run manifest (inputs, order, solver identity). Resuming with anything different stops.
"""
import json
import time
import traceback
from pathlib import Path

from . import common as C
from . import frozen_pilot as fp
from .persistence import RunStore, read_jsonl_tolerant

IDENTITY_FIELDS = ["run_id", "mode", "test_only", "backend", "solver_tag", "model", "model_revision",
                   "solver_config_sha256", "requests_sha256", "execution_order_sha256", "items_sha256",
                   "critics_sha256", "stage_a_config_sha256", "planned_keys_sha256", "max_new_tokens",
                   "enable_thinking", "decoding"]


def load_frozen_inputs():
    reqs = C.read_jsonl(C.REQUESTS_FILE)
    order = C.read_json(C.ORDER_FILE)
    frozen = C.read_json(C.FROZEN_HASHES)["files"]
    for relpath, sha in frozen.items():
        got = C.sha256_file(C.STAGE_ROOT / relpath)
        if got != sha:
            raise SystemExit(f"STOP: frozen file {relpath} changed (sha256 {got} != {sha})")
    by_key = {r["request_key"]: r for r in reqs}
    if len(by_key) != len(reqs):
        raise SystemExit("STOP: duplicate request keys in the frozen request file")
    if [o["request_key"] for o in order["order"]] and set(o["request_key"] for o in order["order"]) != set(by_key):
        raise SystemExit("STOP: execution order and request file disagree")
    if C.sha256_text("\n".join(o["request_key"] for o in order["order"])) != order["order_sha256"]:
        raise SystemExit("STOP: execution order hash mismatch")
    return by_key, order, frozen


def smoke_selection(order, by_key, n):
    """Deterministic: the earliest request (in execution order) of each variant kind, then fill in order."""
    kinds, chosen = [], []
    for o in order["order"]:
        r = by_key[o["request_key"]]
        kind = (r["variant_family"], r["pointed_step_role"])
        if kind not in kinds:
            kinds.append(kind)
            chosen.append(o["request_key"])
    for o in order["order"]:
        if len(chosen) >= n:
            break
        if o["request_key"] not in chosen:
            chosen.append(o["request_key"])
    return chosen[:n]


def plan_keys(order, by_key, mode, n_smoke, split=None):
    if mode == "smoke":
        return smoke_selection(order, by_key, n_smoke)
    keys = [o["request_key"] for o in order["order"]]
    if split:
        keys = [k for k in keys if by_key[k]["split"] == split]
    return keys


def run_manifest(run_id, mode, test_only, backend_name, cfg, solver_cfg, solver_cfg_sha, frozen, keys):
    return {
        "run_id": run_id, "mode": mode, "test_only": test_only, "backend": backend_name,
        "solver_tag": cfg["requests"]["solver_tag"],
        "model": solver_cfg.get("model"), "model_revision": solver_cfg.get("model_revision"),
        "solver_config_sha256": solver_cfg_sha,
        "requests_sha256": frozen[C.rel(C.REQUESTS_FILE)], "execution_order_sha256": frozen[C.rel(C.ORDER_FILE)],
        "items_sha256": frozen[C.rel(C.ITEMS_FILE)], "critics_sha256": frozen[C.rel(C.CRITICS_FILE)],
        "stage_a_config_sha256": frozen[C.rel(C.CONFIG_PATH)],
        "planned_keys_sha256": C.sha256_text("\n".join(keys)), "n_planned": len(keys),
        "max_new_tokens": solver_cfg.get("max_new_tokens"), "enable_thinking": solver_cfg.get("enable_thinking"),
        "decoding": solver_cfg.get("decoding"),
        "request_protocol": "stateless; one user message; no system message; no history; batch size 1",
        "retry_policy": "transport errors only; model outputs are never retried",
        "dataset_validation_status": C.DATASET_VALIDATION_STATUS,
        "created": C.now(),
    }


def check_or_write_manifest(run_dir, manifest):
    p = Path(run_dir) / "run_manifest.json"
    if p.exists():
        old = json.loads(p.read_text(encoding="utf-8"))
        diff = [f for f in IDENTITY_FIELDS if old.get(f) != manifest.get(f)]
        if diff:
            raise SystemExit(f"STOP: {run_dir} belongs to a different run (differs in {diff}); refusing to resume "
                             "into it. Use a new --run-id.")
        return False
    C.write_json(p, manifest)
    return True


def import_previous(run_dir, source, manifest, by_key):
    """Seed a FRESH run directory with rows completed in an earlier session (Kaggle: attach the previous version's
    output). `source` is a run directory or a checkpoint/final ZIP containing raw_outputs.jsonl + run_manifest.json.
    Rows are accepted only if the earlier manifest has the same identity and every row matches the frozen prompt."""
    import zipfile
    run_dir, source = Path(run_dir), Path(source)
    if (run_dir / "raw_outputs.jsonl").exists():
        raise SystemExit("STOP: --resume-from needs an empty run directory (this one already has outputs)")
    if source.is_dir():
        raw_bytes = (source / "raw_outputs.jsonl").read_bytes()
        old_man = json.loads((source / "run_manifest.json").read_text(encoding="utf-8"))
    else:
        with zipfile.ZipFile(source) as z:
            names = z.namelist()
            raw_name = next(n for n in names if n.endswith("raw_outputs.jsonl"))
            man_name = next(n for n in names if n.endswith("run_manifest.json"))
            raw_bytes, old_man = z.read(raw_name), json.loads(z.read(man_name))
    diff = [f for f in IDENTITY_FIELDS if old_man.get(f) != manifest.get(f)]
    if diff:
        raise SystemExit(f"STOP: previous outputs come from a different run (differs in {diff})")
    tmp = run_dir / "_import.jsonl"
    run_dir.mkdir(parents=True, exist_ok=True)
    tmp.write_bytes(raw_bytes)
    rows, note = read_jsonl_tolerant(tmp)
    tmp.unlink()
    seen = set()
    for r in rows:
        k = r["request_key"]
        if k in seen or k not in by_key or r["prompt_sha256"] != by_key[k]["prompt_sha256"] \
                or C.sha256_text(r["prompt"]) != r["prompt_sha256"]:
            raise SystemExit(f"STOP: imported row {k} is duplicated, unknown or has a different prompt")
        seen.add(k)
    with open(run_dir / "raw_outputs.jsonl", "w", encoding="utf-8", newline="\n") as fh:
        for r in rows:
            fh.write(json.dumps(r, ensure_ascii=False) + "\n")
    return len(rows), note


def execute(run_dir, by_key, order, keys, backend, manifest, settings, log=print, force_unlock=False,
            limit=None):
    TransportError = fp.module("backends").TransportError
    store = RunStore(run_dir, settings["checkpoint_every"])
    store.acquire(force_unlock)
    run_dir = Path(run_dir)
    logf = run_dir / "run_log.txt"

    def say(msg):
        line = f"{C.now()}  {msg}"
        with open(logf, "a", encoding="utf-8", newline="\n") as fh:
            fh.write(line + "\n")
        log(line)
    try:
        check_or_write_manifest(run_dir, manifest)
        rows = store.completed_rows()
        if store.note:
            say("NOTE: " + store.note)
        done = {r["request_key"] for r in rows}
        unknown = done - set(keys)
        if unknown:
            raise SystemExit(f"STOP: raw_outputs.jsonl has rows outside this run's plan: {sorted(unknown)[:5]}")
        run_index = {o["request_key"]: o["run_index"] for o in order["order"]}
        todo = [k for k in keys if k not in done]
        if limit is not None:
            todo = todo[:limit]          # debugging only: the run's plan (and identity) is unchanged
        say(f"{'RESUMING' if done else 'STARTING'} run {manifest['run_id']} ({manifest['mode']}, backend "
            f"{manifest['backend']}{', TEST ONLY' if manifest['test_only'] else ''}): {len(done)}/{len(keys)} "
            f"already completed, {len(todo)} to go. Completed requests are never regenerated.")
        stats = {"generated": 0, "transport_failures": 0, "skipped_after_transport_failures": 0}
        for k in todo:
            req = by_key[k]
            if C.sha256_text(req["prompt"]) != req["prompt_sha256"]:
                raise SystemExit(f"STOP: prompt hash mismatch for {k}")
            attempt = 0
            while True:
                attempt += 1
                t0 = time.perf_counter()
                try:
                    res = backend.generate(req["prompt"])
                except TransportError as e:
                    stats["transport_failures"] += 1
                    store.transport_failure({"timestamp": C.now(), "request_key": k, "attempt": attempt,
                                             "error": f"{type(e).__name__}: {e}"})
                    if attempt >= settings["transport_retry_attempts"]:
                        stats["skipped_after_transport_failures"] += 1
                        say(f"transport failure x{attempt} on {k}; left incomplete (rerun to resume)")
                        break
                    time.sleep(settings["transport_retry_backoff_seconds"])
                    continue
                latency = time.perf_counter() - t0
                row = {"run_id": manifest["run_id"], "run_index": run_index[k], "request_key": k,
                       "item_id": req["item_id"], "split": req["split"], "variant": req["variant"],
                       "pointed_step": req["pointed_step"], "pointed_step_role": req["pointed_step_role"],
                       "gold_answer": req["gold_answer"], "corrupted_answer": req["corrupted_answer"],
                       "prompt": req["prompt"], "prompt_sha256": req["prompt_sha256"],
                       "raw_response": res.text,
                       "model_metadata": {"response": res.metadata, "backend": manifest["backend"],
                                          "model": manifest["model"], "model_revision": manifest["model_revision"],
                                          "max_new_tokens": manifest["max_new_tokens"],
                                          "enable_thinking": manifest["enable_thinking"]},
                       "attempt_count": attempt, "latency_seconds": round(latency, 3), "timestamp": C.now(),
                       "solver_tag": manifest["solver_tag"], "test_only": manifest["test_only"]}
                store.append(row, done)                 # durable (fsync) before anything else
                stats["generated"] += 1
                try:                                    # derived files: a failure here never stops generation
                    store.write_state(len(done), len(keys), k)
                    for c in store.checkpoints_due(len(done)):
                        store.checkpoint(c)
                        say(f"CHECKPOINT {c}/{len(keys)} written")
                except OSError as e:
                    stats["derived_file_warnings"] = stats.get("derived_file_warnings", 0) + 1
                    say(f"WARNING: state/checkpoint write failed ({type(e).__name__}: {e}); generation continues, "
                        "raw_outputs.jsonl is fsync'ed per request; the missing checkpoint is retried next time")
                if stats["generated"] % 10 == 0 or len(done) == len(keys):
                    say(f"[{len(done)}/{len(keys)}] completed (last latency {latency:.1f}s)")
                break
        stats["completed"] = len(done)
        stats["planned"] = len(keys)
        stats["complete"] = len(done) == len(keys)
        if stats["complete"]:
            store.checkpoint(len(done), name="checkpoint_FINAL.zip")
        say(f"pass finished: {stats}")
        return stats
    except BaseException as e:
        if not isinstance(e, SystemExit):
            n = len(store.completed_keys()) if store.raw.exists() else 0
            C.write_json(run_dir / f"runtime_failure_{int(time.time())}.json",
                         {"failed": C.now(), "error": f"{type(e).__name__}: {e}",
                          "traceback": traceback.format_exc(), "completed_rows_on_disk": n,
                          "policy": "files kept; nothing regenerated; rerun the same command to resume"})
        raise
    finally:
        store.release()
