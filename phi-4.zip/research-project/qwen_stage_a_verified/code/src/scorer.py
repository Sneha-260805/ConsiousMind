"""Scoring contract (fixed before any Stage-A model output exists; same rule as the pilot's frozen scorer).

For every completed response, the numeric parse (parser.py) yields exactly one of four mutually exclusive outcomes:
    repair                numeric answer == gold answer                         (primary: repair success)
    corrupted_retention   numeric answer == the trace's corrupted final answer
    misdirected           numeric answer parsed, but neither gold nor corrupted (the answer CHANGED to another wrong value)
    parse_failure         no unambiguous numeric answer (missing / non_numeric / ambiguous)
Malformed, out-of-schema, refused, empty or truncated-without-valid-answer responses are observed outcomes: they are
scored (repair = False) and never regenerated. Diagnostics: strict_format_compliant, truncated (generation hit
max_new_tokens), truncated_without_valid_answer.
Comparison is numeric (Decimal), as in the pilot's score_pilot.equal.
"""
from decimal import Decimal

from . import parser

SCORER_VERSION = "stage_a_scorer_v1 (pilot rule: repair = numeric_parsed_answer == gold)"
OUTCOMES = ["repair", "corrupted_retention", "misdirected", "parse_failure"]


def equal(parsed, target):
    return parsed is not None and Decimal(parsed) == Decimal(str(target))


def classify(numeric_status, numeric_answer, gold, corrupted):
    if numeric_status != "ok":
        return "parse_failure"
    if equal(numeric_answer, gold):
        return "repair"
    if equal(numeric_answer, corrupted):
        return "corrupted_retention"
    return "misdirected"


def score_raw_row(raw):
    p = parser.parse(raw["raw_response"])
    outcome = classify(p["numeric_parse_status"], p["numeric_parsed_answer"], raw["gold_answer"],
                       raw["corrupted_answer"])
    meta = (raw.get("model_metadata") or {}).get("response") or {}
    truncated = meta.get("finish_reason") == "length"
    return {
        "request_key": raw["request_key"], "item_id": raw["item_id"], "split": raw["split"],
        "variant": raw["variant"], "gold_answer": raw["gold_answer"], "corrupted_answer": raw["corrupted_answer"],
        "test_only": raw.get("test_only", False),
        "outcome": outcome,
        "repair": outcome == "repair",
        "corrupted_retention": outcome == "corrupted_retention",
        "misdirected": outcome == "misdirected",
        "parse_failure": outcome == "parse_failure",
        "strict_format_compliant": p["strict_format_compliant"],
        "truncated": truncated,
        "truncated_without_valid_answer": truncated and outcome == "parse_failure",
        "new_tokens": meta.get("new_tokens"),
        "scorer_version": SCORER_VERSION,
        **{k: p[k] for k in ("parser_version", "numeric_parse_status", "numeric_parsed_answer",
                             "numeric_parse_source", "strict_parse_status", "strict_parsed_answer")},
    }


def score_rows(raw_rows):
    return [score_raw_row(r) for r in sorted(raw_rows, key=lambda r: r["run_index"])]


def score_run(run_dir):
    """Parse + score every completed row of a run; write scored_outputs.jsonl and run_diagnostics.json.
    Integrity information only: no condition comparison is computed or printed here."""
    import json
    import re
    import statistics
    from collections import Counter
    from pathlib import Path

    from .common import sha256_text, write_json, write_jsonl
    from .persistence import read_jsonl_tolerant
    run_dir = Path(run_dir)
    raw, note = read_jsonl_tolerant(run_dir / "raw_outputs.jsonl", repair=False)
    scored = score_rows(raw)
    write_jsonl(run_dir / "scored_outputs.jsonl", scored)
    man = json.loads((run_dir / "run_manifest.json").read_text(encoding="utf-8"))
    tf = run_dir / "transport_failures.jsonl"
    toks = [s["new_tokens"] for s in scored if s["new_tokens"] is not None]
    lat = [r["latency_seconds"] for r in raw]
    diag = {
        "LABEL": "INTEGRITY CHECK ONLY - no repair rates or policy comparisons",
        "TEST_ONLY": man["test_only"],
        "run_id": man["run_id"], "mode": man["mode"], "backend": man["backend"],
        "planned": man["n_planned"], "completed": len(raw),
        "duplicate_keys": len(raw) - len({r["request_key"] for r in raw}),
        "raw_file_note": note,
        "transport_failure_records": len(tf.read_text(encoding="utf-8").splitlines()) if tf.exists() else 0,
        "retries_used": sum(r["attempt_count"] - 1 for r in raw),
        "completed_by_variant_family": dict(Counter(r["variant"].split("@")[0] for r in raw)),
        "numeric_parse_status": dict(Counter(s["numeric_parse_status"] for s in scored)),
        "numeric_parse_source": dict(Counter(str(s["numeric_parse_source"]) for s in scored)),
        "strict_format_compliant": sum(s["strict_format_compliant"] for s in scored),
        "truncated_at_max_new_tokens": [s["request_key"] for s in scored if s["truncated"]],
        "truncated_without_valid_answer": [s["request_key"] for s in scored if s["truncated_without_valid_answer"]],
        "visible_think_tags": [r["request_key"] for r in raw if re.search(r"</?think>", r["raw_response"])
                               or (r["model_metadata"]["response"] or {}).get("think_tag_in_output")],
        "prompts_match_frozen_sha": all(r["prompt_sha256"] == sha256_text(r["prompt"]) for r in raw),
        "generated_tokens_mean": round(statistics.mean(toks), 1) if toks else None,
        "generated_tokens_max": max(toks) if toks else None,
        "latency_mean_s": round(statistics.mean(lat), 2) if lat else None,
        "scorer_version": SCORER_VERSION, "parser_version": scored[0]["parser_version"] if scored else None,
    }
    write_json(run_dir / "run_diagnostics.json", diag)
    return diag, scored
