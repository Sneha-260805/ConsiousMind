"""Simulated critics with KNOWN reliability (Stage A has no real critic).

For target reliability r and concentration c (configs/stage_a.json):
    p_i  ~ Beta(r*c, (1-r)*c)          item-level confidence, E[p_i] = r
    correct_i ~ Bernoulli(p_i)         so p_i is calibrated by construction
    predicted_step = true_error_step if correct_i else the item's prevalidated valid_false_step

Each (regime, item) draw uses its own RNG seeded by a recorded string, so adding/removing an item never changes
another item's draw. The realisation is generated ONCE and frozen (data/generated/simulated_critics.json); every
feedback policy reads the same record, so predictions are never regenerated per policy.

constant_confidence_control (no extra inference: it reuses the same predictions):
    permuted  p values permuted across items within each split and regime (same marginal distribution, no
              item-level discrimination in expectation)
    constant  p = r for every item (no item-level variation at all)
Used to test whether gating only helps when confidence is informative.
"""
import random
from collections import Counter

REGIME_FMT = "r{:.2f}"


def regime_name(r):
    return REGIME_FMT.format(r)


def seed_string(base_seed, version, r, item_id):
    return f"{base_seed}|{version}|{r:.2f}|{item_id}"


def draw(base_seed, version, r, concentration, item_id):
    s = seed_string(base_seed, version, r, item_id)
    rng = random.Random(s)
    p = rng.betavariate(r * concentration, (1 - r) * concentration)
    u = rng.random()
    return s, p, u, u < p


def simulate(items, split_assignment, cfg):
    sc = cfg["simulated_critic"]
    version, base, conc = sc["critic_version"], sc["base_seed"], sc["concentration"]
    records, summary = [], {}
    for r in sc["target_reliabilities"]:
        reg = regime_name(r)
        regime_recs = []
        for it in sorted(items, key=lambda x: x["item_id"]):
            s, p, u, correct = draw(base, version, r, conc, it["item_id"])
            regime_recs.append({
                "regime": reg, "target_reliability": r, "critic_version": version,
                "item_id": it["item_id"], "split": split_assignment[it["item_id"]],
                "seed": s, "p": round(p, 6), "u": round(u, 6), "critic_correct": bool(correct),
                "true_step": it["true_error_step"], "false_step_used": it["valid_false_step"],
                "predicted_step": it["true_error_step"] if correct else it["valid_false_step"],
            })
        # constant-confidence controls
        prng = random.Random(f"{sc['constant_confidence_control']['permutation_seed']}|{version}|{reg}")
        for split in sorted({x["split"] for x in regime_recs}):
            grp = [x for x in regime_recs if x["split"] == split]
            ps = [x["p"] for x in grp]
            prng.shuffle(ps)
            for x, pp in zip(grp, ps):
                x["control_p_permuted"] = pp
        for x in regime_recs:
            x["control_p_constant"] = r
        records += regime_recs
        summary[reg] = regime_summary(regime_recs, r)
    return {
        "critic_version": version,
        "model": "p ~ Beta(r*c, (1-r)*c); correct ~ Bernoulli(p); wrong prediction = valid_false_step",
        "concentration": conc,
        "base_seed": base,
        "target_reliabilities": sc["target_reliabilities"],
        "constant_confidence_control": sc["constant_confidence_control"],
        "summary": summary,
        "records": records,
    }


def regime_summary(recs, r):
    def acc(rs):
        return round(sum(x["critic_correct"] for x in rs) / len(rs), 4) if rs else None

    def mean_p(rs):
        return round(sum(x["p"] for x in rs) / len(rs), 4) if rs else None
    out = {"target_reliability": r, "n": len(recs), "realized_accuracy": acc(recs), "mean_p": mean_p(recs)}
    for split in sorted({x["split"] for x in recs}):
        rs = [x for x in recs if x["split"] == split]
        out[split] = {"n": len(rs), "realized_accuracy": acc(rs), "mean_p": mean_p(rs)}
    out["predicted_step_counts"] = dict(sorted(Counter(x["predicted_step"] for x in recs).items()))
    return out


def realization_seed(cfg, phase, regime, k):
    """Seed of the k-th independent critic realization for one phase. 'tune' and 'eval' live in separate
    namespaces, so threshold selection never sees an eval draw and eval never re-uses a tune draw."""
    sc, mr = cfg["simulated_critic"], cfg["multi_realization"]
    assert phase in ("tune", "eval")
    return f"{sc['base_seed']}|{sc['critic_version']}|{mr['seed_namespace']}|{phase}|{regime}|k{k:05d}"


def draw_realization(items, r, concentration, seed):
    """One independent simulated critic over `items` (sorted by item_id): same model as the frozen critic
    (p ~ Beta(r c, (1-r) c), correct ~ Bernoulli(p), wrong -> valid_false_step), plus both confidence controls.
    Predictions are always the true step or the item's false step, so every policy maps onto existing prompts."""
    rng = random.Random(seed)
    out = {}
    for it in sorted(items, key=lambda x: x["item_id"]):
        p = rng.betavariate(r * concentration, (1 - r) * concentration)
        correct = rng.random() < p
        out[it["item_id"]] = {"p": p, "critic_correct": correct,
                              "predicted_step": it["true_error_step"] if correct else it["valid_false_step"],
                              "control_p_constant": r}
    ids = sorted(out)
    ps = [out[i]["p"] for i in ids]
    rng.shuffle(ps)
    for i, pp in zip(ids, ps):
        out[i]["control_p_permuted"] = pp
    return out


def index(critics_doc):
    """{(regime, item_id): record}"""
    return {(x["regime"], x["item_id"]): x for x in critics_doc["records"]}
