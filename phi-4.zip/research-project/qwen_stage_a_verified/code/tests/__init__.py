"""Stage-A tests."""
