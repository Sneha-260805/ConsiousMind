"""Run the full local test suite; on success record tests/LAST_PASS.json (code fingerprint), which
scripts/08_build_kaggle_bundle.py requires before it will build a GPU bundle.

    python tests/run_all.py
"""
import sys
import unittest
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from src import common as C  # noqa: E402

if __name__ == "__main__":
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"), top_level_dir=str(ROOT))
    res = unittest.TextTestRunner(verbosity=2).run(suite)
    ok = res.wasSuccessful()
    if ok:
        C.write_json(ROOT / "tests" / "LAST_PASS.json",
                     {"passed": C.now(), "tests_run": res.testsRun, "skipped": len(res.skipped),
                      "code_fingerprint": C.code_fingerprint(), "python": sys.version.split()[0]})
    print("\nALL TESTS PASSED" if ok else "\nTESTS FAILED")
    sys.exit(0 if ok else 1)
