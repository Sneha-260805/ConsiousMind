"""Stage-A local validation suite (standard library unittest; no model is loaded).

    python tests/run_all.py                      # runs everything, records tests/LAST_PASS.json on success
    python -m unittest discover -s tests -t .    # same tests, no record
Dataset tests that need the full pilot builder scripts / raw GSM8K are skipped where those are not bundled (Kaggle).
"""
import hashlib
import json
import os
import re
import sys
import tempfile
import unittest
import zipfile
from fractions import Fraction
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src import analysis as A  # noqa: E402
from src import common as C  # noqa: E402
from src import feedback_policies as fpol  # noqa: E402
from src import frozen_pilot as fp  # noqa: E402
from src import prompt_builder as pb  # noqa: E402
from src import request_builder as rb  # noqa: E402
from src import runner as R  # noqa: E402
from src import scorer  # noqa: E402
from src import simulated_critic as sc  # noqa: E402
from src.mock_solver import MockSolver, SimulatedCrash  # noqa: E402
from src.persistence import DuplicateRequestError, RunStore, read_jsonl_tolerant  # noqa: E402

CFG = C.load_config()
ITEMS_DOC = C.read_json(C.ITEMS_FILE)
ITEMS = ITEMS_DOC["items"]
BY_ID = {it["item_id"]: it for it in ITEMS}
SPLIT = C.read_json(C.SPLIT_FILE)
CRITICS = C.read_json(C.CRITICS_FILE)
PHYSICAL = C.read_jsonl(C.REQUESTS_FILE)
LOGICAL = C.read_jsonl(C.GRID_FILE)
ORDER = C.read_json(C.ORDER_FILE)


def _pilot_full():
    try:
        fp.verify("scripts/build_m3_pilot40.py")
        fp.verify("data/pilot/m3_pilot_40.json")
        return True
    except fp.PilotLinkError:
        return False


PILOT_FULL = _pilot_full()
ANN = re.compile(r"<<([^=<>]+)=([^<>]+)>>")


def ev(expr):
    """Independent exact evaluator for <<expr=result>> annotations (digits, + - * / and parentheses only)."""
    e = expr.replace("x", "*").replace("X", "*").replace("×", "*").replace("÷", "/")
    toks = re.findall(r"\d+\.?\d*|\.\d+|[-+*/()]", e)
    assert "".join(toks) == e.replace(" ", ""), expr
    return eval("".join(f"Fraction('{t}')" if t[0].isdigit() or t[0] == "." else t for t in toks))


# =============================================================== dataset
class TestDataset(unittest.TestCase):
    @unittest.skipUnless(PILOT_FULL, "pilot item file not bundled here")
    def test_no_overlap_with_previous_pilot(self):
        pilot = C.read_json(fp.path("data/pilot/m3_pilot_40.json"))["items"]
        self.assertEqual(len(pilot), 40)
        pid = {(re.fullmatch(r"gsm8k/(\w+)\.jsonl", p["source"]).group(1), p["source_index"]) for p in pilot}
        pq = {re.sub(r"\s+", " ", p["question"]).strip().lower() for p in pilot}
        for it in ITEMS:
            self.assertNotIn((it["source_split"], it["source_index"]), pid)
            self.assertNotIn(re.sub(r"\s+", " ", it["question"]).strip().lower(), pq)

    def test_unique_ids_and_problems(self):
        self.assertEqual(len({it["item_id"] for it in ITEMS}), len(ITEMS))
        self.assertEqual(len({it["source_problem_id"] for it in ITEMS}), len(ITEMS))
        self.assertEqual(ITEMS_DOC["n_items"], len(ITEMS))

    def test_exactly_one_first_causal_m3_error(self):
        for it in ITEMS:
            t = it["true_error_step"]
            gold, cor = it["internal"]["gold_steps_annotated"], it["internal"]["corrupted_steps_annotated"]
            self.assertEqual(gold[:t - 1], cor[:t - 1], f"{it['item_id']}: a step before the error changed")
            wrong_steps = []
            for n, line in enumerate(cor, 1):
                for expr, res in ANN.findall(line):
                    if ev(expr) != Fraction(res.replace(",", "")):
                        wrong_steps.append(n)
            self.assertEqual(wrong_steps, [t], f"{it['item_id']}: arithmetic errors at {wrong_steps}")
            g_ann, c_ann = ANN.findall(gold[t - 1]), ANN.findall(cor[t - 1])
            self.assertEqual([e for e, _ in g_ann], [e for e, _ in c_ann], "operands/operator changed")
            self.assertNotEqual([r for _, r in g_ann], [r for _, r in c_ann])
            self.assertEqual(it["error_type"], "M3")
            self.assertTrue(it["validation"]["automatic_m3_validation"]["ALL_PASS"])

    def test_corrupted_answer_differs_from_gold(self):
        for it in ITEMS:
            self.assertNotEqual(Fraction(str(it["corrupted_answer"])), Fraction(str(it["gold_answer"])))

    def test_true_step_valid(self):
        for it in ITEMS:
            t = it["true_error_step"]
            self.assertTrue(2 <= t <= it["n_steps"])
            self.assertNotEqual(it["correct_steps"][t - 1], it["corrupted_steps"][t - 1])
            self.assertEqual(it["correct_steps"][:t - 1], it["corrupted_steps"][:t - 1])

    def test_false_step_genuinely_correct(self):
        for it in ITEMS:
            f, t = it["valid_false_step"], it["true_error_step"]
            self.assertTrue(1 <= f < t)
            g, c = it["internal"]["gold_steps_annotated"][f - 1], it["internal"]["corrupted_steps_annotated"][f - 1]
            self.assertEqual(g, c)
            anns = ANN.findall(c)
            self.assertTrue(anns, f"{it['item_id']}: false step has no calculation")
            for expr, res in anns:
                self.assertEqual(ev(expr), Fraction(res.replace(",", "")))
            self.assertTrue(it["false_step_checks"]["ALL_PASS"])
            self.assertIn(f, it["valid_false_step_candidates"])

    def test_split_by_problem_and_hashed(self):
        a = SPLIT["assignment"]
        self.assertEqual(set(a), set(BY_ID))
        tune = {BY_ID[i]["source_problem_id"] for i, s in a.items() if s == "stage_a_tune"}
        evs = {BY_ID[i]["source_problem_id"] for i, s in a.items() if s == "stage_a_eval"}
        self.assertFalse(tune & evs)
        self.assertLessEqual(abs(len(tune) - len(evs)), 1)
        self.assertEqual(SPLIT["items_file_sha256"], C.sha256_file(C.ITEMS_FILE))

    def test_split_deterministic(self):
        from src.dataset_builder import make_split
        self.assertEqual(make_split(ITEMS, CFG)["assignment"], SPLIT["assignment"])

    def test_student_text_has_no_annotations_or_labels(self):
        for it in ITEMS:
            for s in it["corrupted_steps"] + [it["question"]]:
                self.assertNotIn("<<", s)
                self.assertNotIn("####", s)


# =============================================================== simulated critic
class TestSimulatedCritic(unittest.TestCase):
    def test_reproducible(self):
        a = sc.simulate(ITEMS, SPLIT["assignment"], CFG)
        b = sc.simulate(ITEMS, SPLIT["assignment"], CFG)
        self.assertEqual(a, b)

    def test_frozen_file_matches_regeneration(self):
        made_with = C.read_json(C.CRITIC_MANIFEST).get("generated_with_python")
        here = "%d.%d.%d" % sys.version_info[:3]
        if made_with != here:
            self.skipTest(f"frozen critics were generated with Python {made_with}; this is {here}")
        a = sc.simulate(ITEMS, SPLIT["assignment"], CFG)
        self.assertEqual(a["records"], CRITICS["records"])

    def test_prediction_rule_and_records(self):
        for x in CRITICS["records"]:
            it = BY_ID[x["item_id"]]
            self.assertEqual(x["predicted_step"], it["true_error_step"] if x["critic_correct"] else it["valid_false_step"])
            self.assertTrue(0 < x["p"] < 1)
            self.assertEqual(x["critic_correct"], x["u"] < x["p"])
            self.assertEqual(x["control_p_constant"], x["target_reliability"])
        for reg, s in CRITICS["summary"].items():
            recs = [x for x in CRITICS["records"] if x["regime"] == reg]
            self.assertAlmostEqual(s["realized_accuracy"], sum(x["critic_correct"] for x in recs) / len(recs), 4)

    def test_permuted_control_keeps_p_distribution_within_split(self):
        for reg in {x["regime"] for x in CRITICS["records"]}:
            for split in ("stage_a_tune", "stage_a_eval"):
                recs = [x for x in CRITICS["records"] if x["regime"] == reg and x["split"] == split]
                self.assertEqual(sorted(x["p"] for x in recs), sorted(x["control_p_permuted"] for x in recs))

    def test_critic_prediction_reused_across_policies(self):
        cells = {}
        for r in LOGICAL:
            cells.setdefault((r["item_id"], r["regime"]), []).append(r)
        for (iid, reg), rows in cells.items():
            self.assertEqual(len({(r["p"], r["predicted_step"], r["critic_correct"]) for r in rows}), 1)
            pred = rows[0]["predicted_step"]
            al = next(r for r in rows if r["policy"] == "ALWAYS_LOCATION")
            ga = next(r for r in rows if r["policy"] == "RELIABILITY_GATED")
            self.assertTrue(al["physical_key"].startswith(f"{iid}|LOC@{pred}|"))
            self.assertTrue(ga["gated_route_candidates"]["location"].startswith(f"{iid}|LOC@{pred}|"))
            self.assertTrue(ga["gated_route_candidates"]["attention"].startswith(f"{iid}|ATTN@{pred}|"))
            orc = next(r for r in rows if r["policy"] == "ORACLE_LOCATION")
            self.assertTrue(orc["physical_key"].startswith(f"{iid}|LOC@{BY_ID[iid]['true_error_step']}|"))


# =============================================================== policies and prompts
class TestPoliciesAndPrompts(unittest.TestCase):
    def test_gate_boundaries(self):
        self.assertEqual(fpol.gate_route(0.80, 0.5, 0.8), "location")      # p == tau_high -> specific location
        self.assertEqual(fpol.gate_route(0.7999999, 0.5, 0.8), "attention")
        self.assertEqual(fpol.gate_route(0.50, 0.5, 0.8), "attention")     # p == tau_low -> neutral attention
        self.assertEqual(fpol.gate_route(0.4999999, 0.5, 0.8), "verify")
        self.assertEqual(fpol.gate_route(1.0, 0.5, 0.8), "location")
        self.assertEqual(fpol.gate_route(0.0, 0.5, 0.8), "verify")
        with self.assertRaises(ValueError):
            fpol.gate_route(0.6, 0.8, 0.8)

    def test_policy_routing(self):
        it = ITEMS[0]
        cr = {"p": 0.65, "predicted_step": it["valid_false_step"]}
        self.assertEqual(fpol.route("L0", it), ("none", "L0"))
        self.assertEqual(fpol.route("V", it), ("verify", "V"))
        self.assertEqual(fpol.route("ALWAYS_LOCATION", it, cr), ("location", f"LOC@{it['valid_false_step']}"))
        self.assertEqual(fpol.route("ORACLE_LOCATION", it, cr), ("location", f"LOC@{it['true_error_step']}"))
        self.assertEqual(fpol.route("RELIABILITY_GATED", it, cr, (0.5, 0.8)),
                         ("attention", f"ATTN@{it['valid_false_step']}"))
        self.assertEqual(fpol.route("RELIABILITY_GATED", it, cr, (0.7, 0.8)), ("verify", "V"))
        self.assertEqual(fpol.route("ANSWER_GIVEN_REFERENCE", it), ("answer", "ANSWER"))
        self.assertNotEqual(fpol.feedback_text("ANSWER", it), fpol.feedback_text(f"LOC@{it['true_error_step']}", it))

    def test_feedback_wording(self):
        it = ITEMS[0]
        self.assertEqual(fpol.feedback_text("V", it), "The final answer in the proposed solution is wrong.")
        self.assertEqual(fpol.feedback_text("LOC@3", it),
                         "The final answer in the proposed solution is wrong.\nThe first mistake is in Step 3.")
        self.assertEqual(fpol.feedback_text("ATTN@2", it),
                         "The final answer in the proposed solution is wrong.\nPay special attention to Step 2.")
        self.assertEqual(fpol.feedback_text("GENERIC", it),
                         "Review the proposed solution carefully before giving your final answer.")

    def test_l0_has_no_verification_leakage(self):
        for r in PHYSICAL:
            if r["variant"] != "L0":
                continue
            rest = r["prompt"].replace(BY_ID[r["item_id"]]["question"], "", 1)
            self.assertEqual(pb.find_terms(rest, pb.L0_TERMS), [], r["request_key"])
            self.assertNotIn(fpol.VERIFY, r["prompt"])
            self.assertTrue(r["prompt"].endswith("FINAL_ANSWER: <answer>"))

    def test_prompt_matching_and_hashes(self):
        audit = rb.audit_prompts(PHYSICAL, BY_ID)
        self.assertTrue(audit["ALL_PASS"], audit["violations"][:3] + audit["matching"]["failures"][:3])
        for r in PHYSICAL:
            self.assertEqual(C.sha256_text(r["prompt"]), r["prompt_sha256"])

    def test_matching_audit_detects_tampering(self):
        rows = [dict(r) for r in PHYSICAL if r["item_id"] == ITEMS[0]["item_id"]]
        t = ITEMS[0]["true_error_step"]
        for r in rows:
            if r["variant"] == f"LOC@{t}":
                r["prompt"] = r["prompt"].replace("carefully", "very carefully")
        by_item = {ITEMS[0]["item_id"]: {r["variant"]: r for r in rows}}
        self.assertFalse(rb.matching_audit(by_item, BY_ID)["ALL_PASS"])

    @unittest.skipUnless(PILOT_FULL, "pilot build_conditions not bundled here")
    def test_byte_identical_to_pilot_template(self):
        bc = fp.module("build_conditions")
        for r in PHYSICAL:
            it = BY_ID[r["item_id"]]
            self.assertEqual(r["prompt"], bc.build_prompt(it["question"], it["corrupted_steps"],
                                                          fpol.feedback_text(r["variant"], it)))
        self.assertEqual((bc.VERIFY, bc.LOCATE, bc.ORACLE), (fpol.VERIFY, fpol.LOCATE, fpol.ORACLE))

    def test_every_logical_cell_resolves(self):
        self.assertTrue(rb.summarize(PHYSICAL, LOGICAL)["every_logical_cell_resolves_to_a_physical_request"])
        keys = [r["request_key"] for r in PHYSICAL]
        self.assertEqual(len(keys), len(set(keys)))


# =============================================================== parser and scorer
class TestParserScorer(unittest.TestCase):
    def test_parser_behaviour(self):
        from src.parser import parse
        self.assertEqual(parse("work\nFINAL_ANSWER: 1920")["numeric_parsed_answer"], "1920")
        self.assertTrue(parse("work\nFINAL_ANSWER: 1920")["strict_format_compliant"])
        self.assertEqual(parse("FINAL_ANSWER: 5\nmore\nFINAL_ANSWER: $1,880.")["numeric_parsed_answer"], "1880")
        self.assertEqual(parse("Final_Answer: 1920 dollars")["numeric_parsed_answer"], "1920")
        self.assertEqual(parse("FINAL_ANSWER: 1920 or 1880")["numeric_parse_status"], "ambiguous")
        self.assertEqual(parse("FINAL_ANSWER: forty")["numeric_parse_status"], "non_numeric")
        fb = parse("The total is 1920.\nSo the answer is 1880")
        self.assertEqual((fb["numeric_parsed_answer"], fb["numeric_parse_source"]), ("1880", "final_line_fallback"))
        # the reasoning body is never searched for a convenient number
        self.assertEqual(parse("Clearly 1920 is right.\nI am not sure.")["numeric_parse_status"], "missing")
        self.assertEqual(parse("")["numeric_parse_status"], "missing")

    def test_outcome_classification(self):
        self.assertEqual(scorer.classify("ok", "1920", 1920, 1880), "repair")
        self.assertEqual(scorer.classify("ok", "1880.0", 1920, 1880), "corrupted_retention")
        self.assertEqual(scorer.classify("ok", "1900", 1920, 1880), "misdirected")
        self.assertEqual(scorer.classify("ambiguous", None, 1920, 1880), "parse_failure")
        self.assertEqual(scorer.classify("missing", None, 1920, 1880), "parse_failure")
        row = {"run_index": 0, "request_key": "k", "item_id": "i", "split": "s", "variant": "V", "gold_answer": 10,
               "corrupted_answer": 11, "raw_response": "...\nFINAL_ANSWER: 12",
               "model_metadata": {"response": {"finish_reason": "length", "new_tokens": 768}}}
        s = scorer.score_raw_row(row)
        self.assertTrue(s["misdirected"] and s["truncated"] and not s["truncated_without_valid_answer"])
        self.assertEqual(sum(s[o] for o in scorer.OUTCOMES), 1)


# =============================================================== persistence / runner
class _RunBase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.run_dir = Path(self.tmp.name) / "run"
        self.by_key, self.order, self.frozen = R.load_frozen_inputs()
        self.keys = [o["request_key"] for o in self.order["order"]][:23]
        sc_cfg, sha = __import__("src.solver_loader", fromlist=["solver_config"]).solver_config(CFG)
        self.manifest = R.run_manifest("t", "test", True, "mock", CFG, sc_cfg, sha, self.frozen, self.keys)
        self.settings = {**CFG["runner"], "transport_retry_backoff_seconds": 0}

    def tearDown(self):
        self.tmp.cleanup()

    def run_once(self, solver, **kw):
        return R.execute(self.run_dir, self.by_key, self.order, self.keys, solver, self.manifest, self.settings,
                         log=lambda *_: None, **kw)

    def raw(self):
        return C.read_jsonl(self.run_dir / "raw_outputs.jsonl")


class TestPersistence(_RunBase):
    def test_resume_after_crash_never_regenerates(self):
        s1 = MockSolver(PHYSICAL, crash_after_calls=7)
        with self.assertRaises(SimulatedCrash):
            self.run_once(s1)
        self.assertEqual(len(self.raw()), 7)
        self.assertTrue(list(self.run_dir.glob("runtime_failure_*.json")))
        s2 = MockSolver(PHYSICAL)
        st = self.run_once(s2)
        self.assertTrue(st["complete"])
        self.assertEqual(len(s2.calls), len(self.keys) - 7)        # completed requests were not regenerated
        keys = [r["request_key"] for r in self.raw()]
        self.assertEqual(sorted(keys), sorted(self.keys))
        self.assertEqual(len(keys), len(set(keys)))
        s3 = MockSolver(PHYSICAL)
        self.run_once(s3)
        self.assertEqual(s3.calls, [])                              # a finished run sends nothing

    def test_checkpoints_every_10(self):
        self.run_once(MockSolver(PHYSICAL))
        names = sorted(p.name for p in (self.run_dir / "checkpoints").glob("checkpoint_*.zip"))
        self.assertEqual(names, ["checkpoint_0010.zip", "checkpoint_0020.zip", "checkpoint_FINAL.zip"])
        with zipfile.ZipFile(self.run_dir / "checkpoints" / "checkpoint_0010.zip") as z:
            self.assertEqual(len(z.read("raw_outputs.jsonl").decode().splitlines()), 10)

    def test_duplicate_request_prevention(self):
        store = RunStore(self.run_dir)
        done = set()
        store.append({"request_key": "a", "x": 1}, done)
        with self.assertRaises(DuplicateRequestError):
            store.append({"request_key": "a", "x": 2}, done)
        with open(store.raw, "a", encoding="utf-8") as fh:
            fh.write(json.dumps({"request_key": "a"}) + "\n")
        with self.assertRaises(DuplicateRequestError):
            store.completed_rows()

    def test_torn_final_line_is_repaired(self):
        p = Path(self.tmp.name) / "x.jsonl"
        p.write_bytes(b'{"request_key": "a"}\n{"request_key": "b"}\n{"request_ke')
        rows, note = read_jsonl_tolerant(p)
        self.assertEqual([r["request_key"] for r in rows], ["a", "b"])
        self.assertIsNotNone(note)
        self.assertEqual(p.read_bytes(), b'{"request_key": "a"}\n{"request_key": "b"}\n')

    def test_transport_errors_retried_model_outputs_not(self):
        first = self.by_key[self.keys[0]]["prompt_sha256"]
        s = MockSolver(PHYSICAL, transport_failures={first: 2})
        self.run_once(s)
        rows = {r["request_key"]: r for r in self.raw()}
        self.assertEqual(rows[self.keys[0]]["attempt_count"], 3)
        self.assertTrue(all(r["attempt_count"] == 1 for k, r in rows.items() if k != self.keys[0]))
        self.assertEqual(len((self.run_dir / "transport_failures.jsonl").read_text().splitlines()), 2)

    def test_resume_refuses_different_run(self):
        self.run_once(MockSolver(PHYSICAL))
        self.manifest = {**self.manifest, "model_revision": "something-else"}
        with self.assertRaises(SystemExit):
            self.run_once(MockSolver(PHYSICAL))

    def test_lock_blocks_second_runner(self):
        RunStore(self.run_dir).acquire()
        with self.assertRaises(SystemExit):
            self.run_once(MockSolver(PHYSICAL))

    def test_import_previous_from_checkpoint(self):
        with self.assertRaises(SimulatedCrash):
            self.run_once(MockSolver(PHYSICAL, crash_after_calls=12))
        ck = self.run_dir / "checkpoints" / "checkpoint_0010.zip"
        new_dir = Path(self.tmp.name) / "session2"
        n, _ = R.import_previous(new_dir, ck, self.manifest, self.by_key)
        self.assertEqual(n, 10)
        s = MockSolver(PHYSICAL)
        R.execute(new_dir, self.by_key, self.order, self.keys, s, self.manifest, self.settings, log=lambda *_: None)
        self.assertEqual(len(s.calls), len(self.keys) - 10)


class TestOrderAndHashes(unittest.TestCase):
    def test_execution_order_deterministic(self):
        again = rb.execution_order(PHYSICAL, CFG["requests"]["execution_order_seed"])
        self.assertEqual(again, ORDER)
        other = rb.execution_order(PHYSICAL, CFG["requests"]["execution_order_seed"] + 1)
        self.assertNotEqual(other["order_sha256"], ORDER["order_sha256"])
        self.assertEqual(sorted(o["request_key"] for o in ORDER["order"]), sorted(r["request_key"] for r in PHYSICAL))

    def test_sha_generation(self):
        self.assertEqual(C.sha256_text("abc"), "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")
        p = C.ITEMS_FILE
        self.assertEqual(C.sha256_file(p), hashlib.sha256(p.read_bytes()).hexdigest())
        for relp, sha in C.read_json(C.FROZEN_HASHES)["files"].items():
            self.assertEqual(C.sha256_file(C.STAGE_ROOT / relp), sha, relp)


# =============================================================== statistics / analysis
class TestStatsAndSelection(unittest.TestCase):
    def test_mcnemar_exact(self):
        self.assertEqual(A.mcnemar_exact(0, 0), 1.0)
        self.assertAlmostEqual(A.mcnemar_exact(0, 5), 0.0625)
        self.assertAlmostEqual(A.mcnemar_exact(2, 13), 0.007385, places=5)   # pilot CCA: 13 vs 2, p = .0074
        self.assertEqual(A.mcnemar_exact(4, 4), 1.0)

    def test_bootstrap_reproducible(self):
        a, b = [1, 1, 0, 1, 0, 1, 1, 0], [0, 1, 0, 0, 0, 1, 0, 0]
        x = A.paired_bootstrap(a, b, 2000, "s")
        self.assertEqual(x, A.paired_bootstrap(a, b, 2000, "s"))
        self.assertLessEqual(x[0], 3 / 8)
        self.assertGreaterEqual(x[1], 3 / 8)

    def _row(self, tl, th, rep, mis, loc, v=0.5, amis=0.3):
        return {"tau_low": tl, "tau_high": th, "gated_repair": rep, "gated_misdirected": mis, "share_location": loc,
                "feasible": A._feasible({"repair": rep, "misdirected": mis}, v, amis)}

    def test_selection_rule_and_tie_breaks(self):
        rows = [self._row(.4, .7, .6, .2, .5), self._row(.5, .8, .6, .1, .6), self._row(.6, .8, .6, .1, .3),
                self._row(.7, .9, .7, .4, .2), self._row(.4, .9, .45, .0, .1)]
        sel = A._select(rows)
        self.assertEqual((sel["tau_low"], sel["tau_high"]), (.6, .8))    # best repair, then lower mis, lower loc
        self.assertFalse(rows[3]["feasible"])                             # misdirected above ALWAYS_LOCATION
        self.assertFalse(rows[4]["feasible"])                             # repair below V

    def test_no_feasible_point(self):
        self.assertIsNone(A._select([self._row(.4, .7, .3, .5, .5)]))

    def test_pareto(self):
        rows = [self._row(.4, .7, .6, .2, .5), self._row(.5, .8, .6, .1, .6), self._row(.4, .9, .45, .0, .1)]
        self.assertEqual({(r["tau_low"], r["tau_high"]) for r in A.pareto(rows)}, {(.5, .8), (.4, .9)})

    def test_labels(self):
        m = lambda rep, mis: {"repair": rep, "misdirected": mis}  # noqa: E731
        tune_ok = {"gated": m(.8, .1), "V": m(.7, .1)}
        self.assertEqual(A.label_outcome({"G": m(.8, .1), "V": m(.7, .1), "A": m(.75, .2)}, tune_ok, .05),
                         "STRONG FEASIBILITY SIGNAL")
        self.assertEqual(A.label_outcome({"G": m(.7, .1), "V": m(.7, .1), "A": m(.75, .3)}, tune_ok, .05),
                         "PROMISING / MIXED")
        self.assertEqual(A.label_outcome({"G": m(.6, .1), "V": m(.7, .1), "A": m(.75, .3)}, tune_ok, .05),
                         "NO SUPPORT")
        self.assertEqual(A.label_outcome(None, None, .05), A.NO_FEASIBLE)


class TestAnalysisIsolation(_RunBase):
    def test_tune_phase_never_loads_eval_rows(self):
        self.keys = [o["request_key"] for o in self.order["order"]]
        self.manifest = {**self.manifest, "planned_keys_sha256": C.sha256_text("\n".join(self.keys)),
                         "n_planned": len(self.keys)}
        self.run_once(MockSolver(PHYSICAL))
        ctx = A.Context(CFG, "tune", self.run_dir, n_realizations=40)
        self.assertTrue(ctx.outcomes)
        self.assertTrue(all(BY_ID[i]["stage_a_split"] == "stage_a_tune" for i, _ in ctx.outcomes))
        eval_item = next(i for i in BY_ID if BY_ID[i]["stage_a_split"] == "stage_a_eval")
        with self.assertRaises(AssertionError):
            ctx.cell("V", eval_item, ctx.regimes[0])
        self.assertTrue(ctx.status.startswith("NO REAL MODEL RESULTS YET"))
        out = Path(self.tmp.name) / "analysis"
        A.run_tune(ctx, out)
        ctx_e = A.Context(CFG, "eval", self.run_dir, n_realizations=40)
        report, *_ = A.run_eval(ctx_e, out)
        self.assertTrue(all(r["split"] == "stage_a_eval" for r in report["summary"]))
        with open(out / "thresholds_frozen.json", "a", encoding="utf-8") as fh:
            fh.write(" ")
        with self.assertRaises(SystemExit):                           # tampered thresholds are refused
            A.run_eval(A.Context(CFG, "eval", self.run_dir, n_realizations=40), out)


def _synthetic_outcomes(ctx):
    """Scored rows for every physical prompt of ctx's items: V/L0 keep the corrupted answer, a location or attention
    pointer at the TRUE step repairs, LOC at the false step misdirects, ATTN at the false step keeps the answer."""
    out = {}
    for iid, it in ctx.items.items():
        t, f = it["true_error_step"], it["valid_false_step"]
        plan = {"L0": "corrupted_retention", "V": "corrupted_retention", f"LOC@{t}": "repair",
                f"ATTN@{t}": "repair", f"LOC@{f}": "misdirected", f"ATTN@{f}": "corrupted_retention"}
        for v, o in plan.items():
            out[(iid, v)] = {"outcome": o, **{m: m == o for m in A.METRICS}, "strict_format_compliant": True,
                             "truncated": False}
    return out


class TestMultiRealization(unittest.TestCase):
    def test_seed_namespaces_disjoint_and_reproducible(self):
        reg = "r0.70"
        tune = {sc.realization_seed(CFG, "tune", reg, k) for k in range(500)}
        ev = {sc.realization_seed(CFG, "eval", reg, k) for k in range(500)}
        self.assertFalse(tune & ev)
        self.assertFalse({x["seed"] for x in CRITICS["records"]} & (tune | ev))
        a = A.Context(CFG, "tune", None, n_realizations=30)
        b = A.Context(CFG, "tune", None, n_realizations=30)
        self.assertEqual(a.realizations, b.realizations)
        self.assertEqual(a.realization_info["phase_seed_namespace"], "tune")
        e = A.Context(CFG, "eval", None, n_realizations=30)
        self.assertEqual(e.realization_info["phase_seed_namespace"], "eval")
        with self.assertRaises(AssertionError):
            sc.realization_seed(CFG, "both", reg, 0)

    def test_realizations_only_use_existing_prompts(self):
        """No additional model calls: every policy x realization x threshold pair resolves to a frozen prompt."""
        physical = {(r["item_id"], r["variant"]) for r in PHYSICAL}
        for phase in ("tune", "eval"):
            ctx = A.Context(CFG, phase, None, n_realizations=60)
            for reg in ctx.regimes:
                for k in range(60):
                    for i in ctx.item_ids:
                        rec = ctx.realizations[reg][k][i]
                        self.assertIn(rec["predicted_step"], (BY_ID[i]["true_error_step"], BY_ID[i]["valid_false_step"]))
                        for pol in fpol.CORE_POLICIES:
                            for tau in A.threshold_pairs(CFG):
                                for pf in ("p", "control_p_permuted", "control_p_constant"):
                                    _, v = fpol.route(pol, BY_ID[i], rec, tau, pf)
                                    self.assertIn((i, v), physical)

    def test_mean_accuracy_matches_target(self):
        ctx = A.Context(CFG, "eval", None, n_realizations=2000)
        for reg, r in ctx.reliabilities.items():
            recs = [real[i] for real in ctx.realizations[reg] for i in ctx.item_ids]
            self.assertAlmostEqual(sum(x["critic_correct"] for x in recs) / len(recs), r, delta=0.02)
            self.assertAlmostEqual(sum(x["p"] for x in recs) / len(recs), r, delta=0.02)

    def test_pooled_rate_equals_mean_of_realization_rates_and_feasible_path(self):
        ctx = A.Context(CFG, "tune", None, n_realizations=80)
        ctx.outcomes, ctx.has_results, ctx.status = _synthetic_outcomes(ctx), True, "SYNTHETIC TEST"
        m = A.policy_metrics(ctx, "RELIABILITY_GATED", "r0.80", (0.5, 0.8))
        per = []
        for k in range(80):
            rows = [ctx.cell("RELIABILITY_GATED", i, "r0.80", k, (0.5, 0.8))[1] for i in ctx.item_ids]
            per.append(sum(s["repair"] for s in rows) / len(rows))
        self.assertAlmostEqual(m["repair"], sum(per) / len(per), places=5)
        self.assertEqual(m["n_missing"], 0)
        with tempfile.TemporaryDirectory() as d:
            ctx.run_manifest = {"requests_sha256": "x"}
            body = A.run_tune(ctx, d)
            self.assertEqual(body["global_status"], "SELECTED")
            self.assertEqual(body["critic_realizations_used_for_selection"]["phase_seed_namespace"], "tune")
            ev = A.Context(CFG, "eval", None, n_realizations=80)
            ev.outcomes, ev.has_results, ev.status = _synthetic_outcomes(ev), True, "SYNTHETIC TEST"
            ev.run_manifest = {"requests_sha256": "x"}
            report, pm, cmp_, _ = A.run_eval(ev, d)
            self.assertEqual(report["primary_critic_realizations"]["phase_seed_namespace"], "eval")
            self.assertTrue(all(r["critic_realizations"] == "multi" for r in cmp_))
            self.assertTrue(any(r["policy"] == "RELIABILITY_GATED[per_regime_thresholds_SENSITIVITY]" for r in pm)
                            or all(not isinstance(v, dict) for v in body["selected_per_regime_sensitivity"].values()))
            fz = list(__import__("csv").DictReader(open(Path(d) / "paired_comparisons_frozen_realization.csv")))
            self.assertTrue(all(r["mcnemar_exact_p"] not in ("", None) for r in fz))
            self.assertTrue((Path(d) / "policy_metrics_frozen_realization.csv").exists())


class TestNoLocalModel(unittest.TestCase):
    def test_real_solver_refused_off_kaggle(self):
        if os.environ.get("KAGGLE_KERNEL_RUN_TYPE") or os.path.isdir("/kaggle/working"):
            self.skipTest("running on Kaggle")
        from src.solver_loader import guard_real_model
        old = os.environ.pop("STAGE_A_ALLOW_MODEL_LOAD", None)
        try:
            with self.assertRaises(SystemExit):
                guard_real_model()
        finally:
            if old is not None:
                os.environ["STAGE_A_ALLOW_MODEL_LOAD"] = old


if __name__ == "__main__":
    unittest.main()
